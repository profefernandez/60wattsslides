<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Render / and CMS preview through AppView — why: preview parity.
- Keep private media signed and documents claim-gated — why: public downloads are unsafe.
- Use one media switcher for uploads/library/URLs — why: consistent preview and publishing.
- First signed-in user becomes admin through ensureAdmin — why: this is a single-owner CMS.
- Store heading/subtitle styles separately; backgrounds/layout and two links live in title_style JSON — why: preserve old slides.
- Store per-slide alt text in media_alt; blank is decorative — why: media meaning varies.
- AppView includes hidden slides only in CMS, pauses CMS autoplay, and shares story progress and 44px tap zones — why: preview fidelity and accessibility.
- Workshop session details live in items JSON; only record registration clicks for a live matching link — why: flexible schedules without forged analytics.
- Build `data-anchor` ids and slide map from live CMS slides — why: static maps become stale.
- Keep guide navigation and annotations local to AppView; visitor search uses server-local lexical/fuzzy matching, no external AI, no question storage, and only highlights existing slides — why: site-wide zero-retention/GDPR policy.
- Centralize button appearance in slide-actions and SlideActionLink — why: shared contrast and shapes.
- Keep CMS sections in collapsible left nav — why: CRM stays accessible with editor hidden.
- Keep framing/offsets in style JSON; reorder via slide-order; render photo-text in AppView — why: shared preview/live order and appearance.
- Photo shape/border/shadow/split live in title_style and render only through slide-placement helpers via PhotoEditSurface — why: preview/live parity, no schema change.
