# Mobile readiness

- [x] Keep the mobile viewport configuration, fluid public slide layout, and flexible photo/video rendering intact while improving phone usability.
- [x] Ensure meaningful public slide controls—including arrows, pause/play, progress controls, search results, quiz/game reset, and search input—are comfortably tappable and readable on phone-width screens.
- [x] Make the Slides CMS, Media Library, CRM, and Site Settings usable on phones with 16px form inputs, practical tap targets, no horizontal overflow, and an available live Site Settings preview.
- [x] Verify the public website and CMS at phone dimensions, run type/build checks, and preserve all existing editing, CRM, media-library, and browser-local behaviors.

# Owner-hosted PostgreSQL

- [x] Replace the MySQL-specific persistence adapter with PostgreSQL while preserving revision-safe slide drafts and publication, CRM, media records, subscription state, Stripe webhook idempotency, and domain requests.
- [x] Provide an idempotent PostgreSQL schema/bootstrap script and VPS environment template using a dedicated `POSTGRES_URL`, without committing passwords or other credentials.
- [x] Update database-backed verification scripts to use PostgreSQL and type-check the complete application.
- [ ] Apply the schema and connect the CMS to the owner’s actual PostgreSQL database after receiving SSH access and the database password; validate the deployed CMS against the owner’s domain.
