# Slides Website Studio — CMS implementation

**Status:** Implemented in the Preview. The seven-slide customer website continues to use the same renderer in both the CMS and public site.

## Four focused workspaces

| Workspace | What the owner does | Connection to the live website |
| --- | --- | --- |
| **Slides** | Select a slide in the outline or dropdown; edit its headline, each line’s color, supporting copy, photo/video and multiple CTA buttons; add or change a premade layout. | The center preview renders the real selected slide. A button can link to another slide, the search bar, a secure URL or an email. New slides start hidden. |
| **Media Library** | Upload photos or videos once; add a validated YouTube URL; search and filter assets; remove an unused library entry. | Select **Use photo/video on selected slide** or **Use as website logo**. Each asset lists the slides using it; clicking one opens that slide’s editor. |
| **CRM** | Review opt-in workshop requests and tailored-path enquiries; filter, search, change follow-up stage, add private notes and export CSV. | Each lead names its source slide and has **Open source slide**. A workshop submission is a request, **not** a confirmed appointment or payment. |
| **Site Settings** | Change logo, brand copy, palette, fonts, progress controls and search chrome. Save a prospective custom hostname. | Global settings apply to every slide. The domain status remains pending until a project owner connects it at the platform level, configures DNS and verifies HTTPS. |

The first visit opens a selected slide with its editing controls visible, not an empty builder. Controls use compact, readable labels. **Text & color / Photo & video / CTA buttons** jump links remain visible while scrolling the inspector. More specialized fields—booking times/capacity, quiz answers, memory pairs and HTML—appear only for relevant layouts. Crop, card and styling controls sit inside an optional advanced disclosure. On a phone, **Edit text, media & buttons ↓** scrolls directly to the editing area; Project options remain reachable for ZIP backups.

## Save and media behavior

Personal `/studio-demo` writes a draft and separate `/my-site` snapshot to this browser. Library uploads use stable IndexedDB IDs, and the ZIP carries draft, publication, library metadata, uploaded bytes **and private CRM contacts**; protect the downloaded file. Import replaces those contacts with the imported project's contacts and remaps media IDs safely. The authenticated `/admin` studio stores tenant-scoped decks and media metadata in managed MySQL, with protected media uploads and deliberately separate draft/publish actions; a full hosted-account ZIP export is not implemented. The old first-party sample images appear as selectable library assets even though they are not separately uploaded by the owner. Unconfirmed workshop requests do not reserve seats; only an owner-selected **Confirmed booking** stage counts toward capacity.

## Custom-domain boundary

The **domain request** control does not perform a domain connection. Manus documents a project-level UI flow at [Website Settings → Domains](https://manus.im/docs/website-builder/custom-domains); it provides the exact DNS target and handles HTTPS after verification. The available Webdev API has no documented customer-level domain-attach operation. This shared project currently serves customers by `/s/:slug`; it has no verified custom-host-to-slug router, and multi-domain-per-project support has not been established. Until those pieces are built and tested, display **Awaiting platform connection**, never “Connected” or “Live.” A browser-local `/my-site` cannot receive a custom domain.
