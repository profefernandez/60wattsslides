# 60 Watts of Clarity — PostgreSQL CMS setup on the VPS

This application now uses PostgreSQL for server-backed CMS data. The database stores customer slide drafts and published copies, CRM contacts, Media Library records, Stripe state, and domain requests. It does not store photo or video bytes.

## 1. Prepare the database in the hosting panel

Use the existing database `60wattsofclaritycom_website` and PostgreSQL user `60wattsofclaritycom_jason`. Give that user full privileges on this database. Keep the password private.

The VPS application will use a local-only connection, not expose PostgreSQL to the internet:

```text
postgresql://60wattsofclaritycom_jason:URL_ENCODED_PASSWORD@127.0.0.1:5432/60wattsofclaritycom_website
```

If the hosting provider supplies a non-default port or database host, use its exact value instead of `127.0.0.1:5432`.

## 2. Configure the application

On the VPS, copy `.env.vps.example` to `.env`, set `POSTGRES_URL`, and add the existing product’s Supabase and Stripe credentials. Do not commit `.env` or share its contents publicly.

Run the idempotent bootstrap and connection checks from the deployed application directory. These npm commands use Node’s `--env-file=.env` support, so the private values are actually loaded:

```bash
npm ci
npm run db:setup
npm run db:check
```

The first command creates the required tables, indexes, and automatic `updated_at` triggers. It can be safely run again after a controlled maintenance window; it is not a replacement for versioned production migrations.

If the previous MySQL CMS contains records that matter, back up both databases and do not point the application at PostgreSQL yet. Add `MYSQL_SOURCE_URL` to the VPS `.env`, run `node --env-file=.env --import tsx scripts/migrate-mysql-to-postgres.ts` to review source counts, freeze MySQL writes, then rerun it with `--apply`. This one-time importer carries customer decks, published snapshots/slugs, active entitlement and Stripe IDs, CRM leads, media/asset indexes, domain requests, and processed Stripe event IDs. Validate PostgreSQL before application cutover and retain the MySQL backup for rollback.

## 3. Activate the owner CMS deliberately

The browser-only `/studio-demo` works without an account. The durable `/admin` CMS uses Supabase sign-in and requires an active entitlement. After Jason signs in once, obtain his Supabase user UUID and run:

```bash
OWNER_SUPABASE_USER_ID=YOUR_SUPABASE_UUID npm run db:grant-owner
```

This creates the owner’s starter site record if needed and activates only that account. It does not affect other users or send a Stripe charge.

## 4. Validate before cutover

After PostgreSQL is reachable, run the database-backed checks against the new VPS database:

```bash
npx tsx scripts/verify-isolation.ts
npx tsx scripts/verify-media-domain.ts
npx tsx scripts/verify-crm-abuse.ts
```

Run the Stripe webhook and server-rendering checks only after the Node service is running locally on the VPS and Stripe test credentials are configured.

## What this does not yet deploy

This PostgreSQL work does not itself replace the current Apache redirect, configure a Node service, issue a new certificate, or move uploaded media bytes. The existing hosted upload path relies on managed storage and must be replaced with a local secure upload service or object storage before the Media Library is fully self-hosted. Supabase remains the sign-in provider, and Stripe remains the billing provider.
