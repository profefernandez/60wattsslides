ALTER TABLE public.slides ADD COLUMN document_allowed_types text[] NOT NULL DEFAULT ARRAY['pdf','doc','docx','xls','xlsx','ppt','pptx','txt','csv','zip']::text[];
ALTER TABLE public.slides ADD COLUMN document_max_upload_mb integer NOT NULL DEFAULT 20;
ALTER TABLE public.slides ADD CONSTRAINT document_max_upload_mb_range CHECK (document_max_upload_mb BETWEEN 1 AND 20);
ALTER TABLE public.slides ADD CONSTRAINT document_allowed_types_nonempty CHECK (cardinality(document_allowed_types) BETWEEN 1 AND 10);