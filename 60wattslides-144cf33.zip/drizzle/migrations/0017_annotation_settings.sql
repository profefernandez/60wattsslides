ALTER TABLE public.site_settings
  ADD COLUMN IF NOT EXISTS annotation_mode text NOT NULL DEFAULT 'after_search',
  ADD COLUMN IF NOT EXISTS annotation_label text NOT NULL DEFAULT 'Annotations',
  ADD COLUMN IF NOT EXISTS annotation_display text NOT NULL DEFAULT 'both',
  ADD COLUMN IF NOT EXISTS annotation_icon text NOT NULL DEFAULT 'highlighter',
  ADD COLUMN IF NOT EXISTS annotation_style text NOT NULL DEFAULT 'outline',
  ADD COLUMN IF NOT EXISTS annotation_shape text NOT NULL DEFAULT 'rounded',
  ADD COLUMN IF NOT EXISTS annotation_color text NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS answer_template jsonb NOT NULL DEFAULT '{}'::jsonb;