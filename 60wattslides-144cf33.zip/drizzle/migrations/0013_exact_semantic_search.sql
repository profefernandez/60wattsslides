CREATE EXTENSION IF NOT EXISTS vector WITH SCHEMA extensions;

CREATE TABLE public.search_chunks (
  anchor_id text PRIMARY KEY,
  slide_id uuid NOT NULL REFERENCES public.slides(id) ON DELETE CASCADE,
  content text NOT NULL,
  content_hash text NOT NULL,
  embedding extensions.vector(3072) NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.search_chunks TO service_role;
ALTER TABLE public.search_chunks ENABLE ROW LEVEL SECURITY;
-- No policies: only the server (service role) reads/writes. No ANN index on purpose: exact search.

CREATE OR REPLACE FUNCTION public.match_search_chunks(query_embedding extensions.vector(3072), match_count int DEFAULT 8)
RETURNS TABLE(anchor_id text, slide_id uuid, content text, similarity float)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public, extensions
AS $$
  SELECT c.anchor_id, c.slide_id, c.content, 1 - (c.embedding <=> query_embedding) AS similarity
  FROM public.search_chunks c
  JOIN public.slides s ON s.id = c.slide_id AND s.enabled
  ORDER BY c.embedding <=> query_embedding
  LIMIT least(greatest(match_count, 1), 20);
$$;
REVOKE ALL ON FUNCTION public.match_search_chunks(extensions.vector, int) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.match_search_chunks(extensions.vector, int) TO service_role;