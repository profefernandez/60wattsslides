ALTER TABLE public.slides ADD COLUMN document_expires_at timestamptz;
ALTER TABLE public.slides ADD COLUMN document_max_downloads integer NOT NULL DEFAULT 0;
ALTER TABLE public.slides ADD COLUMN document_retention_days integer NOT NULL DEFAULT 30;
ALTER TABLE public.document_submissions ADD COLUMN expires_at timestamptz NOT NULL DEFAULT (now() + interval '30 days');
CREATE INDEX document_submissions_expires_idx ON public.document_submissions (expires_at);
CREATE FUNCTION public.purge_expired_document_submissions() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$ BEGIN DELETE FROM public.document_submissions WHERE expires_at <= now(); RETURN NEW; END $$;
CREATE TRIGGER purge_expired_document_submissions_on_insert BEFORE INSERT ON public.document_submissions FOR EACH STATEMENT EXECUTE FUNCTION public.purge_expired_document_submissions();