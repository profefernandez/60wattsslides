ALTER TABLE public.slides ADD COLUMN document_download_count integer NOT NULL DEFAULT 0;
CREATE OR REPLACE FUNCTION public.claim_document_download(_slide_id uuid, _name text, _email text) RETURNS TABLE(file_path text, file_name text)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE s public.slides%ROWTYPE;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtextextended(_slide_id::text, 0));
  SELECT * INTO s FROM public.slides WHERE id = _slide_id AND enabled AND kind = 'document' AND document_path <> '' AND document_name <> '' AND (document_expires_at IS NULL OR document_expires_at > now());
  IF NOT FOUND THEN RAISE EXCEPTION 'Download unavailable'; END IF;
  IF length(trim(_name)) < 2 OR length(_name) > 120 OR length(_email) > 254 OR _email !~* '^[^@[:space:]]+@[^@[:space:]]+\.[^@[:space:]]+$' THEN RAISE EXCEPTION 'Invalid details'; END IF;
  IF s.document_max_downloads > 0 AND s.document_download_count >= s.document_max_downloads THEN RAISE EXCEPTION 'Download limit reached'; END IF;
  IF EXISTS (SELECT 1 FROM public.document_submissions WHERE slide_id = _slide_id AND email = lower(trim(_email)) AND created_at > now() - interval '1 minute') THEN RAISE EXCEPTION 'Please wait before requesting this file again'; END IF;
  INSERT INTO public.document_submissions(slide_id, name, email, expires_at) VALUES (_slide_id, trim(_name), lower(trim(_email)), now() + make_interval(days => greatest(1, least(365, s.document_retention_days))));
  UPDATE public.slides SET document_download_count = document_download_count + 1 WHERE id = _slide_id;
  RETURN QUERY SELECT s.document_path, s.document_name;
END $$;
REVOKE ALL ON FUNCTION public.claim_document_download(uuid,text,text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.claim_document_download(uuid,text,text) TO service_role;