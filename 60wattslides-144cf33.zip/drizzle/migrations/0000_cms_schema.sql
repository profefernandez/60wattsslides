create type public.app_role as enum ('admin', 'user');
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  role public.app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "Users read own roles" on public.user_roles for select to authenticated using (auth.uid() = user_id);

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.user_roles where user_id = _user_id and role = _role) $$;

create table public.slides (
  id uuid primary key default gen_random_uuid(),
  position integer not null default 0,
  kind text not null default 'image',
  title text not null default '',
  subtitle text not null default '',
  media_url text not null default '',
  overlay_opacity integer not null default 40,
  items jsonb not null default '[]'::jsonb,
  enabled boolean not null default true,
  created_at timestamptz not null default now()
);
grant select on public.slides to anon, authenticated;
grant insert, update, delete on public.slides to authenticated;
grant all on public.slides to service_role;
alter table public.slides enable row level security;
create policy "Anyone reads slides" on public.slides for select to anon, authenticated using (true);
create policy "Admins insert slides" on public.slides for insert to authenticated with check (public.has_role(auth.uid(), 'admin'));
create policy "Admins update slides" on public.slides for update to authenticated using (public.has_role(auth.uid(), 'admin'));
create policy "Admins delete slides" on public.slides for delete to authenticated using (public.has_role(auth.uid(), 'admin'));

create table public.site_settings (
  id integer primary key default 1,
  app_name text not null default 'Horizon Learning',
  chat_placeholder text not null default 'Ask about our programs...',
  system_prompt text not null default '',
  autoplay_seconds integer not null default 7,
  constraint single_row check (id = 1)
);
grant select on public.site_settings to anon, authenticated;
grant update on public.site_settings to authenticated;
grant all on public.site_settings to service_role;
alter table public.site_settings enable row level security;
create policy "Anyone reads settings" on public.site_settings for select to anon, authenticated using (true);
create policy "Admins update settings" on public.site_settings for update to authenticated using (public.has_role(auth.uid(), 'admin'));

insert into public.site_settings (id, system_prompt) values (1, 'You are a helpful, friendly, and professional admissions and support assistant for an educational company named ''Horizon Learning''. Our programs include K-12 Tutoring, University Prep, and Tech Bootcamps. Keep your answers concise, formatted well, and highly relevant to an educational setting. Do not make up prices, just say an advisor can provide a quote.');

insert into public.slides (position, kind, title, subtitle, media_url, overlay_opacity, items) values
(0, 'image', 'Welcome to Horizon Learning', 'Empowering your future.', 'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&w=1600&q=80', 40, '[]'),
(1, 'video', 'Immersive Campus Experience', 'Experience learning from anywhere in the world with state-of-the-art digital tools.', 'https://storage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4', 50, '[]'),
(2, 'list', 'Our Premier Programs', '', '', 0, '[{"title":"Software Engineering","desc":"Master full-stack development, system architecture, and modern frameworks to build scalable applications.","meta":"12 Weeks • Online or Hybrid"},{"title":"Data Science","desc":"Learn machine learning, statistical modeling, and data visualization to drive intelligent decision-making.","meta":"14 Weeks • Online or Hybrid"},{"title":"Digital Marketing","desc":"Drive growth through SEO, advanced analytics, and strategic campaign management.","meta":"8 Weeks • Online"}]'),
(3, 'image', 'Start Your Journey Today', 'Ask our AI assistant below to get enrolled or learn more.', 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?auto=format&fit=crop&w=1600&q=80', 50, '[]');

create policy "Public read media" on storage.objects for select using (bucket_id = 'media');
create policy "Admins upload media" on storage.objects for insert to authenticated with check (bucket_id = 'media' and public.has_role(auth.uid(), 'admin'));
create policy "Admins update media" on storage.objects for update to authenticated using (bucket_id = 'media' and public.has_role(auth.uid(), 'admin'));
create policy "Admins delete media" on storage.objects for delete to authenticated using (bucket_id = 'media' and public.has_role(auth.uid(), 'admin'));