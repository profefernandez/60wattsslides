CREATE TABLE public.workshop_clicks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slide_id uuid NOT NULL REFERENCES public.slides(id) ON DELETE CASCADE,
  session_title text NOT NULL DEFAULT '',
  signup_url text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX workshop_clicks_slide_idx ON public.workshop_clicks(slide_id, created_at DESC);
GRANT SELECT ON public.workshop_clicks TO authenticated;
GRANT ALL ON public.workshop_clicks TO service_role;
ALTER TABLE public.workshop_clicks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins read workshop clicks" ON public.workshop_clicks FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'::app_role));