ALTER TABLE public.slides ADD COLUMN document_path text NOT NULL DEFAULT '';
ALTER TABLE public.slides ADD COLUMN document_name text NOT NULL DEFAULT '';
CREATE TABLE public.document_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slide_id uuid NOT NULL REFERENCES public.slides(id) ON DELETE CASCADE,
  name text NOT NULL,
  email text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.document_submissions TO authenticated;
GRANT ALL ON public.document_submissions TO service_role;
ALTER TABLE public.document_submissions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Admins read document submissions" ON public.document_submissions FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE INDEX document_submissions_slide_created_idx ON public.document_submissions (slide_id, created_at DESC);