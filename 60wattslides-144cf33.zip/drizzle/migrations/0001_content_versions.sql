create table public.content_versions (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  created_by uuid,
  author_email text not null default '',
  snapshot jsonb not null
);
grant select, insert on public.content_versions to authenticated;
grant all on public.content_versions to service_role;
alter table public.content_versions enable row level security;
create policy "Admins read versions" on public.content_versions for select to authenticated using (public.has_role(auth.uid(), 'admin'));
create policy "Admins create versions" on public.content_versions for insert to authenticated with check (public.has_role(auth.uid(), 'admin'));