TRUNCATE public.search_chunks;
REVOKE EXECUTE ON FUNCTION public.match_search_chunks(extensions.vector, int) FROM service_role;
COMMENT ON TABLE public.search_chunks IS 'DEPRECATED: search now runs locally on the server with no external embeddings; kept empty.';
COMMENT ON FUNCTION public.match_search_chunks(extensions.vector, int) IS 'DEPRECATED: unused.';