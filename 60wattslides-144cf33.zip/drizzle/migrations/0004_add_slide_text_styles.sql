ALTER TABLE public.slides ADD COLUMN title_style jsonb NOT NULL DEFAULT '{}'::jsonb;
ALTER TABLE public.slides ADD COLUMN subtitle_style jsonb NOT NULL DEFAULT '{}'::jsonb;