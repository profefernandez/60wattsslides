# Slides Website

A customer-editable, full-screen slide website. Visitors browse a visual story and search **only the published slide text**. The personal studio and the authenticated CMS use the same renderer.

## Use it now for your own website

Open `/studio-demo` to use the browser-persistent personal studio. The four CMS workspaces are **Slides**, **Media Library**, **CRM**, and **Site Settings**. Select a visual slide thumbnail, edit its visible words, colors, photos/video, and CTA buttons, then Save draft and Publish locally. `/my-site` shows the separate published snapshot in the same browser. Export a ZIP regularly; it includes the draft, published snapshot, media library, and personal CRM contacts.

The authenticated `/admin` path gives a signed-in customer a private server-backed draft and a separately published `/s/:slug` site. New slides begin hidden. The editor provides thirteen prefilled layouts: editorial, photo/video, multiple-choice, memory-match, isolated HTML/CSS/JavaScript, workshop request, and tailored-path interactions. CTA buttons can link to another slide, the search bar, email, a `tel:` phone number, or a secure web/map link.

## Owner-hosted PostgreSQL on the VPS

The CMS server persistence is PostgreSQL-based. It stores each customer’s revision-safe slide draft and published snapshot, Stripe subscription/webhook state, CRM contacts and confirmed booking capacity, Media Library records, and custom-domain requests. The runtime expects **`POSTGRES_URL`**, not the old managed MySQL `DATABASE_URL`.

On the VPS, copy [.env.vps.example](.env.vps.example) to a private `.env`, add the real PostgreSQL, Supabase, and Stripe values, and then run the idempotent bootstrap:

```bash
npm ci
cp .env.vps.example .env
# edit .env securely; do not commit it
npm run db:setup
npm run db:check
npm run build
```

The PostgreSQL database and user already shown in the hosting panel should be available locally through a URL of this form; URL-encode the password if it has special characters:

```text
postgresql://60wattsofclaritycom_jason:YOUR_PASSWORD@127.0.0.1:5432/60wattsofclaritycom_website
```

The database password, SSH account, Supabase settings, and Stripe secrets must stay only on the VPS. The npm database commands load the private `.env` with Node’s `--env-file` flag; the deployed Node service must receive the same values through an Apache/systemd `EnvironmentFile=` or Docker `--env-file .env` configuration. The actual VPS bootstrap, Apache reverse-proxy change, root-domain cutover, and live CMS connection require those credentials and are intentionally not attempted from this workspace.

After Jason signs in once through `/auth`, run `OWNER_SUPABASE_USER_ID=YOUR_SUPABASE_UUID npm run db:grant-owner` on the VPS to activate **his** durable `/admin` CMS without sending his own Stripe checkout. The full [VPS PostgreSQL setup runbook](docs/vps-postgres-setup.md) includes the safe order of operations.

If the prior MySQL CMS database contains real customer sites, do **not** cut over by running the bootstrap alone. Back up both databases, run `node --env-file=.env --import tsx scripts/migrate-mysql-to-postgres.ts` first for a source-row count dry run, freeze MySQL writes, then add `--apply` to import customer decks, public snapshots, billing IDs, CRM contacts, media records, asset ownership records, domain requests, and processed Stripe event IDs. Verify PostgreSQL before switching the app; retain the MySQL backup until the new CMS is confirmed.

### Important self-hosting boundary

This PostgreSQL migration makes the CMS database owner-operated. Authentication still uses the configured Supabase project, and hosted file uploads currently rely on the existing managed storage adapter. Before production deployment to the VPS, the Media Library’s managed-storage path must be replaced with either a secured local upload volume or S3-compatible object storage, and the starter media must be copied to that storage. PostgreSQL alone does not store or serve the uploaded photo/video bytes.

## Pages

- `/`: public slide website demo.
- `/studio-demo`: browser-persistent personal CMS; `/my-site`: its local published snapshot.
- `/auth`: customer sign-in/sign-up through the configured Supabase project.
- `/admin`: subscriber CMS with a private draft and deliberate publication.
- `/s/:slug`: a customer’s published site while the subscription is active.
- `/payments`: the authenticated customer’s Stripe invoice history and billing handoff.
- `/api/stripe/webhook`: signed Stripe webhook; `/api/health`: unauthenticated health response.

## Verification

Run `npx tsc --noEmit`, `npm test`, and `npm run build` for source validation. With PostgreSQL configured and the schema applied, run `npx tsx scripts/check-postgres.ts`, `npx tsx scripts/verify-isolation.ts`, `npx tsx scripts/verify-media-domain.ts`, `npx tsx scripts/verify-crm-abuse.ts`, `npx tsx scripts/verify-stripe-ordering.ts`, `npx tsx scripts/verify-webhook.ts`, and `npx tsx scripts/verify-ssr.ts` for database-backed coverage. With the development server running, the browser checks `verify-personal-browser.ts`, `verify-workspaces-browser.ts`, `verify-crm-browser.ts`, `verify-editor-redesign.ts`, `verify-editable-copy-browser.ts`, and `verify-mobile-readiness.ts` cover the personal studio and responsive CMS behavior.

No protected value belongs in Git. Before a live launch, test the real sign-in, Stripe production checkout/portal/webhook, PostgreSQL backup/restore, media storage, and Apache/TLS deployment on `60wattsofclarity.com`.
