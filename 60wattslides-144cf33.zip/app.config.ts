export default { logoUrl: "https://files.manuscdn.com/user_upload_by_module/session_file/105841546/MWYbtQHHeYqWedxj.svg" };
