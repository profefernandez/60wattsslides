import { randomUUID } from "node:crypto";
import assert from "node:assert/strict";
import { closeDatabase, database, ownDeck, publishedDeck, publishDraft, saveDraft } from "../src/template/db.server";

async function main() {
  if (!process.env.POSTGRES_URL) throw new Error("POSTGRES_URL is required for this integration check");
  const alice = randomUUID(), bob = randomUUID();
  try {
    const first = await ownDeck(alice);
    const second = await ownDeck(bob);
    assert.equal(first.deck.slides.length, 7);
    assert.equal(second.deck.slides.length, 7);
    assert.notEqual(first.slug, second.slug);
    await database()`UPDATE customer_decks SET entitlement_status='active' WHERE user_id=${alice}`;
    first.deck.theme.brandName = "Only Alice";
    const revision = await saveDraft(alice, first.deck, first.revision);
    await assert.rejects(saveDraft(bob, second.deck, second.revision), /subscription ended/);
    await assert.rejects(saveDraft(alice, first.deck, first.revision), /another tab/);
    assert.equal((await ownDeck(bob)).deck.theme.brandName, second.deck.theme.brandName);
    await publishDraft(alice, first.deck, revision);
    await assert.rejects(publishDraft(alice, first.deck, revision), /another tab/);
    assert.equal((await publishedDeck(first.slug))?.theme.brandName, "Only Alice");
    assert.equal(await publishedDeck(second.slug), null);
    console.log("PostgreSQL tenant isolation, subscription gate, draft save, and publication verified");
  } finally {
    await database()`DELETE FROM customer_decks WHERE user_id IN (${alice},${bob})`;
    await closeDatabase();
  }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
