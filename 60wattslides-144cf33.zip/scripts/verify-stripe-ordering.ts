import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { closeDatabase, database, ownDeck } from "../src/template/db.server";
import { applySubscriptionSnapshot } from "../src/template/stripe-webhook.server";

async function main() {
  if (!process.env.POSTGRES_URL) throw new Error("POSTGRES_URL is required for this integration check");
  const userId = `test-stripe-order-${randomUUID()}`;
  const db = database();
  try {
    await ownDeck(userId);
    // Simulate two same-second events by passing Stripe's authoritative, current canceled state.
    await db.begin((tx) => applySubscriptionSnapshot(tx, { userId, customerId: "cus_order", subscriptionId: "sub_current", status: "active" }));
    await db.begin((tx) => applySubscriptionSnapshot(tx, { userId, customerId: "cus_order", subscriptionId: "sub_current", status: "canceled" }));
    const canceled = await db<{ entitlement_status: string; stripe_subscription_id: string | null }[]>`
      SELECT entitlement_status,stripe_subscription_id FROM customer_decks WHERE user_id=${userId}
    `;
    assert.equal(canceled[0]?.entitlement_status, "none");
    // A delayed event for the canceled old subscription cannot replace a later active subscription.
    await db`UPDATE customer_decks SET stripe_subscription_id='sub_new',entitlement_status='active' WHERE user_id=${userId}`;
    await db.begin((tx) => applySubscriptionSnapshot(tx, { userId, customerId: "cus_order", subscriptionId: "sub_current", status: "canceled" }));
    const current = await db<{ entitlement_status: string; stripe_subscription_id: string | null }[]>`
      SELECT entitlement_status,stripe_subscription_id FROM customer_decks WHERE user_id=${userId}
    `;
    assert.equal(current[0]?.stripe_subscription_id, "sub_new");
    assert.equal(current[0]?.entitlement_status, "active");
    console.log("Authoritative Stripe state prevents same-second cancellation and stale-subscription ordering errors");
  } finally {
    await db`DELETE FROM customer_decks WHERE user_id=${userId}`;
    await closeDatabase();
  }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
