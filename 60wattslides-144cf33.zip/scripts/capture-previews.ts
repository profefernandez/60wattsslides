import { chromium } from "playwright-core";

async function main() {
  const origin = process.env["PREVIEW_URL"] || "http://127.0.0.1:3000";
  const mediaOrigin = process.env["MEDIA_ORIGIN"];
  const browser = await chromium.launch({ executablePath: "/usr/bin/chromium", headless: true, args: ["--no-sandbox"] });
  try {
    const desktop = await browser.newPage({ viewport: { width: 1600, height: 900 }, deviceScaleFactor: 1 });
    const connectMedia = async (page: typeof desktop) => {
      if (!mediaOrigin) return;
      await page.route("**/manus-storage/**", async (route) => {
        const path = new URL(route.request().url()).pathname;
        const response = await route.fetch({ url: new URL(path, mediaOrigin).href });
        await route.fulfill({ response });
      });
    };
    await connectMedia(desktop);
    await desktop.goto(origin, { waitUntil: "networkidle" });
    await desktop.locator(".sw-slide--split").waitFor();
    await desktop.evaluate(() => document.fonts.ready);
    await desktop.screenshot({ path: "docs/preview-desktop.png" });
    await desktop.getByRole("button", { name: "Go to slide 3" }).click();
    await desktop.locator(".sw-slide--editorial").waitFor();
    await desktop.locator(".sw-photo").evaluate(async (element) => {
      const image = new Image();
      image.src = getComputedStyle(element).backgroundImage.slice(5, -2);
      await image.decode();
    });
    await desktop.screenshot({ path: "docs/preview-editorial.png" });
    const mobile = await browser.newPage({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, isMobile: true, hasTouch: true });
    await connectMedia(mobile);
    await mobile.goto(origin, { waitUntil: "networkidle" });
    await mobile.locator(".sw-slide--split").waitFor();
    await mobile.evaluate(() => document.fonts.ready);
    await mobile.screenshot({ path: "docs/preview-mobile.png" });
    console.log("Captured three clean website previews in docs/");
  } finally { await browser.close(); }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
