import assert from "node:assert/strict";
import { chromium } from "playwright-core";

const origin = process.env.PREVIEW_URL ?? "https://8328-in4uy4c7zi9g0qj8fh1nj-cc83b7a5.us1.manus.computer";

async function main() {
  const browser = await chromium.launch({ executablePath: "/usr/bin/chromium", headless: true, args: ["--no-sandbox"] });
  try {
    const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
    const page = await context.newPage();
    await page.goto(`${origin}/studio-demo`);
    await page.locator(".studio-inspector-tabs").waitFor();

    await page.getByRole("textbox", { name: "Headline", exact: true }).fill("Everything can\nbe changed.");
    assert.match(await page.locator(".studio-preview-frame .sw-headline").innerText(), /Everything can/);

    await page.locator("details.studio-quick-beats summary").click();
    await page.getByRole("button", { name: "Add a story beat" }).click();
    const newestBeat = page.locator(".studio-quick-beat").last();
    await newestBeat.getByLabel("Heading").fill("A fully editable story point");
    assert.equal(await newestBeat.getByLabel("Heading").inputValue(), "A fully editable story point");

    await page.getByRole("button", { name: "Add a slide" }).click();
    await page.getByRole("button", { name: "Multiple choice" }).click();
    await page.locator(".studio-special-editor").waitFor();
    await page.locator(".studio-copy-controls summary").click();
    await page.getByLabel("Small instruction line").fill("PAUSE · REFLECT · CHOOSE");
    assert.equal(await page.locator(".studio-preview-frame .sw-interactive-kicker").innerText(), "PAUSE · REFLECT · CHOOSE");

    await page.getByRole("button", { name: "Site Settings" }).click();
    await page.getByLabel("Context line below the search").fill("Every answer is grounded in this website’s published slides.");
    assert.equal(await page.locator(".settings-preview .sw-search-context").innerText(), "Every answer is grounded in this website’s published slides.");
    await page.locator(".settings-logo").getByRole("button", { name: "Remove" }).click();
    assert.equal(await page.locator(".settings-preview .sw-brand img").count(), 0);

    await page.getByRole("button", { name: "Save draft" }).click();
    const saved = await page.evaluate(() => JSON.parse(localStorage.getItem("slides-website:personal:project:v2")!).draft);
    assert.equal(saved.slides[0].title, "Everything can\nbe changed.");
    assert.equal(saved.slides[0].items.at(-1).title, "A fully editable story point");
    assert.equal(saved.slides.find((slide: { layout: string }) => slide.layout === "quiz").interactionCopy.kicker, "PAUSE · REFLECT · CHOOSE");
    assert.equal(saved.theme.searchContext, "Every answer is grounded in this website’s published slides.");
    assert.equal(saved.theme.logoUrl, "");
    await context.close();
    console.log("CMS editability: visible slide copy, story beats, interactive language and search language verified");
  } finally {
    await browser.close();
  }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
