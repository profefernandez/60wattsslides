import assert from "node:assert/strict";
import { chromium } from "playwright-core";

const STATE_KEY = "slides-website:personal:project:v2";
const origin = process.env.PREVIEW_URL ?? "http://127.0.0.1:3000";

async function main() {
  const browser = await chromium.launch({ executablePath: "/usr/bin/chromium", headless: true, args: ["--no-sandbox"] });
  try {
    // This isolated browser context cannot read or mutate a real creator's project.
    const context = await browser.newContext({ viewport: { width: 1440, height: 900 }, acceptDownloads: true });
    const first = await context.newPage();
    const second = await context.newPage();
    await Promise.all([first.goto(`${origin}/studio-demo`), second.goto(`${origin}/studio-demo`)]);
    await Promise.all([
      first.locator(".studio-slide-link").first().waitFor(),
      second.locator(".studio-slide-link").first().waitFor(),
    ]);
    assert.equal(await first.locator(".studio-slide-link").count(), 7);
    await first.getByRole("button", { name: "Publish locally" }).click();
    await first.waitForFunction((key) => JSON.parse(localStorage.getItem(key) ?? "null")?.revision === 1, STATE_KEY);
    await second.getByText("Updated in another tab").waitFor();
    assert.equal(await second.getByRole("button", { name: "Publish locally" }).isDisabled(), true);

    const current = await context.newPage();
    await current.goto(`${origin}/studio-demo`);
    const headline = current.getByRole("textbox", { name: "Headline", exact: true });
    await headline.waitFor();
    await headline.fill("A safer second draft");
    await current.getByRole("button", { name: "Save draft" }).click();
    await current.waitForFunction((key) => JSON.parse(localStorage.getItem(key) ?? "null")?.revision === 2, STATE_KEY);
    await first.getByText("Updated in another tab").waitFor();
    assert.equal(await first.getByRole("button", { name: "Publish locally" }).isDisabled(), true);

    const snapshot = await current.evaluate((key) => JSON.parse(localStorage.getItem(key)!), STATE_KEY);
    assert.equal(snapshot.draft.slides[0].title, "A safer second draft");
    assert.notEqual(snapshot.published.slides[0].title, "A safer second draft");

    await current.getByRole("tab", { name: "Media", exact: true }).click();
    await current.locator('#studio-quick-media input[type="file"][accept^="image/jpeg"]').first().setInputFiles("public/template/split-portrait.webp");
    await current.waitForFunction(() => { const photo = document.querySelector(".sw-photo"); return photo instanceof Element && getComputedStyle(photo).backgroundImage.includes("blob:"); });
    await current.getByRole("button", { name: "Save draft" }).click();
    await current.waitForFunction((key) => JSON.parse(localStorage.getItem(key)!)?.revision === 3, STATE_KEY);
    const originalId = await current.evaluate((key) => JSON.parse(localStorage.getItem(key)!).draft.slides[0].image, STATE_KEY);
    assert.ok(originalId.startsWith("local-media:"));
    await current.evaluate((key) => {
      const slideId = JSON.parse(localStorage.getItem(key)!).draft.slides[0].id;
      localStorage.setItem("slides-website:personal:crm:v1", JSON.stringify([{
        id: crypto.randomUUID(), createdAt: new Date().toISOString(), kind: "pathway", name: "Included contact",
        email: "included@example.org", message: "", slideId, slideTitle: "First slide", choiceId: "next", choiceLabel: "A next step",
        stage: "new", notes: "Private follow-up",
      }]));
    }, STATE_KEY);
    await current.getByRole("button", { name: "Project options" }).click();
    const downloadPromise = current.waitForEvent("download");
    await current.getByRole("button", { name: "Export ZIP" }).click();
    const backup = await downloadPromise;
    const backupPath = await backup.path();
    assert.ok(backupPath);
    const libraryBeforeImport = await current.evaluate(() => JSON.parse(localStorage.getItem("slides-website:personal:library:v1")!));
    assert.ok(libraryBeforeImport.some((asset: { url: string }) => asset.url === originalId), "Uploaded photos must be indexed in the reusable library");
    await current.evaluate(() => {
      const key = "slides-website:personal:crm:v1";
      const unrelated = JSON.parse(localStorage.getItem(key)!);
      unrelated[0].name = "Unrelated project contact";
      localStorage.setItem(key, JSON.stringify(unrelated));
    });
    current.once("dialog", (dialog) => void dialog.accept());
    await current.locator('input[type="file"][accept*="zip"]').setInputFiles(backupPath);
    await current.waitForFunction((key) => JSON.parse(localStorage.getItem(key)!)?.revision === 4, STATE_KEY);
    const importedId = await current.evaluate((key) => JSON.parse(localStorage.getItem(key)!).draft.slides[0].image, STATE_KEY);
    assert.ok(importedId.startsWith("local-media:"));
    assert.notEqual(importedId, originalId, "An import must never overwrite a media ID already in this browser");
    const libraryAfterImport = await current.evaluate(() => JSON.parse(localStorage.getItem("slides-website:personal:library:v1")!));
    assert.ok(libraryAfterImport.some((asset: { url: string }) => asset.url === importedId), "Backup import must restore library entries with remapped media IDs");
    assert.equal(await current.evaluate(() => JSON.parse(localStorage.getItem("slides-website:personal:crm:v1")!)[0].name), "Included contact", "Imported CRM must replace old unrelated contacts");
    await current.reload();
    await current.waitForFunction(() => { const photo = document.querySelector(".sw-photo"); return photo instanceof Element && getComputedStyle(photo).backgroundImage.includes("blob:"); });
    assert.equal(await current.locator(".studio-slide-link").count(), 7);
    await current.evaluate(async (id) => new Promise<void>((resolve, reject) => {
      const opening = indexedDB.open("slides-website:personal-media:v1");
      opening.onsuccess = () => {
        const transaction = opening.result.transaction("assets", "readwrite");
        const store = transaction.objectStore("assets");
        const record = store.get(id);
        record.onsuccess = () => { store.put({ ...record.result, createdAt: Date.now() - 2 * 86400000 }, id); };
        transaction.oncomplete = () => resolve(); transaction.onerror = () => reject(transaction.error);
      };
      opening.onerror = () => reject(opening.error);
    }), originalId);
    await current.getByRole("tab", { name: "Text", exact: true }).click();
    await current.getByRole("textbox", { name: "Headline", exact: true }).fill("A safer third draft");
    await current.getByRole("button", { name: "Save draft" }).click();
    await current.waitForFunction((key) => JSON.parse(localStorage.getItem(key)!)?.revision === 5, STATE_KEY);
    await current.waitForFunction(async (id) => new Promise<boolean>((resolve) => {
      const opening = indexedDB.open("slides-website:personal-media:v1");
      opening.onsuccess = () => {
        const request = opening.result.transaction("assets", "readonly").objectStore("assets").get(id);
        request.onsuccess = () => resolve(!request.result);
        request.onerror = () => resolve(false);
      };
      opening.onerror = () => resolve(false);
    }), originalId);
    assert.equal((await current.evaluate((key) => JSON.parse(localStorage.getItem(key)!).draft.slides[0].image, STATE_KEY)), importedId);
    await context.close();
    console.log("Browser-local revisions, draft/publication split, ZIP media remapping, reload and orphan cleanup verified");
  } finally { await browser.close(); }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
