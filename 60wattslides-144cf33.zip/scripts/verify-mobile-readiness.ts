import assert from "node:assert/strict";
import { chromium, type Locator } from "playwright-core";

const origin = process.env.PREVIEW_URL ?? "https://8328-in4uy4c7zi9g0qj8fh1nj-cc83b7a5.us1.manus.computer";

async function assertMinHeight(locator: Locator, expected: number, label: string) {
  const box = await locator.boundingBox();
  assert.ok(box && box.height >= expected - 0.5, `${label} should be at least ${expected}px tall; received ${box?.height ?? 0}px`);
}

async function main() {
  const browser = await chromium.launch({ executablePath: "/usr/bin/chromium", headless: true, args: ["--no-sandbox"] });
  try {
    const context = await browser.newContext({ viewport: { width: 390, height: 844 } });
    const page = await context.newPage();

    await page.goto(`${origin}/`);
    await page.locator(".sw-site").waitFor();
    assert.equal(await page.locator('meta[name="viewport"]').getAttribute("content"), "width=device-width, initial-scale=1");
    const publicViewport = await page.evaluate(() => ({ width: document.documentElement.clientWidth, scroll: document.documentElement.scrollWidth }));
    assert.ok(publicViewport.scroll <= publicViewport.width + 2, `Public site overflows horizontally: ${publicViewport.scroll} > ${publicViewport.width}`);
    await assertMinHeight(page.locator(".sw-arrow--next"), 44, "Public next-slide control");
    await assertMinHeight(page.locator(".sw-progress button").first(), 44, "Public progress control");
    await assertMinHeight(page.locator(".sw-search button"), 44, "Public search submit control");
    assert.ok(Number.parseFloat(await page.locator(".sw-search input").evaluate((element) => getComputedStyle(element).fontSize)) >= 16, "Public search input should stay at 16px or larger");

    await page.goto(`${origin}/studio-demo`);
    await page.locator(".studio-slide-link").first().waitFor();
    const edit = page.getByRole("button", { name: "Edit text, media & buttons", exact: false });
    if (await edit.isVisible()) await edit.click();
    await page.getByRole("tab", { name: "Text", exact: true }).waitFor();
    await assertMinHeight(page.locator(".studio-canvas-toolbar").getByRole("button", { name: "Next slide" }), 44, "CMS next-slide control");
    await assertMinHeight(page.getByRole("tab", { name: "Text", exact: true }), 44, "CMS text tab");
    const headline = page.getByRole("textbox", { name: "Headline", exact: true });
    await assertMinHeight(headline, 44, "CMS headline field");
    assert.ok(Number.parseFloat(await headline.evaluate((element) => getComputedStyle(element).fontSize)) >= 16, "CMS fields should stay at 16px or larger");

    await page.getByRole("button", { name: "Media Library" }).click();
    await page.locator(".media-workspace").waitFor();
    await assertMinHeight(page.getByRole("button", { name: "Embed YouTube" }), 44, "Media Library YouTube action");
    const mediaSearch = page.getByPlaceholder("Search media");
    await assertMinHeight(mediaSearch, 44, "Media Library search field");
    assert.ok(Number.parseFloat(await mediaSearch.evaluate((element) => getComputedStyle(element).fontSize)) >= 16, "Media Library fields should stay at 16px or larger");

    await page.getByRole("button", { name: "Site Settings" }).click();
    await page.locator(".settings-workspace").waitFor();
    assert.equal(await page.locator(".settings-preview").isVisible(), true, "Site Settings should retain a live preview on phones");
    const settingsField = page.getByLabel("Company name");
    await assertMinHeight(settingsField, 44, "Site Settings company-name field");
    assert.ok(Number.parseFloat(await settingsField.evaluate((element) => getComputedStyle(element).fontSize)) >= 16, "Site Settings fields should stay at 16px or larger");
    const cmsViewport = await page.evaluate(() => ({ width: document.documentElement.clientWidth, scroll: document.documentElement.scrollWidth }));
    assert.ok(cmsViewport.scroll <= cmsViewport.width + 2, `CMS overflows horizontally: ${cmsViewport.scroll} > ${cmsViewport.width}`);

    await context.close();
    console.log("Mobile readiness: viewport, overflow, public controls, CMS fields, library actions and Settings preview verified");
  } finally {
    await browser.close();
  }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
