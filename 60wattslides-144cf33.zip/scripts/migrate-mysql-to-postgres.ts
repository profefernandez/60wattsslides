import mysql, { type RowDataPacket } from "mysql2/promise";
import postgres from "postgres";

type SourceRow = RowDataPacket & Record<string, unknown>;
const tables = ["customer_decks", "stripe_events", "customer_assets", "crm_leads", "media_assets", "customer_domain_requests"] as const;
const asJson = (value: unknown) => typeof value === "string" ? value : JSON.stringify(value);
const asDate = (value: unknown) => value instanceof Date ? value.toISOString() : typeof value === "string" ? value : new Date().toISOString();
const asString = (value: unknown) => value === null || value === undefined ? "" : String(value);

async function main() {
  const sourceUrl = process.env.MYSQL_SOURCE_URL;
  const targetUrl = process.env.POSTGRES_URL;
  const apply = process.argv.includes("--apply");
  if (!sourceUrl?.startsWith("mysql")) throw new Error("MYSQL_SOURCE_URL is required for a MySQL source database");
  if (!targetUrl?.match(/^postgres(?:ql)?:\/\//i)) throw new Error("POSTGRES_URL is required for the PostgreSQL target database");
  const source = await mysql.createConnection(sourceUrl);
  const target = postgres(targetUrl, { max: 1, connect_timeout: 10 });
  try {
    const data: Record<string, SourceRow[]> = {};
    for (const table of tables) {
      const [rows] = await source.query<SourceRow[]>(`SELECT * FROM \`${table}\``);
      data[table] = rows;
      console.log(`${table}: ${rows.length} source row(s)`);
    }
    if (!apply) {
      console.log("Dry run only. Review the counts, back up both databases, freeze MySQL writers, then rerun with --apply.");
      return;
    }
    await target.begin(async (tx) => {
      for (const row of data.customer_decks) {
        await tx`
          INSERT INTO customer_decks (user_id,slug,draft_json,draft_revision,published_json,entitlement_status,stripe_customer_id,stripe_subscription_id,stripe_checkout_session_id,stripe_checkout_expires_at)
          VALUES (${asString(row.user_id)},${asString(row.slug)},${asJson(row.draft_json)}::jsonb,${Number(row.draft_revision ?? 0)},${row.published_json ? asJson(row.published_json) : null}::jsonb,${asString(row.entitlement_status || "none")},${row.stripe_customer_id ? asString(row.stripe_customer_id) : null},${row.stripe_subscription_id ? asString(row.stripe_subscription_id) : null},${row.stripe_checkout_session_id ? asString(row.stripe_checkout_session_id) : null},${Number(row.stripe_checkout_expires_at ?? 0)})
          ON CONFLICT (user_id) DO UPDATE SET
            slug=EXCLUDED.slug,draft_json=EXCLUDED.draft_json,draft_revision=EXCLUDED.draft_revision,published_json=EXCLUDED.published_json,
            entitlement_status=EXCLUDED.entitlement_status,stripe_customer_id=EXCLUDED.stripe_customer_id,stripe_subscription_id=EXCLUDED.stripe_subscription_id,
            stripe_checkout_session_id=EXCLUDED.stripe_checkout_session_id,stripe_checkout_expires_at=EXCLUDED.stripe_checkout_expires_at
        `;
      }
      for (const row of data.stripe_events) {
        await tx`INSERT INTO stripe_events (event_id,processed_at) VALUES (${asString(row.event_id)},${asDate(row.processed_at)}) ON CONFLICT (event_id) DO NOTHING`;
      }
      for (const row of data.customer_assets) {
        await tx`INSERT INTO customer_assets (user_id,asset_path,content_type,created_at) VALUES (${asString(row.user_id)},${asString(row.asset_path)},${asString(row.content_type)},${asDate(row.created_at)})`;
      }
      for (const row of data.crm_leads) {
        await tx`
          INSERT INTO crm_leads (id,user_id,slide_id,slide_title,kind,display_name,email,message,choice_id,choice_label,booking_key,stage,notes,created_at)
          VALUES (${asString(row.id)}::uuid,${asString(row.user_id)},${asString(row.slide_id)},${asString(row.slide_title)},${asString(row.kind)},${asString(row.display_name)},${asString(row.email)},${asString(row.message)},${asString(row.choice_id)},${asString(row.choice_label)},${row.booking_key ? asString(row.booking_key) : null},${asString(row.stage || "new")},${asString(row.notes)},${asDate(row.created_at)})
          ON CONFLICT (id) DO UPDATE SET stage=EXCLUDED.stage,notes=EXCLUDED.notes,message=EXCLUDED.message,choice_label=EXCLUDED.choice_label
        `;
      }
      for (const row of data.media_assets) {
        await tx`
          INSERT INTO media_assets (id,user_id,kind,title,asset_url,alt_text,created_at)
          VALUES (${asString(row.id)}::uuid,${asString(row.user_id)},${asString(row.kind)},${asString(row.title)},${asString(row.asset_url)},${asString(row.alt_text)},${asDate(row.created_at)})
          ON CONFLICT (id) DO UPDATE SET title=EXCLUDED.title,asset_url=EXCLUDED.asset_url,alt_text=EXCLUDED.alt_text
        `;
      }
      for (const row of data.customer_domain_requests) {
        await tx`
          INSERT INTO customer_domain_requests (user_id,hostname,status,created_at,updated_at)
          VALUES (${asString(row.user_id)},${asString(row.hostname)},${asString(row.status || "awaiting-platform-connection")},${asDate(row.created_at)},${asDate(row.updated_at)})
          ON CONFLICT (user_id) DO UPDATE SET hostname=EXCLUDED.hostname,status=EXCLUDED.status
        `;
      }
    });
    console.log("MySQL CMS records imported into PostgreSQL. Keep MySQL writes frozen until the new app passes verification.");
  } finally {
    await source.end();
    await target.end({ timeout: 5 });
  }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
