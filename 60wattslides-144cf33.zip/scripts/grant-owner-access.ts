import { closeDatabase, database, ownDeck } from "../src/template/db.server";

async function main() {
  const userId = process.env.OWNER_SUPABASE_USER_ID?.trim();
  if (!userId || userId.length > 128) throw new Error("OWNER_SUPABASE_USER_ID is required and must be a valid Supabase user ID");
  try {
    const account = await ownDeck(userId);
    await database()`UPDATE customer_decks SET entitlement_status='active' WHERE user_id=${userId}`;
    console.log(`Owner CMS access is active for ${account.slug}`);
  } finally {
    await closeDatabase();
  }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
