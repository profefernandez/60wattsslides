import postgres from "postgres";

const requiredColumns: Record<string, string[]> = {
  customer_decks: ["user_id", "slug", "draft_json", "draft_revision", "published_json", "entitlement_status", "stripe_customer_id", "stripe_subscription_id", "stripe_checkout_session_id", "stripe_checkout_expires_at"],
  stripe_events: ["event_id", "processed_at"],
  customer_assets: ["id", "user_id", "asset_path", "content_type", "created_at"],
  crm_leads: ["id", "user_id", "slide_id", "kind", "email", "booking_key", "stage", "created_at"],
  media_assets: ["id", "user_id", "kind", "asset_url", "alt_text", "created_at"],
  customer_domain_requests: ["user_id", "hostname", "status", "created_at", "updated_at"],
};
const requiredIndexes = ["idx_customer_decks_stripe_customer", "idx_customer_decks_stripe_subscription", "idx_customer_assets_user", "idx_crm_owner_created", "idx_crm_capacity", "idx_media_owner_created"];
const requiredTriggers = ["customer_decks_set_updated_at", "customer_domain_requests_set_updated_at"];

async function main() {
  const url = process.env.POSTGRES_URL;
  if (!url) throw new Error("POSTGRES_URL is required");
  const sql = postgres(url, { max: 1, connect_timeout: 10 });
  try {
    await sql`SELECT 1`;
    const columns = await sql<{ table_name: string; column_name: string }[]>`
      SELECT table_name,column_name FROM information_schema.columns
      WHERE table_schema=current_schema() AND table_name = ANY(${Object.keys(requiredColumns)})
    `;
    const columnSet = new Set(columns.map((row) => `${row.table_name}.${row.column_name}`));
    const missingColumns = Object.entries(requiredColumns).flatMap(([table, names]) => names.filter((name) => !columnSet.has(`${table}.${name}`)).map((name) => `${table}.${name}`));
    if (missingColumns.length) throw new Error(`PostgreSQL CMS schema is incomplete: missing ${missingColumns.join(", ")}. Run npm run db:setup during a controlled maintenance window.`);
    const indexes = await sql<{ indexname: string }[]>`
      SELECT indexname FROM pg_indexes WHERE schemaname=current_schema() AND indexname = ANY(${requiredIndexes})
    `;
    const indexSet = new Set(indexes.map((row) => row.indexname));
    const missingIndexes = requiredIndexes.filter((name) => !indexSet.has(name));
    if (missingIndexes.length) throw new Error(`PostgreSQL CMS schema is incomplete: missing index ${missingIndexes.join(", ")}. Run npm run db:setup during a controlled maintenance window.`);
    const triggers = await sql<{ tgname: string }[]>`
      SELECT tgname FROM pg_trigger WHERE NOT tgisinternal AND tgname = ANY(${requiredTriggers})
    `;
    const triggerSet = new Set(triggers.map((row) => row.tgname));
    const missingTriggers = requiredTriggers.filter((name) => !triggerSet.has(name));
    if (missingTriggers.length) throw new Error(`PostgreSQL CMS schema is incomplete: missing trigger ${missingTriggers.join(", ")}. Run npm run db:setup during a controlled maintenance window.`);
    console.log(`PostgreSQL is reachable and the ${Object.keys(requiredColumns).length} CMS tables, indexes, and triggers are ready`);
  } finally {
    await sql.end({ timeout: 5 });
  }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
