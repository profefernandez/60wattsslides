import assert from "node:assert/strict";
import { chromium } from "playwright-core";

const origin = process.env.PREVIEW_URL ?? "https://8328-in4uy4c7zi9g0qj8fh1nj-cc83b7a5.us1.manus.computer";

type Surface = { background: string; radius: string; borderTop: string; borderBottom: string };
async function styleOf(page: import("playwright-core").Page, selector: string): Promise<Surface> {
  return page.locator(selector).first().evaluate((element) => {
    const style = getComputedStyle(element);
    return { background: style.backgroundColor, radius: style.borderRadius, borderTop: style.borderTopWidth, borderBottom: style.borderBottomWidth };
  });
}

async function main() {
  const browser = await chromium.launch({ executablePath: "/usr/bin/chromium", headless: true, args: ["--no-sandbox"] });
  try {
    const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
    const page = await context.newPage();
    await page.goto(`${origin}/`);
    await page.locator(".sw-site").waitFor();
    await page.waitForTimeout(700);
    await page.getByRole("button", { name: "Go to slide 4" }).click();
    await page.locator(".sw-items--programs .sw-item").first().waitFor();
    assert.equal(await page.locator(".sw-items--programs .sw-item").count(), 3);
    assert.equal(await page.locator(".sw-items--programs .sw-item-marker span").count(), 3);
    const program = await styleOf(page, ".sw-items--programs .sw-item");
    assert.equal(program.background, "rgba(0, 0, 0, 0)");
    assert.equal(program.radius, "0px");
    assert.equal(program.borderTop, "0px");

    await page.getByRole("button", { name: "Go to slide 5" }).click();
    await page.locator(".sw-items--workshops .sw-item").first().waitFor();
    const workshop = await styleOf(page, ".sw-items--workshops .sw-item");
    assert.equal(workshop.background, "rgba(0, 0, 0, 0)");
    assert.equal(workshop.radius, "0px");
    assert.equal(workshop.borderBottom, "1px");

    await page.getByRole("button", { name: "Go to slide 6" }).click();
    await page.locator(".sw-items--faq .sw-item").first().waitFor();
    assert.equal(await page.locator(".sw-items--faq .sw-item").count(), 3);
    const question = await styleOf(page, ".sw-items--faq .sw-item");
    assert.equal(question.background, "rgba(0, 0, 0, 0)");
    assert.equal(question.radius, "0px");
    assert.equal(question.borderTop, "1px");

    await page.setViewportSize({ width: 390, height: 844 });
    await page.getByRole("button", { name: "Go to slide 4" }).click();
    const dimensions = await page.evaluate(() => ({ client: document.documentElement.clientWidth, scroll: document.documentElement.scrollWidth }));
    assert.ok(dimensions.scroll <= dimensions.client + 2, `Light Path overflows on mobile: ${dimensions.scroll} > ${dimensions.client}`);
    console.log("Card-free Light Path, session ledger and question field verified on desktop and mobile");
    await context.close();
  } finally { await browser.close(); }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
