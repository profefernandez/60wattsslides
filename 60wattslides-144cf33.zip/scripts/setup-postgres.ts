import { readFileSync } from "node:fs";
import postgres from "postgres";

async function main() {
  const url = process.env.POSTGRES_URL;
  if (!url) throw new Error("POSTGRES_URL is required");
  if (!/^postgres(?:ql)?:\/\//i.test(url)) throw new Error("POSTGRES_URL must be a PostgreSQL connection string");
  const sql = postgres(url, { max: 1, connect_timeout: 10 });
  try {
    await sql.unsafe(readFileSync(new URL("./create-postgres-schema.sql", import.meta.url), "utf8"));
    console.log("PostgreSQL CMS schema is current");
  } finally {
    await sql.end({ timeout: 5 });
  }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
