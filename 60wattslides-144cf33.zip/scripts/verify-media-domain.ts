import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { closeDatabase, database, ownDeck, publishDraft, recordAsset, saveDraft } from "../src/template/db.server";
import { deleteOwnedMedia, listOwnedMedia, registerOwnedUpload, registerOwnedYoutube } from "../src/template/media.server";
import { getOwnerDomainRequest, saveOwnerDomainRequest } from "../src/template/domain.server";

async function main() {
  if (!process.env.POSTGRES_URL) throw new Error("POSTGRES_URL is required for this integration check");
  const alice = `test-media-${randomUUID()}`;
  const bob = `test-media-${randomUUID()}`;
  const db = database();
  try {
    await ownDeck(alice); await ownDeck(bob);
    await db`UPDATE customer_decks SET entitlement_status='active' WHERE user_id IN (${alice},${bob})`;
    const path = `customers/${alice}/${randomUUID()}-portrait.webp`;
    await recordAsset(alice, path, "image/webp");
    const asset = await registerOwnedUpload(alice, `/manus-storage/${path}`, "Portrait", "A person speaking");
    assert.equal(asset.type, "image");
    assert.equal((await listOwnedMedia(alice)).length, 1);
    assert.equal((await listOwnedMedia(bob)).length, 0);
    await assert.rejects(registerOwnedUpload(bob, asset.url, "Not mine"), /does not belong/);
    const video = await registerOwnedYoutube(alice, "https://youtu.be/dQw4w9WgXcQ", "Video example");
    assert.equal(video.type, "youtube");
    const original = await ownDeck(alice);
    const withPhoto = structuredClone(original.deck);
    withPhoto.slides[0]!.image = asset.url;
    const revision = await saveDraft(alice, withPhoto, original.revision);
    await assert.rejects(deleteOwnedMedia(alice, asset.id), /Remove this asset/);
    await publishDraft(alice, withPhoto, revision);
    const withoutPhoto = structuredClone(withPhoto);
    withoutPhoto.slides[0]!.image = "";
    await saveDraft(alice, withoutPhoto, revision + 1);
    await assert.rejects(deleteOwnedMedia(alice, asset.id), /Remove this asset/, "A published site still uses the photo");
    const hostname = `${randomUUID().slice(0, 8)}.example.org`;
    await saveOwnerDomainRequest(alice, hostname);
    assert.equal((await getOwnerDomainRequest(alice))?.status, "awaiting-platform-connection");
    await assert.rejects(saveOwnerDomainRequest(bob, hostname), /already requested/);
    assert.equal(await getOwnerDomainRequest(bob), null);
    await deleteOwnedMedia(alice, video.id);
    console.log("PostgreSQL hosted media ownership, slide usage, and pending-domain isolation verified");
  } finally {
    await db`DELETE FROM customer_domain_requests WHERE user_id IN (${alice},${bob})`;
    await db`DELETE FROM media_assets WHERE user_id IN (${alice},${bob})`;
    await db`DELETE FROM customer_assets WHERE user_id IN (${alice},${bob})`;
    await db`DELETE FROM customer_decks WHERE user_id IN (${alice},${bob})`;
    await closeDatabase();
  }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
