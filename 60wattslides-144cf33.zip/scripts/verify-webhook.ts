import { randomUUID } from "node:crypto";
import assert from "node:assert/strict";
import Stripe from "stripe";
import { closeDatabase, database, ownDeck } from "../src/template/db.server";
import { handleStripeEvent } from "../src/template/stripe-webhook.server";

async function main() {
  if (!process.env.POSTGRES_URL) throw new Error("POSTGRES_URL is required for this integration check");
  const signingSecret = "whsec_local_postgres_webhook_test";
  const oldSecret = process.env.STRIPE_WEBHOOK_SECRET, oldKey = process.env.STRIPE_SECRET_KEY;
  process.env.STRIPE_WEBHOOK_SECRET = signingSecret;
  process.env.STRIPE_SECRET_KEY = "sk_test_local_webhook_signature";
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  const userId = randomUUID();
  const eventIds: string[] = [];
  try {
    await ownDeck(userId);
    const now = Math.floor(Date.now() / 1000);
    async function send(eventStatus: "active" | "canceled", authoritativeStatus: "active" | "canceled", eventId = `evt_test_${randomUUID().replace(/-/g, "")}`) {
      eventIds.push(eventId);
      const payload = JSON.stringify({ id: eventId, object: "event", type: "customer.subscription.updated", created: now, data: { object: { id: "sub_test_signed_event", object: "subscription", customer: "cus_test_signed_event", status: eventStatus, metadata: { user_id: userId } } } });
      const signature = stripe.webhooks.generateTestHeaderString({ payload, secret: signingSecret });
      const options = { stripe, retrieveSubscription: async () => ({ id: "sub_test_signed_event", customer: "cus_test_signed_event", status: authoritativeStatus }) };
      await handleStripeEvent(Buffer.from(payload), signature, options);
      await handleStripeEvent(Buffer.from(payload), signature, options); // exact-event replay is idempotent
    }
    await send("active", "active");
    assert.equal((await ownDeck(userId)).entitlement, "active");
    // Same second, the raw late event says active but Stripe's current state is canceled.
    await send("active", "canceled");
    assert.equal((await ownDeck(userId)).entitlement, "none");
    console.log("Signed webhook replay and same-second authoritative cancellation safety verified");
  } finally {
    if (oldSecret === undefined) delete process.env.STRIPE_WEBHOOK_SECRET; else process.env.STRIPE_WEBHOOK_SECRET = oldSecret;
    if (oldKey === undefined) delete process.env.STRIPE_SECRET_KEY; else process.env.STRIPE_SECRET_KEY = oldKey;
    await database()`DELETE FROM customer_decks WHERE user_id=${userId}`;
    for (const eventId of eventIds) await database()`DELETE FROM stripe_events WHERE event_id=${eventId}`;
    await closeDatabase();
  }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
