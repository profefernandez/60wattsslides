import assert from "node:assert/strict";
import { chromium } from "playwright-core";

const origin = process.env.PREVIEW_URL ?? "https://8328-in4uy4c7zi9g0qj8fh1nj-cc83b7a5.us1.manus.computer";

async function main() {
  const browser = await chromium.launch({ executablePath: "/usr/bin/chromium", headless: true, args: ["--no-sandbox"] });
  try {
    const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
    const page = await context.newPage();
    await page.goto(`${origin}/studio-demo`);
    await page.locator(".studio-slide-link").first().waitFor();
    assert.equal(await page.locator(".studio-slide-link .studio-thumb").count(), 7);
    assert.equal(await page.locator('.studio-inspector-tabs [role="tab"]').count(), 3);
    const thumbnails = await page.locator(".studio-thumb-photo").count();
    assert.ok(thumbnails >= 5, `Expected people and media in at least five thumbnails, found ${thumbnails}`);
    assert.match(await page.locator(".studio-thumb-photo").first().evaluate((el) => getComputedStyle(el).backgroundImage), /split-portrait/);

    await page.locator(".studio-slide-link").nth(4).click();
    assert.match(await page.locator(".studio-preview-head h2").innerText(), /Slide 5 of 7/);
    assert.match(await page.locator(".studio-canvas-count").innerText(), /5 of 7/);
    await page.locator(".studio-canvas-toolbar").getByRole("button", { name: "Next slide" }).click();
    assert.match(await page.locator(".studio-preview-head h2").innerText(), /Slide 6 of 7/);
    await page.locator(".studio-canvas-toolbar").getByRole("button", { name: "Previous slide" }).click();
    assert.match(await page.locator(".studio-preview-head h2").innerText(), /Slide 5 of 7/);

    await page.getByRole("tab", { name: "Media", exact: true }).click();
    await page.getByRole("button", { name: "Choose from Media Library" }).click();
    await page.locator(".media-card").first().waitFor();
    assert.ok((await page.locator(".media-card").count()) >= 7);
    await page.locator(".media-card").filter({ hasText: "Human first" }).first().click();
    await page.getByRole("button", { name: "Use photo on selected slide" }).click();
    assert.match(await page.locator(".studio-quick-current img").getAttribute("src") ?? "", /founder-portrait/);
    assert.match(await page.locator(".studio-preview-head h2").innerText(), /Slide 5 of 7/);

    await page.getByRole("tab", { name: "Buttons", exact: true }).click();
    await page.getByRole("button", { name: "Add CTA button" }).click();
    await page.locator(".studio-quick-button").last().getByLabel("Button label").fill("Meet the founder");
    await page.locator(".studio-quick-button").last().locator("select").first().selectOption("#slide:founder");
    await page.getByRole("button", { name: "Save draft" }).click();
    const snapshot = await page.evaluate(() => JSON.parse(localStorage.getItem("slides-website:personal:project:v2")!).draft);
    assert.match(snapshot.slides[4].image, /founder-portrait/);
    assert.equal(snapshot.slides[4].ctaButtons.at(-1).url, "#slide:founder");

    await page.getByRole("button", { name: "Change layout" }).click();
    assert.equal(await page.locator(".studio-layout-gallery button").count(), 13);
    await page.getByRole("button", { name: /Portrait story/ }).click();
    assert.match(await page.locator(".studio-preview-head h2").innerText(), /Slide 5 of 7/);
    await page.getByRole("tab", { name: "Media", exact: true }).click();
    assert.match(await page.locator(".studio-quick-current img").getAttribute("src") ?? "", /founder-portrait/);

    await page.setViewportSize({ width: 390, height: 844 });
    await page.reload();
    await page.getByRole("button", { name: "Edit text, media & buttons", exact: false }).waitFor();
    await page.getByRole("button", { name: "Edit text, media & buttons", exact: false }).click();
    assert.equal(await page.getByRole("tab", { name: "Text", exact: true }).isVisible(), true);
    const viewport = await page.evaluate(() => ({ width: document.documentElement.clientWidth, scroll: document.documentElement.scrollWidth }));
    assert.ok(viewport.scroll <= viewport.width + 2, `Phone UI overflows horizontally: ${viewport.scroll} > ${viewport.width}`);
    console.log("Reference-led CMS: photo thumbnails, slide navigation, reuse, CTA and phone inspector verified");
    await context.close();
  } finally { await browser.close(); }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
