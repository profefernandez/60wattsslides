import { randomUUID } from "node:crypto";
import assert from "node:assert/strict";
import { closeDatabase, database, ownDeck, publishDraft } from "../src/template/db.server";

async function main() {
  if (!process.env.POSTGRES_URL) throw new Error("POSTGRES_URL is required for this integration check");
  const origin = process.env.APP_ORIGIN ?? "http://127.0.0.1:3000";
  const userId = randomUUID();
  try {
    const draft = await ownDeck(userId);
    await database()`UPDATE customer_decks SET entitlement_status='active' WHERE user_id=${userId}`;
    await publishDraft(userId, draft.deck, draft.revision);
    const published = await fetch(`${origin}/s/${draft.slug}`);
    const body = await published.text();
    assert.equal(published.status, 200);
    assert.match(body, /Learn it\./);
    assert.match(body, /60 WATTS OF CLARITY/);
    assert.match(body, /og:title/);
    const unknown = await fetch(`${origin}/s/site-missing-${randomUUID().slice(0, 8)}`);
    assert.equal(unknown.status, 404);
    console.log("PostgreSQL published-site SSR content, metadata and missing-site HTTP 404 verified");
  } finally {
    await database()`DELETE FROM customer_decks WHERE user_id=${userId}`;
    await closeDatabase();
  }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
