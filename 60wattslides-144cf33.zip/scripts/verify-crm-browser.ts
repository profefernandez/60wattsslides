import assert from "node:assert/strict";
import { chromium } from "playwright-core";

const origin = process.env.PREVIEW_URL ?? "http://127.0.0.1:3000";
const inLocalTime = (date: Date) => {
  const pad = (value: number) => String(value).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
};
async function main() {
  const browser = await chromium.launch({ executablePath: "/usr/bin/chromium", headless: true, args: ["--no-sandbox"] });
  try {
    const context = await browser.newContext({ viewport: { width: 1500, height: 980 } });
    const page = await context.newPage();
    await page.goto(`${origin}/studio-demo`);
    await page.getByRole("button", { name: "Add a slide" }).click();
    await page.getByRole("button", { name: /Book a workshop/ }).click();
    assert.equal(await page.locator(".studio-slide-link").count(), 8);
    assert.equal(await page.locator(".sw-conversion-form").count(), 0, "Editing previews must not capture test contacts");
    await page.getByRole("textbox", { name: "Workshop name" }).fill("Practical AI workshop");
    await page.getByLabel("Date and start time").fill(inLocalTime(new Date(Date.now() + 3 * 86400000)));
    await page.getByRole("checkbox", { name: "Visible on website" }).check();
    await page.getByRole("button", { name: "Add a slide" }).click();
    await page.getByRole("button", { name: /A path made for you/ }).click();
    await page.getByRole("checkbox", { name: "Visible on website" }).check();
    await page.getByRole("button", { name: "Save draft" }).click();
    await page.getByRole("button", { name: "Publish locally" }).click();
    await page.waitForFunction(() => JSON.parse(localStorage.getItem("slides-website:personal:project:v2")!)?.published?.slides?.length === 9);
    await page.goto(`${origin}/my-site`);
    const layouts = await page.evaluate(() => JSON.parse(localStorage.getItem("slides-website:personal:project:v2")!).published.slides.map((slide: { layout: string }) => slide.layout) as string[]);
    await page.locator(".sw-progress button").nth(layouts.indexOf("booking")).click();
    await page.getByRole("button", { name: /Practical AI workshop/ }).click();
    await page.getByRole("textbox", { name: "Your name" }).fill("Visitor Test");
    await page.getByRole("textbox", { name: "Email address" }).fill("visitor@example.test");
    await page.getByRole("checkbox", { name: /I agree to share/ }).check();
    await page.getByRole("button", { name: "Request my place" }).click();
    await page.getByText("Request received.", { exact: false }).waitFor();
    await page.locator(".sw-progress button").nth(layouts.indexOf("pathway")).click();
    await page.getByRole("button", { name: /Try it with my team/ }).click();
    await page.getByText("Learn together using examples from your work.").waitFor();
    await page.getByRole("textbox", { name: "Your name" }).fill("Second Visitor");
    await page.getByRole("textbox", { name: "Email address" }).fill("path@example.test");
    await page.getByRole("checkbox", { name: /I agree to share/ }).check();
    await page.getByRole("button", { name: "Save my request" }).click();
    await page.getByText("Your follow-up request is saved.", { exact: false }).waitFor();
    await page.goto(`${origin}/studio-demo`);
    await page.getByRole("button", { name: "CRM", exact: true }).click();
    await page.locator(".crm-list>button").first().waitFor();
    assert.equal(await page.locator(".crm-list>button").count(), 2);
    await page.getByRole("button", { name: "Workshops" }).click();
    assert.equal(await page.locator(".crm-list>button").count(), 1);
    await page.locator(".crm-list>button").first().click();
    await page.getByRole("combobox", { name: "Stage" }).selectOption("contacted");
    await page.getByRole("textbox", { name: "Private notes" }).fill("Follow up about accessibility needs.");
    await page.getByRole("button", { name: "Save contact" }).click();
    await page.getByText("Contact updated.").waitFor();
    const leads = await page.evaluate(() => JSON.parse(localStorage.getItem("slides-website:personal:crm:v1")!));
    assert.equal(leads.length, 2);
    assert.ok(leads.some((lead: { kind: string; stage: string; notes: string }) => lead.kind === "booking" && lead.stage === "contacted" && lead.notes.includes("accessibility")));
    await page.getByRole("button", { name: "Open source slide" }).click();
    const selectedLayout = await page.evaluate(() => {
      const project = JSON.parse(localStorage.getItem("slides-website:personal:project:v2")!);
      const current = document.querySelector('.studio-slide-link[aria-current="page"]');
      const index = [...document.querySelectorAll(".studio-slide-link")].indexOf(current!);
      return project.draft.slides[index].layout;
    });
    assert.equal(selectedLayout, "booking");
    await context.close();
    console.log("Workshop booking, tailored path, slide selection and personal CRM verified in an isolated browser");
  } finally { await browser.close(); }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
