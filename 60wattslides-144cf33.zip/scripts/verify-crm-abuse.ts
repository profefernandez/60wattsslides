import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { closeDatabase, database, ownDeck, publishDraft } from "../src/template/db.server";
import { newSlide } from "../src/template/deck";
import { getHostedLeads, submitHostedLead, updateHostedLead } from "../src/template/crm.server";

async function main() {
  if (!process.env.POSTGRES_URL) throw new Error("POSTGRES_URL is required for this integration check");
  const owner = `test-crm-${randomUUID()}`;
  const db = database();
  try {
    const account = await ownDeck(owner);
    await db`UPDATE customer_decks SET entitlement_status='active' WHERE user_id=${owner}`;
    const deck = structuredClone(account.deck);
    const booking = newSlide("booking", deck.slides.length);
    booking.visible = true;
    booking.bookingSlots = [{ id: "one-seat", label: "One-seat workshop", startsAt: new Date(Date.now() + 86400000).toISOString(), capacity: 1 }];
    deck.slides.push(booking);
    await publishDraft(owner, deck, account.revision);
    const request = (email: string) => submitHostedLead({
      slug: account.slug, slideId: booking.id, kind: "booking", choiceId: "one-seat",
      name: "Test Visitor", email, message: "", consent: true, website: "",
    });
    for (let i = 0; i < 5; i++) await request(`visit${i}@example.org`);
    assert.equal((await getHostedLeads(owner)).length, 5, "Requests do not silently become reserved seats");
    await assert.rejects(request("visit5@example.org"), /many requests/);
    const leads = await getHostedLeads(owner);
    await updateHostedLead(owner, leads[0]!.id, "confirmed", "Owner verified this attendee");
    await assert.rejects(updateHostedLead(owner, leads[1]!.id, "confirmed", "Another seat"), /confirmed seats left/);
    assert.equal((await getHostedLeads(owner)).filter((lead) => lead.stage === "confirmed").length, 1);
    console.log("PostgreSQL workshop intake rate limit and confirmed-seat capacity verified");
  } finally {
    await db`DELETE FROM crm_leads WHERE user_id=${owner}`;
    await db`DELETE FROM customer_decks WHERE user_id=${owner}`;
    await closeDatabase();
  }
}
main().catch((error) => { console.error(error); process.exitCode = 1; });
