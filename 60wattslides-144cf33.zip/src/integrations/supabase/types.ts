export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      content_versions: {
        Row: {
          author_email: string
          created_at: string
          created_by: string | null
          id: string
          snapshot: Json
        }
        Insert: {
          author_email?: string
          created_at?: string
          created_by?: string | null
          id?: string
          snapshot: Json
        }
        Update: {
          author_email?: string
          created_at?: string
          created_by?: string | null
          id?: string
          snapshot?: Json
        }
        Relationships: []
      }
      crm_contacts: {
        Row: {
          board: Json
          consent_at: string | null
          created_at: string
          delivery: string
          email: string
          expires_at: string | null
          id: string
          marketing_consent: boolean
          name: string
          notes: string
          organization: string
          pdf_path: string
          phone: string
          source: string
          status: string
          tags: string[]
          updated_at: string
        }
        Insert: {
          board?: Json
          consent_at?: string | null
          created_at?: string
          delivery?: string
          email?: string
          expires_at?: string | null
          id?: string
          marketing_consent?: boolean
          name?: string
          notes?: string
          organization?: string
          pdf_path?: string
          phone?: string
          source?: string
          status?: string
          tags?: string[]
          updated_at?: string
        }
        Update: {
          board?: Json
          consent_at?: string | null
          created_at?: string
          delivery?: string
          email?: string
          expires_at?: string | null
          id?: string
          marketing_consent?: boolean
          name?: string
          notes?: string
          organization?: string
          pdf_path?: string
          phone?: string
          source?: string
          status?: string
          tags?: string[]
          updated_at?: string
        }
        Relationships: []
      }
      document_submissions: {
        Row: {
          created_at: string
          email: string
          expires_at: string
          id: string
          name: string
          slide_id: string
        }
        Insert: {
          created_at?: string
          email: string
          expires_at?: string
          id?: string
          name: string
          slide_id: string
        }
        Update: {
          created_at?: string
          email?: string
          expires_at?: string
          id?: string
          name?: string
          slide_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "document_submissions_slide_id_fkey"
            columns: ["slide_id"]
            isOneToOne: false
            referencedRelation: "slides"
            referencedColumns: ["id"]
          },
        ]
      }
      media_assets: {
        Row: {
          created_at: string
          folder: string
          name: string
          tags: string[]
        }
        Insert: {
          created_at?: string
          folder?: string
          name: string
          tags?: string[]
        }
        Update: {
          created_at?: string
          folder?: string
          name?: string
          tags?: string[]
        }
        Relationships: []
      }
      search_chunks: {
        Row: {
          anchor_id: string
          content: string
          content_hash: string
          embedding: string
          slide_id: string
          updated_at: string
        }
        Insert: {
          anchor_id: string
          content: string
          content_hash: string
          embedding: string
          slide_id: string
          updated_at?: string
        }
        Update: {
          anchor_id?: string
          content?: string
          content_hash?: string
          embedding?: string
          slide_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "search_chunks_slide_id_fkey"
            columns: ["slide_id"]
            isOneToOne: false
            referencedRelation: "slides"
            referencedColumns: ["id"]
          },
        ]
      }
      site_settings: {
        Row: {
          annotation_color: string
          annotation_display: string
          annotation_icon: string
          annotation_label: string
          annotation_mode: string
          annotation_shape: string
          annotation_style: string
          answer_template: Json
          app_name: string
          autoplay_seconds: number
          chat_placeholder: string
          chat_style: Json
          id: number
          lead_retention_months: number
          system_prompt: string
        }
        Insert: {
          annotation_color?: string
          annotation_display?: string
          annotation_icon?: string
          annotation_label?: string
          annotation_mode?: string
          annotation_shape?: string
          annotation_style?: string
          answer_template?: Json
          app_name?: string
          autoplay_seconds?: number
          chat_placeholder?: string
          chat_style?: Json
          id?: number
          lead_retention_months?: number
          system_prompt?: string
        }
        Update: {
          annotation_color?: string
          annotation_display?: string
          annotation_icon?: string
          annotation_label?: string
          annotation_mode?: string
          annotation_shape?: string
          annotation_style?: string
          answer_template?: Json
          app_name?: string
          autoplay_seconds?: number
          chat_placeholder?: string
          chat_style?: Json
          id?: number
          lead_retention_months?: number
          system_prompt?: string
        }
        Relationships: []
      }
      slides: {
        Row: {
          created_at: string
          document_allowed_types: string[]
          document_download_count: number
          document_expires_at: string | null
          document_max_downloads: number
          document_max_upload_mb: number
          document_name: string
          document_path: string
          document_retention_days: number
          enabled: boolean
          id: string
          items: Json
          kind: string
          media_alt: string
          media_url: string
          overlay_opacity: number
          position: number
          subtitle: string
          subtitle_style: Json
          title: string
          title_style: Json
        }
        Insert: {
          created_at?: string
          document_allowed_types?: string[]
          document_download_count?: number
          document_expires_at?: string | null
          document_max_downloads?: number
          document_max_upload_mb?: number
          document_name?: string
          document_path?: string
          document_retention_days?: number
          enabled?: boolean
          id?: string
          items?: Json
          kind?: string
          media_alt?: string
          media_url?: string
          overlay_opacity?: number
          position?: number
          subtitle?: string
          subtitle_style?: Json
          title?: string
          title_style?: Json
        }
        Update: {
          created_at?: string
          document_allowed_types?: string[]
          document_download_count?: number
          document_expires_at?: string | null
          document_max_downloads?: number
          document_max_upload_mb?: number
          document_name?: string
          document_path?: string
          document_retention_days?: number
          enabled?: boolean
          id?: string
          items?: Json
          kind?: string
          media_alt?: string
          media_url?: string
          overlay_opacity?: number
          position?: number
          subtitle?: string
          subtitle_style?: Json
          title?: string
          title_style?: Json
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      workshop_clicks: {
        Row: {
          created_at: string
          id: string
          session_title: string
          signup_url: string
          slide_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          session_title?: string
          signup_url?: string
          slide_id: string
        }
        Update: {
          created_at?: string
          id?: string
          session_title?: string
          signup_url?: string
          slide_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "workshop_clicks_slide_id_fkey"
            columns: ["slide_id"]
            isOneToOne: false
            referencedRelation: "slides"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      claim_document_download: {
        Args: { _email: string; _name: string; _slide_id: string }
        Returns: {
          file_name: string
          file_path: string
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      match_search_chunks: {
        Args: { match_count?: number; query_embedding: string }
        Returns: {
          anchor_id: string
          content: string
          similarity: number
          slide_id: string
        }[]
      }
    }
    Enums: {
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user"],
    },
  },
} as const
