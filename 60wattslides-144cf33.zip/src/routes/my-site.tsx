import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { SlidesWebsite } from "@/template/renderer";
import { loadPersonalPublished } from "@/template/personal-workspace";
import type { TemplateDeck } from "@/template/deck";

export const Route = createFileRoute("/my-site")({
  head: () => ({ meta: [
    { title: "My private site preview — Slides Website" },
    { name: "robots", content: "noindex" },
  ] }),
  component: MySite,
});

function MySite() {
  const [deck, setDeck] = useState<TemplateDeck | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState("");
  useEffect(() => {
    let mounted = true;
    loadPersonalPublished().then((snapshot) => { if (mounted) { setDeck(snapshot); setLoaded(true); } })
      .catch((cause: unknown) => { if (mounted) { setError(cause instanceof Error ? cause.message : "Could not open your site"); setLoaded(true); } });
    return () => { mounted = false; };
  }, []);
  if (!loaded) return <main role="status" className="grid min-h-screen place-items-center bg-[#173d32] text-white">Opening your private site…</main>;
  if (!deck) return <main className="grid min-h-screen place-items-center bg-[#f8f7f2] p-8 text-[#173d32]"><div className="max-w-lg text-center"><h1 className="text-3xl font-bold">{error || "Nothing published in this browser yet"}</h1><p className="mt-4">Open My Studio, edit a slide and choose Publish locally to create a separate private website preview.</p><a className="mt-6 inline-block rounded bg-[#245c4a] px-5 py-3 text-white" href="/studio-demo">Open My Studio</a></div></main>;
  return <>
    <SlidesWebsite deck={deck} siteSlug="personal" />
    <nav className="fixed left-3 top-28 z-40 flex flex-col items-start gap-2 md:bottom-3 md:top-auto md:flex-row" aria-label="Private preview actions">
      <span className="rounded-full border border-white/50 bg-black/60 px-3 py-1.5 text-[11px] font-semibold text-white backdrop-blur">Private preview · this browser only</span>
      <a className="rounded-full border border-[#e7bc66] bg-[#173d32]/90 px-3 py-1.5 text-[11px] font-semibold text-white backdrop-blur hover:bg-[#173d32]" href="/studio-demo">Edit my site</a>
    </nav>
  </>;
}
