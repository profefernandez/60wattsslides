import { createFileRoute, notFound } from "@tanstack/react-router";
import { SlidesWebsite } from "@/template/renderer";
import { getPublishedDeck } from "@/template/deck.functions";

export const Route = createFileRoute("/s/$slug")({
  loader: async ({ params }) => {
    const deck = await getPublishedDeck({ data: { slug: params.slug } });
    if (!deck) throw notFound();
    return deck;
  },
  head: ({ loaderData }) => {
    const brand = loaderData?.theme.brandName || "Slides Website";
    const description = loaderData?.slides.find((slide) => slide.visible)?.subtitle || `Explore ${brand}'s slide website.`;
    const title = `${brand} — a story in slides`;
    return { meta: [
      { title }, { name: "description", content: description.slice(0, 160) },
      { property: "og:type", content: "website" }, { property: "og:title", content: title },
      { property: "og:description", content: description.slice(0, 160) },
      { name: "twitter:card", content: "summary" }, { name: "twitter:title", content: title },
    ] };
  },
  notFoundComponent: () => <main className="grid min-h-dvh place-items-center bg-[#f8f7f2] px-6 text-center text-[#173d32]"><div><h1 className="text-2xl font-bold">This website is not published</h1><p className="mt-4">The owner may still be working on their slides or their subscription may be inactive.</p></div></main>,
  component: PublishedWebsite,
});

function PublishedWebsite() {
  const deck = Route.useLoaderData();
  return <SlidesWebsite deck={deck} siteSlug={Route.useParams().slug} />;
}
