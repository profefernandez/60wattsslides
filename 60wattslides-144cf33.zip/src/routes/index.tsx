import { createFileRoute } from "@tanstack/react-router";
import { STARTER_DECK } from "@/template/deck";
import { SlidesWebsite } from "@/template/renderer";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Slides Website — a website that tells its story" },
    { name: "description", content: "Explore a complete seven-slide website template and make every photo, word, and design detail your own." },
    { property: "og:title", content: "Slides Website" },
    { property: "og:description", content: "Your website starts finished. Make every slide yours." },
  ] }),
  component: TemplateDemo,
});

function TemplateDemo() {
  return <>
    <SlidesWebsite deck={STARTER_DECK} />
    <nav aria-label="Explore Slides Website" className="fixed left-3 top-28 z-40 flex flex-col items-start gap-2 md:bottom-3 md:top-auto md:flex-row">
      <a href="/studio-demo" className="rounded-full border border-[#e7bc66] bg-[#173d32]/90 px-3 py-1.5 text-[11px] font-semibold text-white backdrop-blur hover:bg-[#173d32]">Open My Studio</a>
      <a href="/auth" className="rounded-full border border-white/40 bg-black/50 px-3 py-1.5 text-[11px] font-semibold text-white backdrop-blur hover:bg-black/80">Make this site yours</a>
    </nav>
  </>;
}
