import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { CustomerEditor } from "@/template/editor";
import { loadPersonalProject } from "@/template/personal-workspace";
import type { OwnDeck } from "@/template/db.server";

type PersonalProject = OwnDeck & { hasSavedDraft: boolean };

export const Route = createFileRoute("/studio-demo")({
  head: () => ({ meta: [
    { title: "My Studio — Slides Website" },
    { name: "description", content: "Make your own interactive slide website in a private browser workspace with saved drafts and media." },
    { name: "robots", content: "noindex" },
  ] }),
  component: PersonalStudio,
});

function PersonalStudio() {
  const [project, setProject] = useState<PersonalProject | null>(null);
  const [error, setError] = useState("");
  useEffect(() => {
    let mounted = true;
    loadPersonalProject().then(({ deck, published, revision, hasSavedDraft }) => {
      if (mounted) setProject({ deck, slug: "personal", entitlement: "none", published, revision, hasSavedDraft });
    }).catch((cause: unknown) => { if (mounted) setError(cause instanceof Error ? cause.message : "Could not open your browser project"); });
    return () => { mounted = false; };
  }, []);
  if (error) return <main className="min-h-screen bg-[#f8f7f2] p-10 text-[#173d32]"><h1 className="text-2xl font-bold">Your browser project needs attention</h1><p className="mt-4 max-w-lg">{error}</p><p className="mt-3">Your saved data has not been deleted. Check that browser storage is enabled, then reload.</p><a href="/" className="mt-6 inline-block underline">View the original template</a></main>;
  if (!project) return <main role="status" className="grid min-h-screen place-items-center bg-[#f8f7f2] text-[#173d32]">Opening your studio…</main>;
  return <CustomerEditor initial={project} refresh={async () => undefined} localMode hasSavedDraft={project.hasSavedDraft} />;
}
