import { createFileRoute } from "@tanstack/react-router";
import Stripe from "stripe";
import { handleStripeEvent } from "@/template/stripe-webhook.server";

export const Route = createFileRoute("/api/stripe/webhook")({
  server: { handlers: {
    POST: async ({ request }) => {
      const signature = request.headers.get("stripe-signature");
      if (!signature) return new Response("Missing signature", { status: 400 });
      try {
        await handleStripeEvent(Buffer.from(await request.arrayBuffer()), signature);
        return new Response("ok", { status: 200 });
      } catch (error) {
        console.error("Stripe webhook failed", error);
        const badSignature = error instanceof Stripe.errors.StripeSignatureVerificationError;
        return new Response("Webhook could not be processed", { status: badSignature ? 400 : 500 });
      }
    },
  } },
});
