import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth")({
  head: () => ({ meta: [
    { title: "Sign in — Slides Website" },
    { name: "description", content: "Sign in to customize and publish your seven-slide website." },
    { name: "robots", content: "noindex" },
  ] }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(event: FormEvent) {
    event.preventDefault(); setBusy(true);
    try {
      if (mode === "in") {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        await navigate({ to: "/admin" });
      } else {
        const { error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: `${window.location.origin}/admin` } });
        if (error) throw error;
        toast.success("Confirm your email, then sign in to open your website."); setMode("in");
      }
    } catch (cause) { toast.error(cause instanceof Error ? cause.message : "Please try again"); }
    finally { setBusy(false); }
  }
  return <div className="flex min-h-dvh bg-[#f8f7f2] font-[Inter] text-[#183d31]"><div className="hidden min-h-dvh w-1/2 flex-col justify-between bg-[#183d31] p-12 text-white lg:flex"><a href="/" className="text-sm font-extrabold tracking-[.25em]">SLIDES WEBSITE</a><div><p className="mb-5 text-xs font-bold tracking-[.3em] text-[#e7bc66]">A DIFFERENT KIND OF WEBSITE</p><h1 className="font-[Manrope] text-6xl font-extrabold leading-[1.03] tracking-[-.06em]">Your website<br />starts <span className="text-[#e7bc66]">finished.</span></h1><p className="mt-6 max-w-md text-lg leading-relaxed text-white/75">Seven thoughtfully designed slides. Your story, your photos, your colors. Every detail editable in one calm studio.</p></div><p className="text-xs text-white/60">A complete website template · $19.99/month after checkout</p></div><div className="flex w-full items-center justify-center p-6 lg:w-1/2"><form onSubmit={submit} className="w-full max-w-md rounded-2xl border border-[#d8dfd5] bg-white p-8 shadow-xl"><a href="/" className="text-xs font-bold tracking-[.2em] text-[#45705b]">← VIEW THE SEVEN-SLIDE TEMPLATE</a><h2 className="mt-9 font-[Manrope] text-3xl font-extrabold tracking-[-.05em]">{mode === "in" ? "Welcome back." : "Make it yours."}</h2><p className="mb-7 mt-2 text-sm leading-relaxed text-[#65776a]">{mode === "in" ? "Sign in to return to your slide website." : "Create an account. Your own copy of all seven slides will be waiting after checkout."}</p><label className="mb-4 block text-xs font-bold">Email address<input className="mt-2 block h-12 w-full rounded-md border border-[#cbd8ca] px-3 text-sm outline-[#245c4a]" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} /></label><label className="mb-6 block text-xs font-bold">Password<input className="mt-2 block h-12 w-full rounded-md border border-[#cbd8ca] px-3 text-sm outline-[#245c4a]" type="password" required minLength={6} autoComplete={mode === "in" ? "current-password" : "new-password"} value={password} onChange={(e) => setPassword(e.target.value)} /></label><button className="h-12 w-full rounded-md bg-[#245c4a] text-sm font-bold text-white disabled:opacity-50" type="submit" disabled={busy}>{busy ? "Please wait…" : mode === "in" ? "Sign in" : "Create my account"}</button><button className="mt-5 w-full text-center text-xs text-[#5b6f61] underline" type="button" onClick={() => setMode(mode === "in" ? "up" : "in")}>{mode === "in" ? "New here? Create an account" : "Already have an account? Sign in"}</button></form></div></div>;
}
