import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { getPaymentHistory, openBillingPortal } from "@/template/billing.functions";

export const Route = createFileRoute("/_authenticated/payments")({
  head: () => ({ meta: [{ title: "Payment history — Slides Website" }, { name: "robots", content: "noindex" }] }),
  component: Payments,
});

function Payments() {
  const { data, error, isLoading, refetch } = useQuery({ queryKey: ["my-payment-history"], queryFn: () => getPaymentHistory() });
  const [busy, setBusy] = useState(false);
  async function manage() {
    setBusy(true);
    const tab = window.open("", "_blank");
    try { const { url } = await openBillingPortal({ data: { origin: window.location.origin } }); if (tab) tab.location.href = url; else window.location.href = url; }
    catch (cause) { tab?.close(); toast.error(cause instanceof Error ? cause.message : "The billing portal is unavailable"); }
    finally { setBusy(false); }
  }
  return <main className="min-h-dvh bg-[#f8f7f2] px-6 py-12 font-[Inter] text-[#173d32]"><div className="mx-auto max-w-3xl"><a href="/admin" className="text-xs font-bold tracking-[.12em] text-[#456b56]">← BACK TO WEBSITE STUDIO</a><h1 className="mt-9 font-[Manrope] text-4xl font-extrabold tracking-[-.05em]">Your payments</h1><p className="mt-2 text-sm text-[#667d6d]">Completed invoices and subscription status from Stripe. A checkout return alone is not proof that a payment succeeded.</p><button type="button" onClick={() => void manage()} disabled={busy} className="mt-7 rounded-md bg-[#245c4a] px-5 py-3 text-sm font-semibold text-white disabled:opacity-50">{busy ? "Opening…" : "Manage subscription"}</button>{isLoading && <p className="mt-10" role="status">Loading your invoices…</p>}{error && <div className="mt-10 rounded-lg border border-red-300 bg-white p-4"><p>Could not load payment history.</p><button type="button" onClick={() => void refetch()} className="mt-2 underline">Try again</button></div>}{data && (data.length ? <div className="mt-10 overflow-hidden rounded-lg border border-[#dce3da] bg-white"><table className="w-full text-left text-sm"><thead className="bg-[#edf3ed] text-xs uppercase tracking-[.12em]"><tr><th className="p-4">Date</th><th className="p-4">Items</th><th className="p-4">Amount</th><th className="p-4">Status</th><th className="p-4">Receipt</th></tr></thead><tbody>{data.map((invoice) => <tr key={invoice.id} className="border-t border-[#e5eae2]"><td className="p-4">{new Date(invoice.date * 1000).toLocaleDateString()}</td><td className="p-4">{invoice.items.join(", ")}</td><td className="p-4">{new Intl.NumberFormat("en-US", { style: "currency", currency: invoice.currency }).format(invoice.amount / 100)}</td><td className="p-4 capitalize">{invoice.status.replace(/_/g, " ")}</td><td className="p-4">{invoice.invoiceUrl ? <a className="underline" href={invoice.invoiceUrl} target="_blank" rel="noopener noreferrer">View</a> : "—"}</td></tr>)}</tbody></table></div> : <p className="mt-10 rounded-lg border border-[#dce3da] bg-white p-6 text-sm">No completed invoices yet. If you have just returned from checkout, allow the signed webhook to process, then refresh this page.</p>)}</div></main>;
}
