import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { CustomerEditor } from "@/template/editor";
import { SlidesWebsite } from "@/template/renderer";
import { getMyDeck } from "@/template/deck.functions";
import { startSubscription } from "@/template/billing.functions";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [
    { title: "Your website studio — Slides Website" },
    { name: "description", content: "Make your seven-slide website yours." },
    { name: "robots", content: "noindex" },
  ] }),
  component: Admin,
});

function Admin() {
  const { data, error, isLoading, refetch } = useQuery({ queryKey: ["my-customer-deck"], queryFn: () => getMyDeck(), refetchOnWindowFocus: false });
  const [checkoutBusy, setCheckoutBusy] = useState(false);
  async function checkout() {
    if (checkoutBusy) return;
    setCheckoutBusy(true);
    const tab = window.open("", "_blank");
    try {
      const result = await startSubscription({ data: { origin: window.location.origin } });
      if (result.alreadyActive) { tab?.close(); await refetch(); return; }
      if (result.pending) { tab?.close(); toast.info("Your earlier checkout is still processing. Refresh access or manage billing before trying again."); return; }
      if (tab) tab.location.href = result.url; else window.location.href = result.url;
      toast.info("Opening secure test checkout in a new tab.");
    } catch (cause) { tab?.close(); toast.error(cause instanceof Error ? cause.message : "Checkout is unavailable"); }
    finally { setCheckoutBusy(false); }
  }
  if (isLoading) return <div className="flex h-dvh items-center justify-center bg-[#f8f7f2] text-[#173d32]" role="status">Preparing your seven-slide website…</div>;
  if (error || !data) return <div className="flex h-dvh flex-col items-center justify-center gap-4 bg-[#f8f7f2] px-6 text-center text-[#173d32]"><h1 className="text-2xl font-semibold">Your studio couldn’t load</h1><p>{error instanceof Error ? error.message : "Please try again."}</p><button className="rounded border px-5 py-3" onClick={() => void refetch()}>Try again</button></div>;
  if (data.entitlement !== "active") return <div className="relative h-dvh overflow-hidden bg-[#111514]"><SlidesWebsite deck={data.deck} /><div className="absolute bottom-16 left-1/2 z-40 w-[min(440px,calc(100%-32px))] -translate-x-1/2 rounded-xl border border-[#d3c394] bg-[#f8f7f2] p-6 text-center text-[#173d32] shadow-2xl"><p className="mb-2 text-[11px] font-bold tracking-[.22em] text-[#9d7a31]">YOUR SITE IS READY</p><h1 className="mb-2 font-[Manrope] text-2xl font-bold">Seven slides. Already designed.</h1><p className="mb-5 text-sm leading-relaxed">Subscribe for <strong>$19.99/month</strong> to open your CMS, replace every photo and word, and publish a site for your own company.</p><button type="button" onClick={() => void checkout()} disabled={checkoutBusy} className="w-full rounded-md bg-[#22594a] px-5 py-3 font-semibold text-white disabled:opacity-50">{checkoutBusy ? "Opening checkout…" : "Open test checkout · $19.99/month"}</button><button type="button" onClick={() => void refetch()} className="mt-3 text-xs underline">Already checked out? Refresh access</button><a href="/payments" className="ml-3 text-xs underline">Payments &amp; billing</a><p className="mt-3 text-[11px] text-[#75877a]">Development uses Stripe test mode. No live payment is taken in this preview.</p></div></div>;
  return <CustomerEditor key={data.slug} initial={data} refresh={refetch} />;
}
