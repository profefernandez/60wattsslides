import { describe, expect, test } from "vitest";
import { sizePreset, textStyleClasses, textStyleCss } from "./slide-text";

describe("slide font sizes", () => {
  test("restores independent heading and subtitle named sizes", () => {
    for (const size of ["small", "medium", "large", "extra-large"] as const) {
      expect(textStyleClasses({ size }, "title")).toContain("text-");
      expect(textStyleClasses({ size }, "subtitle")).toContain("text-");
      expect(textStyleCss({ size }, "title")).toBeUndefined();
    }
    expect(textStyleClasses({ size: "extra-large" }, "title")).not.toBe(textStyleClasses({ size: "extra-large" }, "subtitle"));
  });

  test("point sizes already saved still show in a named size", () => {
    expect(sizePreset(16)).toBe("small");
    expect(sizePreset(20)).toBe("medium");
    expect(sizePreset(26)).toBe("large");
    expect(sizePreset(32)).toBe("extra-large");
  });

  test("automatic contrast overrides a custom dark text color and adds a backing", () => {
    const style = { color: "#101010", readability: "auto" } as const;
    expect(textStyleCss(style, "title")).toBeUndefined();
    expect(textStyleClasses(style, "title")).toContain("text-slide-light");
    expect(textStyleClasses(style, "title")).toContain("slide-text-shadow");
  });
});