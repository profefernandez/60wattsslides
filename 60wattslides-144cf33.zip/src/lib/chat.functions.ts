import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { ListItem, SlideKind } from "@/lib/cms";
import { buildSlideMap } from "@/lib/slide-map";

const schema = z.object({
  messages: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().min(1).max(4000) }))
    .min(1)
    .max(40),
});

/** Privacy-first: server-local search only, no external AI, nothing stored. Returns the matching slide text. */
export const sendChat = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => schema.parse(data))
  .handler(async ({ data }) => {
    const { createClient } = await import("@supabase/supabase-js");
    const sb = createClient(process.env["SUPABASE_URL"]!, process.env["SUPABASE_PUBLISHABLE_KEY"]!, {
      auth: { persistSession: false, autoRefreshToken: false },
    });
    const { data: rows } = await sb
      .from("slides")
      .select("id, kind, title, subtitle, items, enabled, position, document_path, document_name")
      .eq("enabled", true)
      .order("position");
    const map = buildSlideMap((rows ?? []).map((r) => ({ ...r, kind: r.kind as SlideKind, items: Array.isArray(r.items) ? (r.items as unknown as ListItem[]) : [] })));
    const question = [...data.messages].reverse().find((m) => m.role === "user")?.content ?? "";
    const { localSearch } = await import("@/lib/semantic-search.server");
    const hit = localSearch(map, question, 1)[0];
    if (!hit) return { reply: "I couldn't find that on these slides. Try different words.", slideId: null };
    return { reply: hit.content, slideId: hit.slideId };
  });
