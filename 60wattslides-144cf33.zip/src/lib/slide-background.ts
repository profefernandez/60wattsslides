import type { Slide } from "@/lib/cms";

export type SlideBackground = "original" | "charcoal" | "forest" | "ocean" | "berry" | "image";

export const BACKGROUND_COLORS: { value: Exclude<SlideBackground, "image">; label: string; className: string }[] = [
  { value: "original", label: "Original", className: "bg-hero-gradient" },
  { value: "charcoal", label: "Charcoal", className: "bg-slide-bg-charcoal" },
  { value: "forest", label: "Forest", className: "bg-slide-bg-forest" },
  { value: "ocean", label: "Ocean", className: "bg-slide-bg-ocean" },
  { value: "berry", label: "Berry", className: "bg-slide-bg-berry" },
];

export function slideBackground(slide: Slide): SlideBackground {
  return slide.title_style?.background_color ?? "original";
}

export function slideBackgroundClass(slide: Slide): string {
  return BACKGROUND_COLORS.find((color) => color.value === slideBackground(slide))?.className ?? "bg-hero-gradient";
}