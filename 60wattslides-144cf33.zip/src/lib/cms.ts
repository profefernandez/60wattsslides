import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { TextStyle } from "@/lib/slide-text";
import { chatStyle, type ChatStyle } from "@/lib/chat-style";
import { annotationDisplay, annotationMode, annotationShape, annotationStyle, answerTemplate, type AnswerTemplate } from "@/lib/annotation";
import { applyInitialSplitTemplate } from "@/lib/website-template";

export type SlideKind = "image" | "photo-text" | "video" | "list" | "text" | "document" | "faq" | "workshop" | "logos";

export interface ListItem {
  title: string;
  desc: string;
  meta: string;
  /** Workshop: extra recurring dates/times beyond `meta`. */
  dates?: string[];
  /** Workshop: registration link (http/https only) and button text. */
  signup_url?: string;
  cta_label?: string;
  /** Workshop: optional waitlist link shown when seats_left is 0. */
  waitlist_url?: string;
  /** Workshop: optional total seats and seats remaining. */
  capacity?: number | null;
  seats_left?: number | null;
  /** Workshop: calendar start (datetime-local, wall time) aligned with [meta, ...dates]. */
  starts?: string[];
  duration_min?: number;
  timezone?: string;
  /** Logos: image URL for a partner logo (title = company name / alt text, signup_url = optional website). */
  logo_url?: string;
}

export function setAt(list: string[] | undefined, i: number, v: string): string[] {
  const next = [...(list ?? [])];
  while (next.length <= i) next.push("");
  next[i] = v;
  return next;
}

export const TIME_ZONES: string[] = typeof Intl.supportedValuesOf === "function" ? Intl.supportedValuesOf("timeZone") : ["UTC"];

export function isValidTimeZone(tz: string): boolean {
  try {
    new Intl.DateTimeFormat("en", { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

function calStamp(d: Date): string {
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getUTCFullYear()}${p(d.getUTCMonth() + 1)}${p(d.getUTCDate())}T${p(d.getUTCHours())}${p(d.getUTCMinutes())}00`;
}

/** Google Calendar link using wall-clock time + ctz, so no timezone math is needed. */
export function calendarLinks(item: ListItem, start: string): { google: string; ics: string } | null {
  const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(start);
  if (!m) return null;
  const wall = new Date(Date.UTC(+m[1]!, +m[2]! - 1, +m[3]!, +m[4]!, +m[5]!));
  const end = new Date(wall.getTime() + (item.duration_min ?? 60) * 60000);
  const tz = item.timezone && isValidTimeZone(item.timezone) ? item.timezone : "";
  const q = new URLSearchParams({ action: "TEMPLATE", text: item.title, details: item.desc, dates: `${calStamp(wall)}/${calStamp(end)}` });
  if (tz) q.set("ctz", tz);
  const esc = (t: string) => t.replace(/[\\;,]/g, (c) => `\\${c}`).replace(/\n/g, "\\n");
  const dt = (d: Date) => (tz ? `;TZID=${tz}:${calStamp(d)}` : `:${calStamp(d)}`);
  const ics = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Horizon//Workshop//EN", "BEGIN:VEVENT", `UID:${calStamp(wall)}-${encodeURIComponent(item.title)}`, `DTSTAMP:${calStamp(new Date())}Z`, `DTSTART${dt(wall)}`, `DTEND${dt(end)}`, `SUMMARY:${esc(item.title)}`, `DESCRIPTION:${esc(item.desc)}`, "END:VEVENT", "END:VCALENDAR"].join("\r\n");
  return { google: `https://calendar.google.com/calendar/render?${q.toString()}`, ics: `data:text/calendar;charset=utf-8,${encodeURIComponent(ics)}` };
}

export function safeSignupUrl(url: string | undefined): string | null {
  if (!url) return null;
  try {
    const u = new URL(url.trim());
    return u.protocol === "https:" || u.protocol === "http:" ? u.toString() : null;
  } catch {
    return null;
  }
}

export interface Slide {
  id: string;
  position: number;
  kind: SlideKind;
  title: string;
  subtitle: string;
  title_style: Partial<TextStyle>;
  subtitle_style: Partial<TextStyle>;
  media_url: string;
  media_alt: string;
  document_path: string;
  document_name: string;
  document_expires_at: string | null;
  document_max_downloads: number;
  document_download_count: number;
  document_retention_days: number;
  document_allowed_types: string[];
  document_max_upload_mb: number;
  overlay_opacity: number;
  items: ListItem[];
  enabled: boolean;
}

export interface SiteSettings {
  app_name: string;
  chat_placeholder: string;
  system_prompt: string;
  autoplay_seconds: number;
  annotation_mode: string;
  annotation_label: string;
  annotation_display: string;
  annotation_icon: string;
  annotation_style: string;
  annotation_shape: string;
  annotation_color: string;
  answer_template: AnswerTemplate;
  chat_style: ChatStyle;
}

export const AUTOPLAY_MIN_SECONDS = 3;
export const AUTOPLAY_MAX_SECONDS = 20;
export const AUTOPLAY_DEFAULT_SECONDS = 7;

export function clampAutoplaySeconds(value: number): number {
  if (!Number.isFinite(value)) return AUTOPLAY_DEFAULT_SECONDS;
  return Math.min(AUTOPLAY_MAX_SECONDS, Math.max(AUTOPLAY_MIN_SECONDS, Math.round(value)));
}

export interface SiteContent {
  slides: Slide[];
  settings: SiteSettings;
}

export async function fetchSiteContent(): Promise<SiteContent> {
  const [slidesRes, settingsRes] = await Promise.all([
    supabase.from("slides").select("*").order("position"),
    supabase.from("site_settings").select("*").eq("id", 1).single(),
  ]);
  if (slidesRes.error) throw slidesRes.error;
  if (settingsRes.error) throw settingsRes.error;
  const slides: Slide[] = slidesRes.data.map((s) => ({
    ...s,
    kind: s.kind as SlideKind,
    title_style: (s.title_style ?? {}) as Partial<TextStyle>,
    subtitle_style: (s.subtitle_style ?? {}) as Partial<TextStyle>,
    media_alt: s.media_alt ?? "",
    document_path: s.document_path ?? "",
    document_name: s.document_name ?? "",
    document_expires_at: s.document_expires_at ?? null,
    document_max_downloads: s.document_max_downloads ?? 0,
    document_download_count: s.document_download_count ?? 0,
    document_retention_days: s.document_retention_days ?? 30,
    document_allowed_types: s.document_allowed_types ?? ["pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "zip"],
    document_max_upload_mb: s.document_max_upload_mb ?? 20,
    items: Array.isArray(s.items) ? (s.items as unknown as ListItem[]) : [],
  }));
  const st = settingsRes.data;
  return {
    slides: applyInitialSplitTemplate(slides),
    settings: {
      app_name: st.app_name,
      chat_placeholder: st.chat_placeholder,
      system_prompt: st.system_prompt,
      autoplay_seconds: clampAutoplaySeconds(st.autoplay_seconds),
      annotation_mode: annotationMode(st.annotation_mode),
      annotation_label: st.annotation_label ?? "Annotations",
      annotation_display: annotationDisplay(st.annotation_display),
      annotation_icon: st.annotation_icon ?? "highlighter",
      annotation_style: annotationStyle(st.annotation_style),
      annotation_shape: annotationShape(st.annotation_shape),
      annotation_color: st.annotation_color ?? "",
      answer_template: answerTemplate(st.answer_template),
      chat_style: chatStyle(st.chat_style),
    },
  };
}

export const siteContentQuery = queryOptions({
  queryKey: ["site-content"],
  queryFn: fetchSiteContent,
});
