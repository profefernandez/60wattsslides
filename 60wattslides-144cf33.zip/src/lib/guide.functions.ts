import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { ListItem, SlideKind } from "@/lib/cms";
import { buildSlideMap } from "@/lib/slide-map";
import { INTRO_SUBTITLE, INTRO_TITLE, isLegacyIntro } from "@/lib/website-template";

export interface GuideSource {
  targetSlideId: string;
  anchorId: string;
  slideTitle: string;
  comment: string;
}

/** Answers never include claims that cannot be traced to an enabled slide. */
export type GuideAnswer =
  | ({ action: "highlight"; chipLabel: string } & GuideSource)
  | { action: "suggest"; chipLabel: string; matches: GuideSource[] }
  | { action: "create_slide"; newSlide: { insertAfterSlideId: string; title: string; body: string; bullets: string[]; ephemeral: true }; chipLabel: string }
  | { action: "trigger_lead_form"; chipLabel: string }
  | { action: "error"; message: string };

const input = z.object({
  question: z.string().trim().min(1).max(500),
  deckState: z.object({
    slideIds: z.array(z.string().min(1).max(80)).max(60),
    visibleSlideId: z.string().max(80).nullable(),
  }),
});
const EMAIL = /[^\s@]+@[^\s@]+\.[^\s@]+/;
const PHONE = /(?:\+?\d[\s().-]?){7,}/;

function label(text: string): string {
  return text.trim().replace(/\s+/g, " ").split(" ").slice(0, 5).join(" ").slice(0, 40);
}

export const askGuide = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => input.parse(data))
  .handler(async ({ data }): Promise<GuideAnswer> => {
    if (EMAIL.test(data.question) || PHONE.test(data.question)) return { action: "trigger_lead_form", chipLabel: "Contact details" };

    const url = process.env["SUPABASE_URL"];
    const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
    if (!url || !key) return { action: "error", message: "Slide search is unavailable right now. Please try again later." };

    try {
      const { createClient } = await import("@supabase/supabase-js");
      const sb = createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
      const { data: rows, error } = await sb.from("slides")
        .select("id, kind, title, subtitle, items, enabled, position, document_path, document_name")
        .eq("enabled", true).order("position");
      if (error) throw error;
      const map = buildSlideMap((rows ?? []).map((row) => ({
        ...row,
        ...(isLegacyIntro(row.title) ? { title: INTRO_TITLE, subtitle: INTRO_SUBTITLE } : {}),
        kind: row.kind as SlideKind,
        items: Array.isArray(row.items) ? row.items as unknown as ListItem[] : [],
      })));
      const { localSearch } = await import("@/lib/semantic-search.server");
      const hits = localSearch(map, data.question, 8);
      const distinct = hits.filter((hit, index) => hits.findIndex((candidate) => candidate.slideId === hit.slideId) === index);
      if (distinct.length === 0) {
        const safeTitle = data.question.trim().replace(/\s+/g, " ").replace(/[<>]/g, "").slice(0, 90);
        return {
          action: "create_slide",
          chipLabel: "New draft slide",
          newSlide: {
            insertAfterSlideId: map.some((slide) => slide.id === data.deckState.visibleSlideId) ? data.deckState.visibleSlideId! : map.at(-1)?.id ?? "end",
            title: safeTitle ? `Question: ${safeTitle}` : "Unanswered question",
            body: "This deck does not contain a supported answer yet. This is a temporary draft, not a published or verified answer.",
            bullets: ["Add a sourced, verified answer in the editor.", "Review the content before enabling the slide for visitors."],
            ephemeral: true,
          },
        };
      }
      const source = (hit: typeof hits[number]): GuideSource => ({
        targetSlideId: hit.slideId,
        anchorId: hit.anchorId,
        slideTitle: map.find((slide) => slide.id === hit.slideId)?.title || "Untitled slide",
        comment: hit.content.trim().slice(0, 320),
      });
      const top = distinct[0]!;
      const nearby = distinct.filter((hit) => hit.coverage >= top.coverage && hit.score >= top.score * 0.82).slice(0, 3);
      if (nearby.length > 1) return { action: "suggest", chipLabel: label(data.question), matches: nearby.map(source) };
      return { action: "highlight", ...source(top), chipLabel: label(data.question) };
    } catch (error) {
      console.error("Slide search failed", error);
      return { action: "error", message: "We couldn't search the deck right now. Your question is still here; please try again." };
    }
  });
