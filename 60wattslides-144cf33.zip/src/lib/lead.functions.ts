import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { ListItem, SlideKind } from "@/lib/cms";
import { buildSlideMap } from "@/lib/slide-map";

const leadInput = z.object({
  firstName: z.string().trim().min(1, "First name is required").max(80),
  email: z.string().trim().toLowerCase().email("Enter a valid email").max(254),
  organization: z.string().trim().max(120).default(""),
  delivery: z.enum(["download", "email", "both"]),
  marketing: z.boolean(),
  items: z.array(z.object({ anchorId: z.string().min(3).max(120), question: z.string().trim().max(500) })).min(1).max(12),
});

export type LeadResult =
  | { ok: true; pdfBase64: string; fileName: string; emailSent: boolean }
  | { ok: false; message: string };

/** Wraps text to lines that fit width using the given font metrics. */
function wrap(text: string, width: number, measure: (s: string) => number): string[] {
  const lines: string[] = [];
  for (const para of text.split(/\n+/)) {
    let line = "";
    for (const word of para.split(/\s+/).filter(Boolean)) {
      const next = line ? `${line} ${word}` : word;
      if (measure(next) > width && line) { lines.push(line); line = word; } else line = next;
    }
    if (line) lines.push(line);
  }
  return lines;
}

/** Standard fonts only support basic Latin; replace anything else. */
const clean = (s: string) => s.replace(/[\u2018\u2019]/g, "'").replace(/[\u201C\u201D]/g, '"').replace(/[\u2013\u2014]/g, "-").replace(/[^\x20-\x7E\n]/g, "");

async function buildPdf(appName: string, firstName: string, cards: { title: string; question: string; body: string }[]): Promise<Uint8Array> {
  const { PDFDocument, StandardFonts, rgb } = await import("pdf-lib");
  const doc = await PDFDocument.create();
  const serif = await doc.embedFont(StandardFonts.TimesRomanBold);
  const sans = await doc.embedFont(StandardFonts.Helvetica);
  const sansBold = await doc.embedFont(StandardFonts.HelveticaBold);
  const ink = rgb(0.12, 0.12, 0.12);
  const muted = rgb(0.4, 0.4, 0.4);
  const W = 612, H = 792, M = 56;
  const date = new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  const footer = (p: ReturnType<typeof doc.addPage>) => {
    p.drawRectangle({ x: 0, y: 0, width: W, height: 40, color: ink });
    p.drawText(clean(appName), { x: M, y: 15, size: 9, font: sansBold, color: rgb(1, 1, 1) });
  };

  const cover = doc.addPage([W, H]);
  cover.drawText("Your answers", { x: M, y: H - 220, size: 40, font: serif, color: ink });
  cover.drawText(clean(`Prepared for ${firstName}`), { x: M, y: H - 260, size: 16, font: sans, color: ink });
  cover.drawText(date, { x: M, y: H - 282, size: 12, font: sans, color: muted });
  cover.drawText(`${cards.length} answer${cards.length === 1 ? "" : "s"} from ${clean(appName)}`, { x: M, y: H - 304, size: 12, font: sans, color: muted });
  footer(cover);

  for (const [i, card] of cards.entries()) {
    const page = doc.addPage([W, H]);
    let y = H - M - 10;
    page.drawText(`Answer ${i + 1}`, { x: M, y, size: 10, font: sansBold, color: muted });
    y -= 34;
    for (const line of wrap(clean(card.title), W - 2 * M, (s) => serif.widthOfTextAtSize(s, 24))) { page.drawText(line, { x: M, y, size: 24, font: serif, color: ink }); y -= 30; }
    if (card.question) {
      y -= 4;
      for (const line of wrap(clean(`You asked: ${card.question}`), W - 2 * M, (s) => sans.widthOfTextAtSize(s, 12))) { page.drawText(line, { x: M, y, size: 12, font: sans, color: muted }); y -= 16; }
    }
    y -= 14;
    for (const line of wrap(clean(card.body), W - 2 * M, (s) => sans.widthOfTextAtSize(s, 13))) {
      if (y < 70) break;
      page.drawText(line, { x: M, y, size: 13, font: sans, color: ink }); y -= 19;
    }
    footer(page);
  }
  return doc.save();
}

/**
 * Visitor chose to keep a copy: builds the PDF from live slide text (never client text),
 * saves a lead in the CRM with a retained PDF, and returns the PDF for download.
 */
export const submitBoardLead = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => leadInput.parse(data))
  .handler(async ({ data }): Promise<LeadResult> => {
    const { supabaseAdmin: sb } = await import("@/integrations/supabase/client.server");

    // Purge expired website leads and their retained PDFs.
    const { data: expired } = await sb.from("crm_contacts").select("id, pdf_path").eq("source", "board").lte("expires_at", new Date().toISOString());
    if (expired?.length) {
      const paths = expired.map((r) => r.pdf_path).filter(Boolean);
      if (paths.length) await sb.storage.from("documents").remove(paths);
      await sb.from("crm_contacts").delete().in("id", expired.map((r) => r.id));
    }

    const since = new Date(Date.now() - 60_000).toISOString();
    const { count } = await sb.from("crm_contacts").select("id", { count: "exact", head: true }).eq("source", "board").eq("email", data.email).gte("created_at", since);
    if ((count ?? 0) > 0) return { ok: false, message: "Please wait a minute before requesting another copy." };

    const [{ data: rows }, { data: settings }] = await Promise.all([
      sb.from("slides").select("id, kind, title, subtitle, items, enabled, position, document_path, document_name").eq("enabled", true).order("position"),
      sb.from("site_settings").select("app_name, lead_retention_months").eq("id", 1).single(),
    ]);
    const map = buildSlideMap((rows ?? []).map((r) => ({ ...r, kind: r.kind as SlideKind, items: Array.isArray(r.items) ? (r.items as unknown as ListItem[]) : [] })));
    const cards = data.items.flatMap((item) => {
      const slide = map.find((s) => item.anchorId.startsWith(`${s.id}:`));
      const anchor = slide?.anchors.find((a) => a.anchorId === item.anchorId);
      return slide && anchor ? [{ anchorId: item.anchorId, slideId: slide.id, title: slide.title || "Answer", question: item.question, body: anchor.textContent }] : [];
    });
    if (!cards.length) return { ok: false, message: "Those answers are no longer on the site. Ask again and try once more." };

    const appName = settings?.app_name || "Your answers";
    const pdf = await buildPdf(appName, data.firstName, cards);
    const stamp = new Date().toISOString().slice(0, 10);
    const fileName = `${appName.replace(/[^a-z0-9]+/gi, "-").toLowerCase()}-answers-${stamp}.pdf`;
    const pdfPath = `leads/${crypto.randomUUID()}.pdf`;
    const upload = await sb.storage.from("documents").upload(pdfPath, pdf, { contentType: "application/pdf" });
    if (upload.error) console.error("lead pdf upload failed", upload.error.message);

    const months = Math.min(36, Math.max(1, settings?.lead_retention_months ?? 12));
    const expires = new Date(); expires.setMonth(expires.getMonth() + months);
    const now = new Date().toISOString();
    const { error } = await sb.from("crm_contacts").insert({
      name: data.firstName, email: data.email, organization: data.organization, source: "board", status: "new",
      marketing_consent: data.marketing, consent_at: now, delivery: data.delivery,
      board: cards, pdf_path: upload.error ? "" : pdfPath, expires_at: expires.toISOString(),
    });
    if (error) { console.error("lead insert failed", error.message); return { ok: false, message: "We couldn't save your copy. Please try again." }; }

    // Email delivery waits for a sender domain; the download always works.
    return { ok: true, pdfBase64: Buffer.from(pdf).toString("base64"), fileName, emailSent: false };
  });
