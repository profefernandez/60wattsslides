import type { CSSProperties } from "react";
import { isHexColor, type TextStyle } from "./slide-text";

export const ACTION_STYLES = ["solid", "outline", "soft", "ghost", "underline"] as const;
export type ActionStyle = (typeof ACTION_STYLES)[number];
export const ACTION_SHAPES = ["rounded", "square", "pill", "cut", "asymmetric"] as const;
export type ActionShape = (typeof ACTION_SHAPES)[number];
export type SlideAction = NonNullable<TextStyle["actions"]>[number];

export function actionStyle(action: SlideAction, index: number): ActionStyle {
  return ACTION_STYLES.find((style) => style === action.style) ?? (index === 0 ? "solid" : "outline");
}

export function actionColor(action: SlideAction): string | undefined {
  return typeof action.color === "string" && isHexColor(action.color) ? action.color.toLowerCase() : undefined;
}

export function actionShape(action: SlideAction): ActionShape {
  return ACTION_SHAPES.find((shape) => shape === action.shape) ?? "rounded";
}

export function actionBrightness(action: SlideAction): number {
  return typeof action.brightness === "number" && Number.isFinite(action.brightness)
    ? Math.max(-50, Math.min(50, Math.round(action.brightness))) : 0;
}

export type Rgb = [number, number, number];
export function hexRgb(hex: string): Rgb {
  return [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16)) as Rgb;
}

export function rgbCss([red, green, blue]: Rgb): string {
  return `rgb(${Math.round(red)}, ${Math.round(green)}, ${Math.round(blue)})`;
}

export function mixRgb(from: Rgb, to: Rgb, ratio: number): Rgb {
  return from.map((value, index) => value + ((to[index] ?? 0) - value) * ratio) as Rgb;
}

export function luminance(rgb: Rgb): number {
  const linear = rgb.map((value) => {
    const channel = value / 255;
    return channel <= 0.04045 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4;
  });
  return (linear[0] ?? 0) * 0.2126 + (linear[1] ?? 0) * 0.7152 + (linear[2] ?? 0) * 0.0722;
}

export function contrastRatio(a: Rgb, b: Rgb): number {
  const x = luminance(a), y = luminance(b);
  return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
}

const BLACK: Rgb = [0, 0, 0];
const WHITE: Rgb = [255, 255, 255];

export function contrastInk(surface: Rgb): Rgb {
  return contrastRatio(surface, BLACK) >= contrastRatio(surface, WHITE) ? BLACK : WHITE;
}

/** Retain the chosen hue whenever it meets AA; otherwise blend toward the readable neutral. */
export function readableInk(color: Rgb, surface: Rgb): Rgb {
  if (contrastRatio(color, surface) >= 4.5) return color;
  const neutral = contrastInk(surface);
  for (let step = 1; step <= 100; step++) {
    const candidate = mixRgb(color, neutral, step / 100).map(Math.round) as Rgb;
    if (contrastRatio(candidate, surface) >= 4.5) return candidate;
  }
  return neutral;
}

export function actionColorVariables(action: SlideAction, index = 0, themeColor?: Rgb): CSSProperties {
  const color = actionColor(action);
  const base = color ? hexRgb(color) : themeColor;
  if (!base) return {};
  const surface = BLACK;
  const brightness = actionBrightness(action) / 100;
  const adjusted = brightness < 0 ? mixRgb(base, BLACK, -brightness) : mixRgb(base, WHITE, brightness);
  const appearance = actionStyle(action, index);
  // An opaque backing guarantees predictable contrast even over photographs and videos.
  const fill = appearance === "solid" ? adjusted : appearance === "soft" ? mixRgb(surface, adjusted, 0.22) : surface;
  const ink = appearance === "solid" ? contrastInk(fill) : readableInk(adjusted, fill);
  return {
    "--slide-action-color": rgbCss(adjusted),
    "--slide-action-foreground": rgbCss(contrastInk(adjusted)),
    "--slide-action-ink": rgbCss(ink),
    "--slide-action-surface": rgbCss(surface),
    "--slide-action-soft": rgbCss(mixRgb(surface, adjusted, 0.22)),
  } as CSSProperties;
}