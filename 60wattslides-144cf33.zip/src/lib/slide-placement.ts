import type { CSSProperties } from "react";
import type { TextStyle } from "@/lib/slide-text";

export const clamp = (value: number, min: number, max: number) => Number.isFinite(value) ? Math.min(max, Math.max(min, value)) : 0;

export const ZOOM_MIN = 50;
export const ZOOM_MAX = 400;
export const PAN_LIMIT = 100;

export type PhotoShape = "full" | "rounded-sm" | "rounded-md" | "rounded-lg" | "circle" | "arch" | "custom";
export const PHOTO_SHAPES: { value: PhotoShape; label: string }[] = [
  { value: "full", label: "Full" },
  { value: "rounded-sm", label: "Rounded S" },
  { value: "rounded-md", label: "Rounded M" },
  { value: "rounded-lg", label: "Rounded L" },
  { value: "circle", label: "Circle" },
  { value: "arch", label: "Arch" },
  { value: "custom", label: "Custom" },
];

export interface PhotoState { zoom: number; x: number; y: number }

export function photoState(style: Partial<TextStyle>): PhotoState {
  return { zoom: clamp(style.media_zoom ?? 100, ZOOM_MIN, ZOOM_MAX), x: clamp(style.media_x ?? 0, -PAN_LIMIT, PAN_LIMIT), y: clamp(style.media_y ?? 0, -PAN_LIMIT, PAN_LIMIT) };
}

/** Keep part of the photo visible: the further you zoom in, the further you may move. */
export function clampPan(state: PhotoState): PhotoState {
  const zoom = clamp(state.zoom, ZOOM_MIN, ZOOM_MAX);
  const limit = Math.min(PAN_LIMIT, 50 + (zoom / 100) * 50);
  return { zoom, x: clamp(state.x, -limit, limit), y: clamp(state.y, -limit, limit) };
}

/** Zoom by `factor` keeping the point (px, py) — in container pixels — fixed under the cursor. */
export function zoomAt(state: PhotoState, factor: number, px: number, py: number, width: number, height: number): PhotoState {
  const next = clamp(state.zoom * factor, ZOOM_MIN, ZOOM_MAX);
  const k = next / state.zoom;
  if (!width || !height) return clampPan({ ...state, zoom: next });
  const cx = (px - width / 2) / width * 100;
  const cy = (py - height / 2) / height * 100;
  return clampPan({ zoom: next, x: cx - (cx - state.x) * k, y: cy - (cy - state.y) * k });
}

export function wheelFactor(deltaY: number, deltaMode: number): number {
  const dy = deltaY * (deltaMode === 1 ? 16 : deltaMode === 2 ? 100 : 1);
  return Math.exp(-dy * 0.0015);
}

export function panBy(state: PhotoState, dx: number, dy: number): PhotoState {
  return clampPan({ ...state, x: state.x + dx, y: state.y + dy });
}

export function photoFrame(style: Partial<TextStyle>, defaultFit: "cover" | "contain" = "cover"): CSSProperties {
  const { zoom, x, y } = photoState(style);
  return {
    objectFit: style.media_fit === "contain" || (!style.media_fit && defaultFit === "contain") ? "contain" : "cover",
    transform: `translate(${x}%, ${y}%) scale(${zoom / 100})`,
  };
}

const SHADOWS = { none: undefined, soft: "0 8px 24px oklch(0 0 0 / 25%)", strong: "0 18px 48px oklch(0 0 0 / 45%)" } as const;

/** Shape, border and shadow for the box holding a photo. Missing fields keep the original full-bleed look. */
export function photoContainer(style: Partial<TextStyle>): { className: string; style: CSSProperties } {
  const shape = style.media_shape ?? "full";
  const width = style.media_border === "thick" ? 6 : style.media_border === "thin" ? 2 : 0;
  const color = style.media_border_color && /^#[0-9a-f]{6}$/i.test(style.media_border_color) ? style.media_border_color : "var(--primary)";
  const css: CSSProperties = { boxShadow: SHADOWS[style.media_shadow ?? "none"], ...(width ? { border: `${width}px solid ${color}` } : {}) };
  const centered = "absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 overflow-hidden";
  switch (shape) {
    case "circle":
      return { className: `${centered} aspect-square w-[min(80cqw,80cqh)]`, style: { ...css, borderRadius: "9999px" } };
    case "arch":
      return { className: `${centered} aspect-[3/4] h-[min(86cqh,114cqw)]`, style: { ...css, borderRadius: "50% 50% 0 0 / 37.5% 37.5% 0 0" } };
    case "rounded-sm":
    case "rounded-md":
    case "rounded-lg":
    case "custom": {
      const r = shape === "custom" ? `${clamp(style.media_radius ?? 12, 0, 50)}%` : shape === "rounded-sm" ? "2cqmin" : shape === "rounded-md" ? "5cqmin" : "10cqmin";
      return { className: "absolute inset-[4cqmin] overflow-hidden", style: { ...css, borderRadius: r } };
    }
    default:
      return { className: "absolute inset-0 overflow-hidden", style: css };
  }
}

/** Desktop photo width and the matching automatic mobile photo height for photo + text slides. */
export function photoSplit(style: Partial<TextStyle>): CSSProperties {
  if (style.media_split == null) return { ["--photo-split" as string]: "48%", ["--photo-rows" as string]: "42%" };
  const s = clamp(style.media_split, 30, 70);
  return { ["--photo-split" as string]: `${s}%`, ["--photo-rows" as string]: `${Math.round(35 + (s - 30) * 15 / 40)}%` };
}

export function textPlacement(style: Partial<TextStyle>): CSSProperties {
  const x = clamp(style.offset_x ?? 0, -70, 70);
  const y = clamp(style.offset_y ?? 0, -70, 70);
  return x || y ? { transform: `translate(${x}cqw, ${y}cqh)` } : {};
}
