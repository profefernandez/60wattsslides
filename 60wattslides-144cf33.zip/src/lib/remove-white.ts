import { useEffect, useState } from "react";

const cache = new Map<string, Promise<string>>();

/** Turns near-white pixels transparent (soft edge) in the browser. Falls back to the original URL. */
function process(url: string): Promise<string> {
  const hit = cache.get(url);
  if (hit) return hit;
  const p = new Promise<string>((resolve) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => {
      try {
        const max = 800;
        const k = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
        const w = Math.max(1, Math.round(img.naturalWidth * k));
        const h = Math.max(1, Math.round(img.naturalHeight * k));
        const c = document.createElement("canvas");
        c.width = w;
        c.height = h;
        const ctx = c.getContext("2d");
        if (!ctx) return resolve(url);
        ctx.drawImage(img, 0, 0, w, h);
        const d = ctx.getImageData(0, 0, w, h);
        const px = d.data;
        for (let i = 0; i < px.length; i += 4) {
          const min = Math.min(px[i] ?? 0, px[i + 1] ?? 0, px[i + 2] ?? 0);
          if (min >= 245) px[i + 3] = 0;
          else if (min >= 225) px[i + 3] = Math.round((px[i + 3] ?? 255) * ((245 - min) / 20));
        }
        ctx.putImageData(d, 0, 0);
        resolve(c.toDataURL("image/png"));
      } catch {
        resolve(url);
      }
    };
    img.onerror = () => resolve(url);
    img.src = url;
  });
  cache.set(url, p);
  return p;
}

export function useWhiteRemoved(url: string | undefined, enabled: boolean): string | undefined {
  const [out, setOut] = useState<string | undefined>(enabled ? undefined : url);
  useEffect(() => {
    if (!url || !enabled) {
      setOut(url);
      return;
    }
    let live = true;
    void process(url).then((r) => live && setOut(r));
    return () => {
      live = false;
    };
  }, [url, enabled]);
  return out;
}
