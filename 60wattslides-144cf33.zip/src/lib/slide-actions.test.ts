import { describe, expect, test } from "vitest";
import { actionBrightness, actionColor, actionColorVariables, actionShape, actionStyle, contrastRatio, hexRgb, type Rgb } from "./slide-actions";

function cssRgb(value: unknown): Rgb {
  const channels = String(value).match(/\d+/g)?.map(Number) ?? [];
  return [channels[0] ?? 0, channels[1] ?? 0, channels[2] ?? 0];
}

describe("per-button slide appearance", () => {
  test("keeps earlier buttons' default styles and accepts all five choices", () => {
    const old = { label: "Visit", url: "https://example.com" };
    expect(actionStyle(old, 0)).toBe("solid");
    expect(actionStyle(old, 1)).toBe("outline");
    for (const style of ["solid", "outline", "soft", "ghost", "underline"]) {
      expect(actionStyle({ ...old, style }, 0)).toBe(style);
    }
    expect(actionStyle({ ...old, style: "invalid" }, 1)).toBe("outline");
  });

  test("rejects invalid color and picks readable solid text", () => {
    const base = { label: "Visit", url: "https://example.com" };
    expect(actionColor({ ...base, color: "red" })).toBeUndefined();
    expect(actionColorVariables({ ...base, color: "#111" })).toEqual({});
    expect(actionColorVariables({ ...base, color: "#ffffff" })["--slide-action-foreground" as keyof object]).toBe("rgb(0, 0, 0)");
    expect(actionColorVariables({ ...base, color: "#101010" })["--slide-action-foreground" as keyof object]).toBe("rgb(255, 255, 255)");
    expect(actionColor({ ...base, color: "#AABBCC" })).toBe("#aabbcc");
  });

  test("supports five shapes with a safe rounded fallback", () => {
    const base = { label: "Visit", url: "https://example.com" };
    expect(actionShape(base)).toBe("rounded");
    for (const shape of ["rounded", "square", "pill", "cut", "asymmetric"]) expect(actionShape({ ...base, shape })).toBe(shape);
    expect(actionShape({ ...base, shape: "unsafe" })).toBe("rounded");
  });

  test("brightness is bounded and defaults to unchanged", () => {
    const base = { label: "Visit", url: "https://example.com", color: "#808080" };
    expect(actionBrightness(base)).toBe(0);
    expect(actionBrightness({ ...base, brightness: Infinity })).toBe(0);
    expect(actionBrightness({ ...base, brightness: 999 })).toBe(50);
    expect(actionBrightness({ ...base, brightness: -999 })).toBe(-50);
    const original = actionColorVariables(base)["--slide-action-color" as keyof object];
    expect(original).toBe("rgb(128, 128, 128)");
    expect(actionColorVariables({ ...base, brightness: -50 })["--slide-action-color" as keyof object]).toBe("rgb(64, 64, 64)");
    expect(actionColorVariables({ ...base, brightness: 50 })["--slide-action-color" as keyof object]).toBe("rgb(192, 192, 192)");
  });

  test("all styles retain AA contrast at extreme colors and theme defaults", () => {
    const theme: Rgb = [95, 70, 210];
    for (const style of ["solid", "outline", "soft", "ghost", "underline"]) {
      for (const color of ["#ffffff", "#000000", "#777777", "#ff8800", undefined]) {
        for (const brightness of [-50, 0, 50]) {
          const variables = actionColorVariables({ label: "Visit", url: "https://example.com", style, color, brightness }, 0, theme);
          const fill = cssRgb(variables[style === "solid" ? "--slide-action-color" as keyof object : style === "soft" ? "--slide-action-soft" as keyof object : "--slide-action-surface" as keyof object]);
          const ink = cssRgb(variables[style === "solid" ? "--slide-action-foreground" as keyof object : "--slide-action-ink" as keyof object]);
          expect(contrastRatio(fill, ink)).toBeGreaterThanOrEqual(4.5);
        }
      }
    }
    expect(hexRgb("#ff8800")).toEqual([255, 136, 0]);
  });

  test("independent settings remain independent", () => {
    const first = { label: "Learn", url: "https://example.com", style: "soft", color: "#ff8800" };
    const second = { label: "Contact", url: "https://example.com/contact", style: "underline", color: "#005588", shape: "pill", brightness: -25 };
    expect(actionStyle(first, 0)).toBe("soft");
    expect(actionStyle(second, 1)).toBe("underline");
    expect(actionColor(first)).not.toBe(actionColor(second));
    expect(actionShape(first)).toBe("rounded");
    expect(actionShape(second)).toBe("pill");
    expect(actionBrightness(first)).toBe(0);
    expect(actionBrightness(second)).toBe(-25);
  });
});