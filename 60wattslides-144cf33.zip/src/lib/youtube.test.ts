import { describe, expect, it } from "vitest";
import { youtubeEmbedUrl, youtubeVideoId } from "./youtube";

const ID = "dQw4w9WgXcQ";

describe("youtubeVideoId", () => {
  it("parses watch links", () => {
    expect(youtubeVideoId(`https://www.youtube.com/watch?v=${ID}`)).toBe(ID);
    expect(youtubeVideoId(`https://youtube.com/watch?v=${ID}&t=42s`)).toBe(ID);
    expect(youtubeVideoId(`https://m.youtube.com/watch?v=${ID}`)).toBe(ID);
  });
  it("parses youtu.be short links", () => {
    expect(youtubeVideoId(`https://youtu.be/${ID}`)).toBe(ID);
    expect(youtubeVideoId(`https://youtu.be/${ID}?si=abc`)).toBe(ID);
  });
  it("parses shorts, embed and live links", () => {
    expect(youtubeVideoId(`https://www.youtube.com/shorts/${ID}`)).toBe(ID);
    expect(youtubeVideoId(`https://www.youtube.com/embed/${ID}`)).toBe(ID);
    expect(youtubeVideoId(`https://www.youtube.com/live/${ID}`)).toBe(ID);
    expect(youtubeVideoId(`https://www.youtube-nocookie.com/embed/${ID}`)).toBe(ID);
  });
  it("rejects non-YouTube and malformed links", () => {
    expect(youtubeVideoId("https://example.com/video.mp4")).toBeNull();
    expect(youtubeVideoId("https://vimeo.com/12345")).toBeNull();
    expect(youtubeVideoId(`https://youtube.com/watch?v=short`)).toBeNull();
    expect(youtubeVideoId("not a url")).toBeNull();
    expect(youtubeVideoId("")).toBeNull();
    expect(youtubeVideoId(`https://notyoutube.com/watch?v=${ID}`)).toBeNull();
  });
});

describe("youtubeEmbedUrl", () => {
  it("builds a privacy-enhanced embed url", () => {
    const url = youtubeEmbedUrl(ID);
    expect(url).toContain(`youtube-nocookie.com/embed/${ID}`);
    expect(url).toContain("rel=0");
    expect(url).not.toContain("autoplay=1");
  });
  it("adds autoplay, mute and loop when active", () => {
    const url = youtubeEmbedUrl(ID, { autoplay: true });
    expect(url).toContain("autoplay=1");
    expect(url).toContain("mute=1");
    expect(url).toContain("loop=1");
    expect(url).toContain(`playlist=${ID}`);
  });
});
