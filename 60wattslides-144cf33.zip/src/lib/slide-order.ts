/** Keep the deck's array order and stored position values in sync. */
export function reorderSlides<T extends { id: string; position: number }>(slides: T[], activeId: string, overId: string): T[] {
  const from = slides.findIndex((slide) => slide.id === activeId);
  const to = slides.findIndex((slide) => slide.id === overId);
  if (from < 0 || to < 0 || from === to) return slides;
  const ordered = [...slides];
  const [moving] = ordered.splice(from, 1);
  if (!moving) return slides;
  ordered.splice(to, 0, moving);
  return ordered.map((slide, position) => ({ ...slide, position }));
}