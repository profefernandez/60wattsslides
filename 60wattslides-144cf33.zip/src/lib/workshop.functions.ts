import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const click = z.object({
  slideId: z.string().uuid(),
  sessionTitle: z.string().max(300),
  signupUrl: z.string().url().max(2000),
});

/** Records a registration-button click only if it matches a real session on an enabled workshop slide. */
export const trackWorkshopClick = createServerFn({ method: "POST" })
  .inputValidator((input) => click.parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: slide } = await supabaseAdmin.from("slides").select("kind, enabled, items").eq("id", data.slideId).maybeSingle();
    if (!slide || !slide.enabled || slide.kind !== "workshop" || !Array.isArray(slide.items)) return { ok: false };
    const items = slide.items as { title?: string; signup_url?: string }[];
    const match = items.some((i) => (i.title ?? "") === data.sessionTitle && (i.signup_url ?? "").trim() !== "" && new URL(i.signup_url!.trim()).toString() === data.signupUrl);
    if (!match) return { ok: false };
    await supabaseAdmin.from("workshop_clicks").insert({ slide_id: data.slideId, session_title: data.sessionTitle, signup_url: data.signupUrl });
    return { ok: true };
  });
