import type { Slide, SlideKind } from "@/lib/cms";
import { SUBTITLE_DEFAULT, TITLE_DEFAULT } from "@/lib/slide-text";

export type StarterLayoutId = "hero" | "photo-message" | "person" | "video" | "workshop" | "faq" | "partners" | "text";

export const STARTER_LAYOUTS: { id: StarterLayoutId; label: string; description: string; kind: SlideKind }[] = [
  { id: "hero", label: "Photo introduction", description: "An image, headline and short message", kind: "image" },
  { id: "photo-message", label: "Photo + message", description: "Photo on the left, words on the right", kind: "photo-text" },
  { id: "person", label: "Meet a person", description: "Introduce the person behind the work", kind: "photo-text" },
  { id: "video", label: "Video story", description: "Feature a video with supporting text", kind: "video" },
  { id: "workshop", label: "Workshop", description: "Sessions, dates and registration links", kind: "workshop" },
  { id: "faq", label: "Questions & answers", description: "Answer common questions in one slide", kind: "faq" },
  { id: "partners", label: "Partner logos", description: "Showcase organizations you work with", kind: "logos" },
  { id: "text", label: "Text story", description: "A simple, focused message", kind: "text" },
];

const starterCopy: Record<StarterLayoutId, { title: string; subtitle: string }> = {
  hero: { title: "Your main message", subtitle: "A clear introduction to what you offer. Add a photo and replace this text." },
  "photo-message": { title: "The idea that matters", subtitle: "Explain the benefit in one or two sentences. Add a photo in the editor." },
  person: { title: "Meet the person behind the work", subtitle: "Introduce their role, experience and the people they help. Add an authentic photo." },
  video: { title: "See the story", subtitle: "Add a video link or upload a video and write a short introduction." },
  workshop: { title: "Upcoming workshops", subtitle: "Add each session, its date, description and registration link below." },
  faq: { title: "Frequently asked questions", subtitle: "Replace these sample questions and answers with verified information." },
  partners: { title: "Organizations we work with", subtitle: "Add approved partner logos and descriptions below." },
  text: { title: "One clear takeaway", subtitle: "Write the one thing you want visitors to remember from this slide." },
};

/** A starter is deliberately hidden until the editor verifies its words and media. */
export function createStarterSlide(position: number, id: StarterLayoutId): Slide {
  const layout = STARTER_LAYOUTS.find((item) => item.id === id);
  if (!layout) throw new Error(`Unknown slide layout: ${id}`);
  const copy = starterCopy[id];
  return {
    id: `new-${crypto.randomUUID()}`,
    position,
    kind: layout.kind,
    title: copy.title,
    subtitle: copy.subtitle,
    title_style: { ...TITLE_DEFAULT },
    subtitle_style: { ...SUBTITLE_DEFAULT },
    media_url: "",
    media_alt: "",
    document_path: "",
    document_name: "",
    document_expires_at: null,
    document_max_downloads: 0,
    document_download_count: 0,
    document_retention_days: 30,
    document_allowed_types: ["pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "zip"],
    document_max_upload_mb: 20,
    overlay_opacity: 40,
    items: id === "faq" ? [{ title: "Question goes here", desc: "Replace this with a helpful, verified answer.", meta: "" }] : [],
    enabled: false,
  };
}

export function createStarterOutline(): Slide[] {
  const order: StarterLayoutId[] = ["hero", "person", "photo-message", "workshop", "faq"];
  return order.map((id, position) => createStarterSlide(position, id));
}
