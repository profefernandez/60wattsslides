import { describe, expect, it } from "vitest";
import { clampPan, photoSplit, zoomAt } from "./slide-placement";

describe("photo placement", () => {
  it("keeps the cursor point fixed when zooming", () => {
    const s = zoomAt({ zoom: 100, x: 0, y: 0 }, 2, 75, 50, 100, 100);
    expect(s.zoom).toBe(200);
    expect(s.x).toBe(-25);
    expect(s.y).toBe(0);
  });
  it("clamps zoom and pan", () => {
    expect(zoomAt({ zoom: 390, x: 0, y: 0 }, 2, 50, 50, 100, 100).zoom).toBe(400);
    expect(clampPan({ zoom: 100, x: 500, y: -500 })).toEqual({ zoom: 100, x: 100, y: -100 });
  });
  it("keeps the original split when unset and maps mobile height", () => {
    expect(photoSplit({})).toMatchObject({ "--photo-split": "48%", "--photo-rows": "42%" });
    expect(photoSplit({ media_split: 70 })).toMatchObject({ "--photo-split": "70%", "--photo-rows": "50%" });
  });
});
