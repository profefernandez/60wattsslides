import type { Slide } from "@/lib/cms";

/** One highlightable element on a slide, matching a `data-anchor` attribute in AppView. */
export interface SlideAnchor {
  anchorId: string;
  textContent: string;
}

export interface SlideMapEntry {
  id: string;
  kind: Slide["kind"];
  title: string;
  anchors: SlideAnchor[];
}

/** Stable anchor id: `<slideId>:<part>` where part is title | subtitle | item-N | cta. */
export function anchorId(slideId: string, part: string): string {
  return `${slideId}:${part}`;
}

export type SlideMapSource = Pick<Slide, "id" | "kind" | "title" | "subtitle" | "items" | "enabled" | "position" | "document_path" | "document_name">;

function itemText(slide: SlideMapSource, i: number): string {
  const it = slide.items[i]!;
  const parts = [it.title, it.meta, ...(it.dates ?? []), it.desc];
  if (slide.kind === "workshop") {
    if (typeof it.seats_left === "number") parts.push(`${it.seats_left} seats left${typeof it.capacity === "number" ? ` of ${it.capacity}` : ""}`);
    else if (typeof it.capacity === "number") parts.push(`${it.capacity} seats`);
  }
  return parts.map((p) => (p ?? "").trim()).filter(Boolean).join(" — ");
}

/**
 * Slide map sent to the AI as context. Built from live CMS content (not at build time),
 * so it always matches exactly what AppView renders. Only enabled slides are included.
 */
export function buildSlideMap(slides: SlideMapSource[]): SlideMapEntry[] {
  return slides
    .filter((s) => s.enabled)
    .sort((a, b) => a.position - b.position)
    .map((s) => {
      const anchors: SlideAnchor[] = [];
      if (s.title.trim()) anchors.push({ anchorId: anchorId(s.id, "title"), textContent: s.title.trim() });
      if (s.subtitle.trim() && s.kind !== "list") anchors.push({ anchorId: anchorId(s.id, "subtitle"), textContent: s.subtitle.trim() });
      if (s.kind === "list" || s.kind === "faq" || s.kind === "workshop") {
        s.items.forEach((_, i) => {
          const text = itemText(s, i);
          if (text) anchors.push({ anchorId: anchorId(s.id, `item-${i}`), textContent: text });
        });
      }
      if (s.kind === "logos") {
        s.items.forEach((it, i) => {
          if (it.logo_url && it.title.trim()) anchors.push({ anchorId: anchorId(s.id, `item-${i}`), textContent: `Works with ${it.title.trim()}` });
        });
      }
      if (s.kind === "document" && s.document_path) anchors.push({ anchorId: anchorId(s.id, "cta"), textContent: `Download form for ${s.document_name}` });
      return { id: s.id, kind: s.kind, title: s.title, anchors };
    });
}

export function hasAnchor(map: SlideMapEntry[], slideId: string, anchor?: string): boolean {
  const entry = map.find((m) => m.id === slideId);
  return !!entry && (anchor === undefined || entry.anchors.some((a) => a.anchorId === anchor));
}
