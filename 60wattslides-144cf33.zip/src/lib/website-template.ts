import type { Slide } from "@/lib/cms";

export const SIGNATURE_PORTRAIT = "/manus-storage/split-portrait_52da614a.webp";
export const INTRO_TITLE = "Learn it.\nBuild it.\nDeploy it.";
export const INTRO_SUBTITLE = "AI education & consultation\nfor social workers.";

export function isLegacyIntro(title: string): boolean {
  return /learn it/i.test(title) && /deploy it/i.test(title);
}

/** A reversible view-layer update to the imported first slide; the CMS saves it when edited. */
export function applyInitialSplitTemplate(slides: Slide[]): Slide[] {
  const first = slides.findIndex((slide) => slide.enabled);
  if (first < 0 || !isLegacyIntro(slides[first]!.title)) return slides;
  return slides.map((slide, index) => index !== first ? slide : {
    ...slide,
    kind: "photo-text" as const,
    title: INTRO_TITLE,
    subtitle: INTRO_SUBTITLE,
    media_url: SIGNATURE_PORTRAIT,
    media_alt: "Portrait of a person seated in a bright office",
    title_style: {
      ...slide.title_style,
      size: "extra-large" as const,
      family: "sans" as const,
      color: "light" as const,
      align: "left" as const,
      weight: "bold" as const,
      readability: "none" as const,
      accent_line: "Build it.",
      media_fit: "cover" as const,
      media_shape: "full" as const,
      media_split: 50,
      actions: [],
    },
    subtitle_style: {
      ...slide.subtitle_style,
      size: "medium" as const,
      family: "sans" as const,
      color: "light" as const,
      align: "left" as const,
      weight: "light" as const,
      readability: "none" as const,
    },
  });
}
