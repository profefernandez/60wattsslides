import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const submission = z.object({
  slideId: z.string().uuid(),
  name: z.string().trim().min(2).max(120),
  email: z.string().trim().email().max(254),
  website: z.string().max(0),
});

export const requestDocument = createServerFn({ method: "POST" })
  .inputValidator((input) => submission.parse(input))
  .handler(async ({ data }) => {
    const { createClient } = await import("@supabase/supabase-js");
    const key = process.env['SUPABASE_PUBLISHABLE_KEY'] ?? process.env['SUPABASE_ANON_KEY'];
    const url = process.env['SUPABASE_URL'];
    if (!key || !url) throw new Error("Downloads are unavailable right now");
    const publicClient = createClient(url, key, {
      auth: { persistSession: false },
      global: { fetch: (input, init) => {
        const headers = new Headers(init?.headers);
        if (key.startsWith("sb_") && headers.get("Authorization") === `Bearer ${key}`) headers.delete("Authorization");
        headers.set("apikey", key);
        return fetch(input, { ...init, headers });
      } },
    });
    const { data: slide, error: readError } = await publicClient.from("slides")
      .select("id, kind, enabled, document_path, document_name, document_expires_at")
      .eq("id", data.slideId).single();
    if (readError || !slide || !slide.enabled || slide.kind !== "document" || !slide.document_path || !slide.document_name || (slide.document_expires_at && new Date(slide.document_expires_at) <= new Date())) {
      throw new Error("This download is not available");
    }
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: claim, error } = await supabaseAdmin.rpc("claim_document_download", {
      _slide_id: slide.id, _name: data.name, _email: data.email,
    });
    if (error || !claim?.[0]) throw new Error(error?.message === "Download limit reached" ? "This download has reached its limit" : "This download is not available");
    const { data: signed, error: signError } = await supabaseAdmin.storage.from("documents")
      .createSignedUrl(claim[0].file_path, 60, { download: claim[0].file_name });
    if (signError || !signed) throw new Error("Download unavailable. Please try again later.");
    return { url: signed.signedUrl };
  });