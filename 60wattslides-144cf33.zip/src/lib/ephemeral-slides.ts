export interface EphemeralSlide {
  id: string;
  sourceSlideId: string;
  anchorId: string;
  title: string;
  body: string;
  label: string;
  advances: number;
  /** A no-match idea, not an answer and never published automatically. */
  draft?: boolean;
  bullets?: string[];
}

/** Source excerpts and topic drafts stay in this visitor's session. */
export function addEphemeral(existing: EphemeralSlide[], slide: EphemeralSlide): EphemeralSlide[] {
  return [...existing.filter((item) => item.anchorId !== slide.anchorId), slide].slice(-2);
}

export function advancePast(existing: EphemeralSlide[], id: string): EphemeralSlide[] {
  return existing.flatMap((item) => item.id !== id ? [item] : item.advances + 1 >= 2 ? [] : [{ ...item, advances: item.advances + 1 }]);
}

export function insertEphemeral<T extends { id: string }>(slides: T[], answers: EphemeralSlide[]): (T | EphemeralSlide)[] {
  const bySource = new Map<string, EphemeralSlide[]>();
  for (const answer of answers) bySource.set(answer.sourceSlideId, [...(bySource.get(answer.sourceSlideId) ?? []), answer]);
  return [...slides.flatMap((slide) => [slide, ...(bySource.get(slide.id) ?? [])]), ...(bySource.get("end") ?? [])];
}
