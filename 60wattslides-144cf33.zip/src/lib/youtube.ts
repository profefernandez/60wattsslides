const ID_PATTERN = /^[A-Za-z0-9_-]{11}$/;

export function youtubeVideoId(url: string): string | null {
  const trimmed = url.trim();
  if (!trimmed) return null;
  let parsed: URL;
  try {
    parsed = new URL(trimmed);
  } catch {
    return null;
  }
  const host = parsed.hostname.toLowerCase().replace(/^www\.|^m\./, "");
  if (host === "youtu.be") {
    const id = parsed.pathname.split("/").filter(Boolean)[0] ?? "";
    return ID_PATTERN.test(id) ? id : null;
  }
  if (host === "youtube.com" || host === "youtube-nocookie.com") {
    if (parsed.pathname === "/watch") {
      const id = parsed.searchParams.get("v") ?? "";
      return ID_PATTERN.test(id) ? id : null;
    }
    const match = /^\/(embed|shorts|live)\/([A-Za-z0-9_-]{11})(?:\/|$)/.exec(parsed.pathname);
    if (match?.[2]) return match[2];
  }
  return null;
}

export function youtubeEmbedUrl(id: string, options: { autoplay?: boolean } = {}): string {
  const params = new URLSearchParams({ playsinline: "1", rel: "0", modestbranding: "1" });
  if (options.autoplay) {
    params.set("autoplay", "1");
    params.set("mute", "1");
    params.set("loop", "1");
    params.set("playlist", id);
  }
  return `https://www.youtube-nocookie.com/embed/${id}?${params.toString()}`;
}
