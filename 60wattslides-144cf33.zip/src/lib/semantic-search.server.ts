import type { SlideMapEntry } from "@/lib/slide-map";

/** Full-scan, server-local search. No external model or question logging. */
export interface SearchHit {
  anchorId: string;
  slideId: string;
  content: string;
  score: number;
  coverage: number;
  matchedTerms: number;
  queryTerms: number;
}

const STOP = new Set("a an and are as at be by can do does for from how i in is it me my of on or our the this to we what when where which who why will with you your about makes make tell know please available there any".split(" "));
const RELATED: Record<string, string> = {
  cost: "price", fee: "price", pay: "price", tuition: "price", pricing: "price",
  signup: "register", enrol: "register", enroll: "register", join: "register", book: "register",
  date: "schedule", time: "schedule", calendar: "schedule",
  class: "course", program: "course", programme: "course", lesson: "course",
  download: "document", file: "document", pdf: "document", brochure: "document",
  seat: "capacity", spot: "capacity", space: "capacity", full: "capacity",
};

function stem(word: string): string {
  const raw = word.replace(/(ing|edly|ed|ies|es|s)$/, (ending) => ending === "ies" ? "y" : "");
  const base = raw.length >= 3 ? raw : word;
  return RELATED[base] ?? RELATED[word] ?? base;
}

export function searchTokens(text: string): string[] {
  return (text.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "").match(/[a-z0-9]+/g) ?? [])
    .filter((word) => !STOP.has(word))
    .map(stem);
}

function trigrams(word: string): Set<string> {
  const padded = `  ${word} `;
  return new Set(Array.from({ length: Math.max(0, padded.length - 2) }, (_, index) => padded.slice(index, index + 3)));
}

function similarity(a: string, b: string): number {
  if (a === b) return 1;
  if (Math.min(a.length, b.length) < 4) return 0;
  const left = trigrams(a), right = trigrams(b);
  let shared = 0;
  left.forEach((part) => { if (right.has(part)) shared++; });
  return shared / (left.size + right.size - shared);
}

export function localSearch(map: SlideMapEntry[], question: string, limit = 5): SearchHit[] {
  const query = [...new Set(searchTokens(question))];
  if (!query.length) return [];
  const docs = map.flatMap((slide) => slide.anchors.map((anchor) => ({
    anchorId: anchor.anchorId,
    slideId: slide.id,
    content: anchor.textContent,
    words: searchTokens(`${slide.title} ${anchor.textContent}`),
  })));
  const count = docs.length;
  if (!count) return [];
  const average = docs.reduce((sum, doc) => sum + doc.words.length, 0) / count || 1;
  const frequency = new Map<string, number>();
  docs.forEach((doc) => new Set(doc.words).forEach((term) => frequency.set(term, (frequency.get(term) ?? 0) + 1)));

  return docs.map((doc) => {
    let score = 0;
    let matchedTerms = 0;
    for (const term of query) {
      const similarities = doc.words.map((word) => similarity(term, word)).filter((value) => value >= 0.75);
      if (!similarities.length) continue;
      matchedTerms++;
      const tf = similarities.reduce((sum, value) => sum + value, 0);
      const idf = Math.log(1 + (count - (frequency.get(term) ?? 0) + 0.5) / ((frequency.get(term) ?? 0) + 0.5));
      score += (idf * tf * 2.2) / (tf + 1.2 * (0.25 + 0.75 * doc.words.length / average));
    }
    const coverage = matchedTerms / query.length;
    return { anchorId: doc.anchorId, slideId: doc.slideId, content: doc.content, score, coverage, matchedTerms, queryTerms: query.length };
  })
    .filter((hit) => hit.score > 0.3 && hit.coverage >= (query.length === 1 ? 1 : query.length === 2 ? 1 : 0.6) && (query.length < 3 || hit.matchedTerms >= 2))
    .sort((a, b) => b.coverage - a.coverage || b.score - a.score)
    .slice(0, limit);
}
