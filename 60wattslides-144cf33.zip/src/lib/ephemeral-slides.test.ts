import { describe, expect, test } from "vitest";
import { addEphemeral, advancePast, insertEphemeral, type EphemeralSlide } from "./ephemeral-slides";

const answer = (id: string, sourceSlideId = "a"): EphemeralSlide => ({ id, sourceSlideId, anchorId: `${id}:title`, title: id, body: "Published text", label: id, advances: 0 });

describe("temporary slide lifecycle", () => {
  test("inserts after the source or at the end", () => {
    expect(insertEphemeral([{ id: "a" }, { id: "b" }], [answer("one"), answer("two", "end")]).map((s) => s.id)).toEqual(["a", "one", "b", "two"]);
  });
  test("retains only two live answers and replaces a repeated anchor", () => {
    expect(addEphemeral(addEphemeral([answer("one")], answer("two")), answer("three")).map((s) => s.id)).toEqual(["two", "three"]);
    expect(addEphemeral([answer("one")], { ...answer("updated"), anchorId: "one:title" }).map((s) => s.id)).toEqual(["updated"]);
  });
  test("evicts the oldest answer in insertion order even after revisiting an anchor", () => {
    const first = addEphemeral(addEphemeral([], answer("one")), answer("two"));
    expect(first).toHaveLength(2);
    expect(addEphemeral(first, answer("three")).map((s) => s.id)).toEqual(["two", "three"]);
    expect(addEphemeral(first, { ...answer("one"), body: "Updated" }).map((s) => [s.id, s.body])).toEqual([["two", "Published text"], ["one", "Updated"]]);
  });
  test("collapses after two forward exits", () => {
    const once = advancePast([answer("one"), answer("two")], "one");
    expect(once.map((s) => [s.id, s.advances])).toEqual([["one", 1], ["two", 0]]);
    expect(advancePast(once, "one").map((s) => s.id)).toEqual(["two"]);
    expect(advancePast([answer("one")], "other")).toHaveLength(1);
  });
});