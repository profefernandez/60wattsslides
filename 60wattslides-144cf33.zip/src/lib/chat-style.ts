import { ArrowRight, ArrowUp, BookOpen, Compass, GraduationCap, Lightbulb, MessageCircle, Search, Send, Sparkles, type LucideIcon } from "lucide-react";
import { isHexColor } from "./slide-text";
import { ACTION_SHAPES, ACTION_STYLES, type ActionShape, type ActionStyle } from "./slide-actions";

export const CHAT_DESIGNS = [
  { value: "pill", label: "Pill" },
  { value: "square", label: "Squared" },
  { value: "line", label: "Underline only" },
  { value: "zigzag", label: "Zigzag edges" },
  { value: "scallop", label: "Scalloped waves" },
  { value: "ticket", label: "Ticket notches" },
  { value: "cut", label: "Cut corners" },
  { value: "offset", label: "Offset shadow" },
] as const;
export type ChatDesign = (typeof CHAT_DESIGNS)[number]["value"];

export const CHAT_SIZES = [
  { value: "slim", label: "Slim" },
  { value: "regular", label: "Regular" },
] as const;
export type ChatSize = (typeof CHAT_SIZES)[number]["value"];

const icon = (value: string, label: string, Icon: LucideIcon) => ({ value, label, icon: Icon });
export const CHAT_ICONS = [
  icon("graduation", "Graduation cap", GraduationCap),
  icon("search", "Search", Search),
  icon("message", "Speech bubble", MessageCircle),
  icon("lightbulb", "Light bulb", Lightbulb),
  icon("compass", "Compass", Compass),
  icon("book", "Book", BookOpen),
  icon("sparkles", "Sparkles", Sparkles),
  icon("none", "No icon", Search),
];
export const SEND_ICONS = [
  icon("send", "Paper plane", Send),
  icon("arrow-right", "Arrow right", ArrowRight),
  icon("arrow-up", "Arrow up", ArrowUp),
  icon("search", "Search", Search),
];

export interface ChatStyle {
  design: ChatDesign;
  size: ChatSize;
  icon: string;
  send_icon: string;
  button_style: ActionStyle;
  button_shape: ActionShape;
  button_color: string;
  bar_color: string;
}

export const CHAT_STYLE_DEFAULT: ChatStyle = {
  design: "pill", size: "slim", icon: "graduation", send_icon: "send", button_style: "solid", button_shape: "pill", button_color: "", bar_color: "",
};

/** Validate saved JSON; unknown values fall back to safe defaults. */
export function chatStyle(value: unknown): ChatStyle {
  const v = (value && typeof value === "object" ? value : {}) as Record<string, unknown>;
  const pick = <T extends string>(list: readonly T[], key: string, fallback: T): T => list.find((x) => x === v[key]) ?? fallback;
  const hex = (key: string) => (typeof v[key] === "string" && isHexColor(v[key] as string) ? (v[key] as string).toLowerCase() : "");
  return {
    design: pick(CHAT_DESIGNS.map((d) => d.value), "design", "pill"),
    size: pick(CHAT_SIZES.map((d) => d.value), "size", "slim"),
    icon: pick(CHAT_ICONS.map((d) => d.value), "icon", "graduation"),
    send_icon: pick(SEND_ICONS.map((d) => d.value), "send_icon", "send"),
    button_style: pick(ACTION_STYLES, "button_style", "solid"),
    button_shape: pick(ACTION_SHAPES, "button_shape", "pill"),
    button_color: hex("button_color"),
    bar_color: hex("bar_color"),
  };
}

export function chatIcon(value: string): LucideIcon | null {
  if (value === "none") return null;
  return CHAT_ICONS.find((i) => i.value === value)?.icon ?? GraduationCap;
}
export function sendIcon(value: string): LucideIcon {
  return SEND_ICONS.find((i) => i.value === value)?.icon ?? Send;
}
