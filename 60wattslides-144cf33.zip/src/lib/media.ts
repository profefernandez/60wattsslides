import { supabase } from "@/integrations/supabase/client";

export async function mediaUrlFor(name: string) {
  const { data, error } = await supabase.storage.from("media").createSignedUrl(name, 60 * 60 * 24 * 365 * 10);
  if (error || !data) throw error ?? new Error("Couldn't use this file");
  return data.signedUrl;
}

export async function uploadMedia(file: File) {
  if (!file.type.startsWith("image/") && !file.type.startsWith("video/")) {
    throw new Error("Choose a photo or video file");
  }
  const name = `${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9.]/g, "_")}`;
  const { error } = await supabase.storage.from("media").upload(name, file, { contentType: file.type });
  if (error) throw error;
  return { name, url: await mediaUrlFor(name) };
}