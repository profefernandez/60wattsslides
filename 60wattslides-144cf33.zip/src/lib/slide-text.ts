import { cn } from "@/lib/utils";

export type TextStyle = {
  /** Named sizes; numeric values from the short-lived point-size editor remain readable. */
  size: number | "small" | "medium" | "large" | "extra-large";
  family: "sans" | "serif" | "mono" | "franklin" | "playfair" | "merriweather" | "montserrat" | "lora" | "space-grotesk";
  /** Preset name or a custom hex color like "#ff8800". */
  color: "light" | "gold" | "coral" | "mint" | (string & {});
  align: "left" | "center" | "right";
  weight: "light" | "normal" | "semibold" | "bold";
  readability: "none" | "shadow" | "backing" | "auto";
  /** Optional whole heading line emphasized in the signature gold on split hero slides. */
  accent_line?: string;
  /** Text-only slide background choice, persisted with the slide's existing JSON style. */
  background_color?: "original" | "charcoal" | "forest" | "ocean" | "berry" | "image";
  /** Text-only slide composition, persisted alongside its title styling. */
  screen_layout?: "centered" | "left-block" | "top-banner" | "split";
  /** Shared slide CTA settings stored with the heading style for all slide kinds. */
  actions?: { label: string; url: string; style?: string | undefined; color?: string | undefined; shape?: string | undefined; brightness?: number | undefined; x?: number | undefined; y?: number | undefined }[];
  /** Position is an offset relative to the slide, in percent of its width/height. */
  offset_x?: number;
  offset_y?: number;
  /** Photo framing lives with the heading style to avoid changing existing slide rows. */
  media_fit?: "cover" | "contain";
  media_zoom?: number;
  media_x?: number;
  media_y?: number;
  /** Photo container shape, border, shadow and photo+text split (30–70% photo width). */
  media_shape?: "full" | "rounded-sm" | "rounded-md" | "rounded-lg" | "circle" | "arch" | "custom";
  media_radius?: number;
  media_border?: "none" | "thin" | "thick";
  media_border_color?: string;
  media_shadow?: "none" | "soft" | "strong";
  media_split?: number;
  /** Video box width as % of the slide (30–100; 100 = fill the slide). */
  video_size?: number;
  /** Video box center as % of the slide (0–100, default 50). */
  video_x?: number;
  video_y?: number;
  /** Logo wall tile size as % of the default (60–160). */
  logo_size?: number;
  /** Logo wall padding inside each tile. */
  logo_padding?: "none" | "tight" | "normal";
  /** "tile" = light tile behind logo; "remove" = strip white background, no tile. */
  logo_bg?: "tile" | "remove";
};

export const SCREEN_LAYOUTS = [
  { value: "centered", label: "Centered" },
  { value: "left-block", label: "Left block" },
  { value: "top-banner", label: "Top banner" },
  { value: "split", label: "Split" },
] as const;

export type ScreenLayout = (typeof SCREEN_LAYOUTS)[number]["value"];

export function screenLayout(value: Partial<TextStyle> | undefined | null): ScreenLayout {
  return value?.screen_layout ?? "centered";
}

export const TITLE_DEFAULT: TextStyle = {
  size: "large", family: "sans", color: "light", align: "center", weight: "bold", readability: "shadow",
};

export const SUBTITLE_DEFAULT: TextStyle = {
  size: "medium", family: "sans", color: "light", align: "center", weight: "light", readability: "shadow",
};

export function sizePreset(size: TextStyle["size"]): "small" | "medium" | "large" | "extra-large" {
  if (typeof size !== "number") return size;
  if (size < 20) return "small";
  if (size < 25) return "medium";
  if (size < 29) return "large";
  return "extra-large";
}

export function textStyle(value: Partial<TextStyle> | undefined | null, kind: "title" | "subtitle"): TextStyle {
  return { ...(kind === "title" ? TITLE_DEFAULT : SUBTITLE_DEFAULT), ...value };
}

const titleSizes = {
  small: "text-2xl @3xl:text-3xl",
  medium: "text-3xl @3xl:text-4xl",
  large: "text-4xl @3xl:text-6xl",
  "extra-large": "text-5xl @3xl:text-7xl",
};

const subtitleSizes = {
  small: "text-base @3xl:text-lg",
  medium: "text-xl @3xl:text-2xl",
  large: "text-2xl @3xl:text-3xl",
  "extra-large": "text-3xl @3xl:text-4xl",
};

export const FONT_OPTIONS: { value: TextStyle["family"]; label: string }[] = [
  { value: "sans", label: "Sans serif" },
  { value: "franklin", label: "Libre Franklin" },
  { value: "montserrat", label: "Montserrat" },
  { value: "space-grotesk", label: "Space Grotesk" },
  { value: "serif", label: "Serif" },
  { value: "playfair", label: "Playfair Display" },
  { value: "merriweather", label: "Merriweather" },
  { value: "lora", label: "Lora" },
  { value: "mono", label: "Monospace" },
];

const families: Record<TextStyle["family"], string> = {
  sans: "font-sans", serif: "font-serif", mono: "font-mono",
  franklin: "font-franklin", playfair: "font-playfair", merriweather: "font-merriweather",
  montserrat: "font-montserrat", lora: "font-lora", "space-grotesk": "font-space-grotesk",
};
const presetColors: Record<string, string> = {
  light: "text-slide-light", gold: "text-slide-gold", coral: "text-slide-coral", mint: "text-slide-mint",
};

export function isHexColor(value: string): boolean {
  return /^#[0-9a-fA-F]{6}$/.test(value);
}

/** Inline color for custom hex choices; preset colors stay on semantic classes. */
export function textStyleCss(value: Partial<TextStyle> | undefined | null, kind: "title" | "subtitle") {
  const style = textStyle(value, kind);
  return style.readability !== "auto" && isHexColor(style.color) ? { color: style.color } : undefined;
}
const alignments: Record<TextStyle["align"], string> = {
  left: "text-left", center: "text-center", right: "text-right",
};
const weights: Record<TextStyle["weight"], string> = {
  light: "font-light", normal: "font-normal", semibold: "font-semibold", bold: "font-bold",
};

export function textStyleClasses(value: Partial<TextStyle> | undefined | null, kind: "title" | "subtitle") {
  const style = textStyle(value, kind);
  return cn(
    "w-full break-words leading-tight",
    (kind === "title" ? titleSizes : subtitleSizes)[sizePreset(style.size)],
    families[style.family] ?? "font-sans", style.readability === "auto" ? "text-slide-light" : presetColors[style.color], alignments[style.align], weights[style.weight],
    (style.readability === "shadow" || style.readability === "auto") && "slide-text-shadow",
  );
}

export function textBackingClasses(value: Partial<TextStyle> | undefined | null, kind: "title" | "subtitle") {
  return ["backing", "auto"].includes(textStyle(value, kind).readability)
    ? "box-decoration-clone rounded-sm bg-slide-backing px-2 py-1"
    : "";
}
