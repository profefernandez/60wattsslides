import { Bookmark, Eye, Highlighter, Sparkles, StickyNote, type LucideIcon } from "lucide-react";
import { isHexColor } from "./slide-text";
import { ACTION_SHAPES, ACTION_STYLES, type ActionShape, type ActionStyle } from "./slide-actions";

export const ANNOTATION_MODES = [
  { value: "after_search", label: "Only after a visitor searches" },
  { value: "always", label: "Always show" },
  { value: "off", label: "Never show" },
] as const;
export type AnnotationMode = (typeof ANNOTATION_MODES)[number]["value"];

export const ANNOTATION_DISPLAYS = [
  { value: "both", label: "Icon and text" },
  { value: "icon", label: "Icon only" },
  { value: "text", label: "Text only" },
] as const;
export type AnnotationDisplay = (typeof ANNOTATION_DISPLAYS)[number]["value"];

export const ANNOTATION_ICONS: { value: string; label: string; icon: LucideIcon }[] = [
  { value: "highlighter", label: "Highlighter", icon: Highlighter },
  { value: "bookmark", label: "Bookmark", icon: Bookmark },
  { value: "sparkles", label: "Sparkles", icon: Sparkles },
  { value: "note", label: "Sticky note", icon: StickyNote },
  { value: "eye", label: "Eye", icon: Eye },
];

export function annotationIcon(value: string): LucideIcon {
  return ANNOTATION_ICONS.find((option) => option.value === value)?.icon ?? Highlighter;
}

export function annotationMode(value: string | undefined): AnnotationMode {
  return ANNOTATION_MODES.find((option) => option.value === value)?.value ?? "after_search";
}

export function annotationDisplay(value: string | undefined): AnnotationDisplay {
  return ANNOTATION_DISPLAYS.find((option) => option.value === value)?.value ?? "both";
}

export function annotationStyle(value: string | undefined): ActionStyle {
  return ACTION_STYLES.find((style) => style === value) ?? "outline";
}

export function annotationShape(value: string | undefined): ActionShape {
  return ACTION_SHAPES.find((shape) => shape === value) ?? "rounded";
}

/** Look of the temporary answer cards the guide inserts into the deck. */
export interface AnswerTemplate {
  /** Card surface: tinted with the accent, a solid panel, or the slide background. */
  background: "tint" | "solid" | "plain";
  border: "dashed" | "solid" | "none";
  /** Custom hex accent; blank keeps the site theme colour. */
  accent: string;
  heading: string;
  font: "sans" | "serif" | "mono";
}

export const ANSWER_TEMPLATE_DEFAULT: AnswerTemplate = {
  background: "tint",
  border: "dashed",
  accent: "",
  heading: "Answered for you",
  font: "sans",
};

export function answerTemplate(value: unknown): AnswerTemplate {
  const raw = (value && typeof value === "object" ? value : {}) as Partial<AnswerTemplate>;
  return {
    background: ["tint", "solid", "plain"].includes(raw.background as string) ? (raw.background as AnswerTemplate["background"]) : ANSWER_TEMPLATE_DEFAULT.background,
    border: ["dashed", "solid", "none"].includes(raw.border as string) ? (raw.border as AnswerTemplate["border"]) : ANSWER_TEMPLATE_DEFAULT.border,
    accent: typeof raw.accent === "string" && isHexColor(raw.accent) ? raw.accent.toLowerCase() : "",
    heading: typeof raw.heading === "string" ? raw.heading : ANSWER_TEMPLATE_DEFAULT.heading,
    font: ["sans", "serif", "mono"].includes(raw.font as string) ? (raw.font as AnswerTemplate["font"]) : ANSWER_TEMPLATE_DEFAULT.font,
  };
}
