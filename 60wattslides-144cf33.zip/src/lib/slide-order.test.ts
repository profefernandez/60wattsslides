import { describe, expect, test } from "vitest";
import { reorderSlides } from "./slide-order";

const slides = ["a", "b", "c", "d"].map((id, position) => ({ id, position, title: id }));

describe("slide ordering", () => {
  test("moves a slide forward and updates stored positions", () => {
    const result = reorderSlides(slides, "a", "c");
    expect(result.map((slide) => [slide.id, slide.position])).toEqual([["b", 0], ["c", 1], ["a", 2], ["d", 3]]);
    expect(result[2]?.title).toBe("a");
    expect(slides[0]?.position).toBe(0);
  });

  test("moves a slide backward, including hidden slides", () => {
    const result = reorderSlides(slides.map((s) => ({ ...s, enabled: s.id !== "b" })), "d", "b");
    expect(result.map((s) => s.id)).toEqual(["a", "d", "b", "c"]);
    expect(result.map((s) => s.position)).toEqual([0, 1, 2, 3]);
    expect(result[2]?.enabled).toBe(false);
  });

  test("unknown and unchanged destinations do not alter the deck", () => {
    expect(reorderSlides(slides, "missing", "b")).toBe(slides);
    expect(reorderSlides(slides, "a", "missing")).toBe(slides);
    expect(reorderSlides(slides, "a", "a")).toBe(slides);
  });
});