import { describe, expect, it } from "vitest";
import type { SlideMapEntry } from "@/lib/slide-map";
import { localSearch } from "@/lib/semantic-search.server";
import { createStarterOutline, createStarterSlide, STARTER_LAYOUTS } from "@/lib/slide-templates";

const map: SlideMapEntry[] = [
  { id: "about", kind: "photo-text", title: "Meet Jason Fernandez", anchors: [
    { anchorId: "about:title", textContent: "Meet Jason Fernandez" },
    { anchorId: "about:subtitle", textContent: "Your social work AI consultant" },
  ] },
  { id: "workshops", kind: "workshop", title: "Upcoming workshops", anchors: [
    { anchorId: "workshops:title", textContent: "Upcoming workshops" },
    { anchorId: "workshops:item-0", textContent: "Hands-on workshop for social workers" },
  ] },
  { id: "learning", kind: "text", title: "60 Watts of Clarity", anchors: [
    { anchorId: "learning:subtitle", textContent: "Your pathway to AI literacy" },
  ] },
];

describe("slide search decisions", () => {
  it("links a specific person question to the source anchor", () => {
    const [first] = localSearch(map, "Who is Jason Fernandez?");
    expect(first?.slideId).toBe("about");
    expect(first?.anchorId).toBe("about:title");
  });
  it("does not imply workshop pricing from a generic workshop mention", () => {
    expect(localSearch(map, "How much do the workshops cost?")).toEqual([]);
  });
  it("does not fabricate a source for unrelated subjects", () => {
    expect(localSearch(map, "What is the capital of Peru?")).toEqual([]);
  });
  it("supports a distinct, meaningful one-word question", () => {
    expect(localSearch(map, "Jason")[0]?.slideId).toBe("about");
  });
});

describe("CMS slide starters", () => {
  it("offers varied starter kinds without publishing placeholders", () => {
    expect(STARTER_LAYOUTS.length).toBeGreaterThan(5);
    for (const layout of STARTER_LAYOUTS) {
      const slide = createStarterSlide(2, layout.id);
      expect(slide.kind).toBe(layout.kind);
      expect(slide.position).toBe(2);
      expect(slide.enabled).toBe(false);
      expect(slide.title.length).toBeGreaterThan(3);
      expect(slide.subtitle.length).toBeGreaterThan(3);
    }
  });
  it("makes an editable five-slide outline without altering the published website", () => {
    const slides = createStarterOutline();
    expect(slides).toHaveLength(5);
    expect(slides.map((slide) => slide.position)).toEqual([0, 1, 2, 3, 4]);
    expect(slides.every((slide) => !slide.enabled)).toBe(true);
    expect(new Set(slides.map((slide) => slide.id)).size).toBe(5);
  });
});
