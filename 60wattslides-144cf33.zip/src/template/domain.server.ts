import { domainToASCII } from "node:url";
import { isIP } from "node:net";
import { database, ownDeck } from "./db.server";

type DomainRow = { hostname: string; status: string; created_at: Date | string };
const databaseCode = (error: unknown) => error && typeof error === "object" && "code" in error ? String(error.code) : "";
export function normalizeHostname(input: string): string {
  if (/[/?#:@\s]/.test(input.trim())) throw new Error("Enter a domain you own, such as www.yourcompany.com (no https:// or path).");
  const hostname = domainToASCII(input.trim().toLowerCase().replace(/\.$/, ""));
  const labels = hostname.split(".");
  if (!hostname || isIP(hostname) || hostname.length > 253 || labels.length < 2 || labels.some((part) => !/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(part)) || /(?:^|\.)(?:localhost|local|invalid|test|manus\.computer)$/.test(hostname)) {
    throw new Error("Enter a domain you own, such as www.yourcompany.com (no https:// or path).");
  }
  return hostname;
}
export async function getOwnerDomainRequest(userId: string): Promise<{ hostname: string; status: string } | null> {
  await ownDeck(userId);
  const rows = await database()<DomainRow[]>`
    SELECT hostname,status,created_at FROM customer_domain_requests WHERE user_id=${userId} LIMIT 1
  `;
  return rows[0] ? { hostname: rows[0].hostname, status: rows[0].status } : null;
}
export async function saveOwnerDomainRequest(userId: string, input: string) {
  const customer = await ownDeck(userId);
  if (customer.entitlement !== "active") throw new Error("A hosted account is required before connecting a domain");
  const hostname = normalizeHostname(input);
  try {
    await database().begin(async (tx) => {
      const claimed = await tx<{ user_id: string }[]>`
        SELECT user_id FROM customer_domain_requests WHERE hostname=${hostname} FOR UPDATE
      `;
      if (claimed[0] && claimed[0].user_id !== userId) throw new Error("That domain is already requested by another account.");
      const current = await tx<DomainRow[]>`
        SELECT hostname,status,created_at FROM customer_domain_requests WHERE user_id=${userId} FOR UPDATE
      `;
      if (current[0]) {
        await tx`UPDATE customer_domain_requests SET hostname=${hostname},status='awaiting-platform-connection' WHERE user_id=${userId}`;
      } else {
        await tx`INSERT INTO customer_domain_requests (user_id,hostname,status) VALUES (${userId},${hostname},'awaiting-platform-connection')`;
      }
    });
  } catch (cause) {
    if (databaseCode(cause) === "23505") throw new Error("That domain is already requested by another account.");
    throw cause;
  }
  return { hostname, status: "awaiting-platform-connection" };
}
