import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { getOwnerDomainRequest, saveOwnerDomainRequest } from "./domain.server";

export const getMyDomainRequest = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth])
  .handler(async ({ context }) => getOwnerDomainRequest(context.userId));
export const submitMyDomainRequest = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ hostname: z.string().min(3).max(253) }).parse(data))
  .handler(async ({ context, data }) => saveOwnerDomainRequest(context.userId, data.hostname));
