import { useEffect, useRef, useState, type CSSProperties } from "react";
import { Globe2, ImagePlus, Link2, Search } from "lucide-react";
import { toast } from "sonner";
import type { DeckTheme, TemplateDeck } from "./deck";
import { getMyDomainRequest, submitMyDomainRequest } from "./domain.functions";
import { SlidesWebsite } from "./renderer";
import "./site-settings.css";

type Props = { deck: TemplateDeck; localMode: boolean; disabled: boolean; onChange: (patch: Partial<DeckTheme>) => void; onLogoUpload: (file: File) => void; onOpenLibrary: () => void };
const fonts: DeckTheme["displayFont"][] = ["Manrope", "Inter", "Source Serif 4", "Playfair Display"];
const DOMAIN_KEY = "slides-website:personal:domain-request:v1";
export function SiteSettings({ deck, localMode, disabled, onChange, onLogoUpload, onOpenLibrary }: Props) {
  const [domain, setDomain] = useState("");
  const [domainState, setDomainState] = useState<"not-requested" | "local-only" | "awaiting-platform-connection">("not-requested");
  const [saving, setSaving] = useState(false);
  const [domainError, setDomainError] = useState("");
  const previewRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(.35);
  useEffect(() => {
    const frame = previewRef.current;
    if (!frame) return;
    const sync = () => setScale(frame.clientWidth / 1100);
    sync(); const observer = new ResizeObserver(sync); observer.observe(frame);
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    if (localMode) { const stored = localStorage.getItem(DOMAIN_KEY); if (stored) { setDomain(stored); setDomainState("local-only"); } return; }
    void getMyDomainRequest().then((result) => { if (result) { setDomain(result.hostname); setDomainState("awaiting-platform-connection"); } }).catch((cause) => setDomainError(cause instanceof Error ? cause.message : "Could not load domain request"));
  }, [localMode]);
  async function requestDomain() {
    setSaving(true); setDomainError("");
    try {
      const hostname = domain.trim().toLowerCase();
      if (!/^(?:[a-z0-9-]+\.)+[a-z]{2,63}$/.test(hostname) || hostname.includes("..")) throw new Error("Enter a domain you own, without https:// or a path.");
      if (localMode) {
        localStorage.setItem(DOMAIN_KEY, hostname); setDomain(hostname); setDomainState("local-only");
        toast.info("This is a saved domain idea. A browser-only site cannot serve a custom domain.");
      } else {
        const result = await submitMyDomainRequest({ data: { hostname } });
        setDomain(result.hostname); setDomainState("awaiting-platform-connection");
        toast.info("Request saved. Platform binding, your DNS record and HTTPS must be completed before it can go live.");
      }
    } catch (cause) { setDomainError(cause instanceof Error ? cause.message : "Could not save this domain request"); }
    finally { setSaving(false); }
  }
  const theme = deck.theme;
  type TextKey = "brandName" | "tagline" | "searchLabel" | "searchPlaceholder" | "searchContext" | "searchMultipleSourcesNotice" | "searchFoundPrefix" | "searchSourceLabel" | "storyLinkLabel" | "noAnswerEyebrow" | "noAnswerSubtitle" | "noAnswerBody" | "noAnswerNotice" | "noAnswerDraftNote";
  const text = (label: string, key: TextKey, rows?: number) => <label className="settings-field">{label}{rows ? <textarea rows={rows} value={theme[key]} disabled={disabled} onChange={(event) => onChange({ [key]: event.target.value })} /> : <input value={theme[key]} disabled={disabled} onChange={(event) => onChange({ [key]: event.target.value })} />}</label>;
  const color = (label: string, key: "ink" | "forest" | "gold" | "paper" | "progressColor" | "searchBackground" | "searchForeground" | "searchButton") => <label className="settings-color" key={key}><input type="color" value={theme[key]} disabled={disabled} onChange={(event) => onChange({ [key]: event.target.value })} /><span>{label}</span><code>{theme[key]}</code></label>;
  const toggle = (label: string, key: "showProgress" | "showCounter" | "showArrows" | "showPause" | "showSearch") => <label className="settings-toggle" key={key}><span>{label}</span><input type="checkbox" checked={theme[key]} disabled={disabled} onChange={(event) => onChange({ [key]: event.target.checked })} /></label>;
  return <main className="settings-workspace"><header><span>APPLIES TO YOUR WHOLE WEBSITE</span><h1>Site Settings</h1><p>Keep your brand and website behavior consistent across all slides.</p></header><div className="settings-layout"><div className="settings-form">
    <section><h2>Your brand</h2><div className="settings-logo">{theme.logoUrl && <img src={theme.logoUrl} alt="Your current logo" />}<div><strong>Website logo</strong><div className="settings-actions"><label><ImagePlus size={16} /> Replace logo<input type="file" hidden accept="image/jpeg,image/png,image/webp,image/gif,image/avif" disabled={disabled} onChange={(event) => { const file = event.target.files?.[0]; if (file) onLogoUpload(file); event.currentTarget.value = ""; }} /></label><button type="button" disabled={disabled} onClick={onOpenLibrary}>Choose from library</button>{theme.logoUrl && <button type="button" disabled={disabled} onClick={() => onChange({ logoUrl: "" })}>Remove</button>}</div></div></div>{text("Company name", "brandName")}{text("Tagline", "tagline")}<h3>Brand colors</h3><div className="settings-colors">{color("Ink", "ink")}{color("Forest", "forest")}{color("Gold", "gold")}{color("Paper", "paper")}</div><div className="settings-two"><label className="settings-field">Headline font<select value={theme.displayFont} disabled={disabled} onChange={(event) => onChange({ displayFont: event.target.value as DeckTheme["displayFont"] })}>{fonts.map((font) => <option key={font}>{font}</option>)}</select></label><label className="settings-field">Body font<select value={theme.bodyFont} disabled={disabled} onChange={(event) => onChange({ bodyFont: event.target.value as DeckTheme["bodyFont"] })}>{fonts.map((font) => <option key={font}>{font}</option>)}</select></label></div></section>
    <section><h2>Story controls</h2><p>Choose the navigation your visitors see.</p>{toggle("Show progress", "showProgress")}{toggle("Show slide count", "showCounter")}{toggle("Show previous/next arrows", "showArrows")}{toggle("Show pause/play", "showPause")}<label className="settings-field">Auto-advance (0 = off)<input type="number" min={0} max={120} value={theme.autoplaySeconds} disabled={disabled} onChange={(event) => onChange({ autoplaySeconds: Math.min(120, Math.max(0, Number(event.target.value))) })} /></label><label className="settings-field">Progress style<select value={theme.progressStyle} disabled={disabled} onChange={(event) => onChange({ progressStyle: event.target.value as DeckTheme["progressStyle"] })}><option value="segments">Segments</option><option value="dots">Dots</option><option value="line">Continuous line</option></select></label>{color("Progress highlight", "progressColor")}</section>
    <section><h2><Search size={20} /> Search & answers</h2>{toggle("Show slide search", "showSearch")}{text("Search label", "searchLabel")}{text("Question placeholder", "searchPlaceholder")}{text("Context line below the search", "searchContext", 2)}<details><summary>Result & unanswered-topic language</summary><div className="settings-copy-fields">{text("Several matching slides", "searchMultipleSourcesNotice", 2)}{text("Match prefix", "searchFoundPrefix")}{text("Result source label", "searchSourceLabel")}{text("Link under a story beat", "storyLinkLabel")}</div><h3>When no published slide answers a question</h3><div className="settings-copy-fields">{text("Draft eyebrow", "noAnswerEyebrow")}{text("Draft supporting text", "noAnswerSubtitle", 2)}{text("Draft body", "noAnswerBody", 3)}{text("Search status message", "noAnswerNotice", 2)}{text("Draft note", "noAnswerDraftNote", 2)}</div></details><details><summary>Search colors</summary><div className="settings-colors">{color("Background", "searchBackground")}{color("Text", "searchForeground")}{color("Button", "searchButton")}</div></details></section>
    <section className="settings-domain"><h2><Globe2 size={21} /> Connect a domain</h2><p>Use a domain you own for a hosted website. A saved name alone does not connect DNS or turn on HTTPS.</p><label className="settings-field">Your domain<input value={domain} disabled={disabled || saving} onChange={(event) => setDomain(event.target.value)} placeholder="www.yourcompany.com" autoComplete="url" /></label><button type="button" onClick={() => void requestDomain()} disabled={disabled || saving || !domain.trim()}><Link2 size={17} /> {saving ? "Saving…" : "Save domain request"}</button>{!localMode && disabled && <p className="settings-domain-note">An active hosted account is needed to save a domain request.</p>}{domainError && <p role="alert" className="settings-error">{domainError}</p>}<div className="settings-domain-status"><strong>Status: {domainState === "not-requested" ? "Not connected" : domainState === "local-only" ? "Saved idea — browser-only" : "Awaiting platform connection"}</strong><ol><li>Publish a hosted site first; a browser-local site cannot receive a domain.</li><li>The project owner connects the domain in Manus website Settings → Domains and receives the exact DNS record.</li><li>Add that record at your domain provider; wait for a valid HTTPS certificate and working website before using it publicly.</li></ol><a href="https://manus.im/docs/website-builder/custom-domains" target="_blank" rel="noopener noreferrer">Read official domain connection steps ↗</a></div></section>
  </div><aside className="settings-preview"><h2>Live website preview</h2><p>Your settings update the same slide visitors see.</p><div ref={previewRef} style={{ "--settings-scale": scale } as CSSProperties}><SlidesWebsite deck={deck} editorMode selectedIndex={0} /></div></aside></div></main>;
}
