import { z } from "zod";
const color = z.string().regex(/^#[0-9a-fA-F]{6}$/);
const media = z.string().max(2000).refine((value) => !value || value.startsWith("/manus-storage/") || /^local-media:[a-f0-9-]{36}$/.test(value) || /^\/[a-zA-Z0-9/_-]+\.(svg|png|jpe?g|webp|gif|avif)$/.test(value) || /^https:\/\//i.test(value), "Use a secure image or video URL");
const link = z.string().max(2000).refine((value) => !value || /^(https:\/\/|mailto:|tel:|#search$|#slide:[a-zA-Z0-9_-]{1,100}$)/i.test(value), "Use a secure link, a slide, or the search bar");
const item = z.object({ id: z.string().max(100), title: z.string().max(160), body: z.string().max(700), meta: z.string().max(100), url: link });
const interactionCopy = z.object({
  kicker: z.string().max(160).default(""), prompt: z.string().max(350).default(""), idle: z.string().max(350).default(""), correct: z.string().max(350).default(""), incorrect: z.string().max(350).default(""), reset: z.string().max(100).default(""), complete: z.string().max(350).default(""),
  title: z.string().max(200).default(""), intro: z.string().max(500).default(""), empty: z.string().max(500).default(""), optionHint: z.string().max(160).default(""), unavailable: z.string().max(120).default(""), resultLabel: z.string().max(160).default(""),
  formTitle: z.string().max(300).default(""), nameLabel: z.string().max(120).default(""), emailLabel: z.string().max(120).default(""), messageLabel: z.string().max(160).default(""), consent: z.string().max(500).default(""),
  submit: z.string().max(100).default(""), sending: z.string().max(100).default(""), helper: z.string().max(350).default(""), confirmed: z.string().max(500).default(""),
  pairsLabel: z.string().max(80).default(""), turnSingular: z.string().max(80).default(""), turnPlural: z.string().max(80).default(""),
}).default({});
export const slideSchema = z.object({
  id: z.string().min(1).max(100), layout: z.enum(["split", "profile", "editorial", "programs", "workshops", "faq", "closing", "video", "quiz", "memory", "html", "booking", "pathway"]),
  visible: z.boolean(), eyebrow: z.string().max(120), title: z.string().max(250), accentLine: z.string().max(100),
  headlineColors: z.array(color).max(12).default([]),
  subtitle: z.string().max(400), body: z.string().max(1200), image: media, imageAlt: z.string().max(200),
  imagePositionX: z.number().min(0).max(100), imagePositionY: z.number().min(0).max(100), mobileFocusY: z.number().min(0).max(100), imageFit: z.enum(["cover", "contain"]),
  videoUrl: media, background: color, foreground: color, accent: color, imageWidth: z.number().min(25).max(75), copyInset: z.number().min(20).max(140),
  overlay: z.number().min(0).max(85), titleSize: z.number().min(28).max(150),
  headlineFont: z.enum(["theme", "Manrope", "Inter", "Source Serif 4", "Playfair Display"]), headlineWeight: z.number().int().min(300).max(900), bodySize: z.number().min(12).max(48),
  alignment: z.enum(["left", "center", "right"]), showRule: z.boolean(), ctaLabel: z.string().max(100), ctaUrl: link,
  ctaButtons: z.array(z.object({ id: z.string().uuid(), label: z.string().max(100), url: link, style: z.enum(["gold", "outline"]) })).max(4).default([]),
  items: z.array(item).max(12),
  quizQuestion: z.string().max(350).default(""),
  quizChoices: z.array(z.object({ id: z.string().min(1).max(100), text: z.string().max(240), correct: z.boolean() })).max(8).default([]),
  quizExplanation: z.string().max(700).default(""),
  gamePairs: z.array(z.object({ id: z.string().min(1).max(100), term: z.string().max(120), meaning: z.string().max(120) })).max(6).default([]),
  htmlContent: z.string().max(40000).default(""),
  bookingSlots: z.array(z.object({
    id: z.string().min(1).max(100), label: z.string().min(1).max(160),
    startsAt: z.string().max(40).refine((value) => !value || (!Number.isNaN(Date.parse(value)) && /Z$/.test(value)), "Use a valid workshop date and time"),
    capacity: z.number().int().min(1).max(10000),
  })).max(12).default([]),
  pathQuestion: z.string().max(240).default(""),
  pathChoices: z.array(z.object({ id: z.string().min(1).max(100), label: z.string().min(1).max(160), outcome: z.string().min(1).max(500), nextStep: z.string().min(1).max(500) })).max(6).default([]),
  interactionCopy,
  interactionCopyCustomized: z.boolean().default(false),
}).superRefine((slide, context) => {
  if (slide.layout === "quiz" && (slide.quizChoices.length < 2 || slide.quizChoices.filter((choice) => choice.correct).length !== 1)) {
    context.addIssue({ code: "custom", message: "Quiz slides need at least two choices and exactly one correct answer" });
  }
  if (slide.layout === "memory" && slide.gamePairs.length < 1) {
    context.addIssue({ code: "custom", message: "Memory games need at least one matching pair" });
  }
  if (slide.visible && slide.layout === "booking" && !slide.bookingSlots.some((slot) => slot.startsAt)) {
    context.addIssue({ code: "custom", message: "Add a workshop date and time before making a booking slide visible" });
  }
  if (slide.visible && slide.layout === "pathway" && slide.pathChoices.length < 2) {
    context.addIssue({ code: "custom", message: "Tailored-path slides need at least two choices" });
  }
});
export const deckSchema = z.object({
  version: z.literal(1),
  theme: z.object({
    brandName: z.string().min(1).max(80), tagline: z.string().max(140), logoUrl: media,
    ink: color, forest: color, gold: color, paper: color,
    displayFont: z.enum(["Manrope", "Inter", "Source Serif 4", "Playfair Display"]),
    bodyFont: z.enum(["Manrope", "Inter", "Source Serif 4", "Playfair Display"]),
    progressStyle: z.enum(["segments", "dots", "line"]), progressColor: color,
    showProgress: z.boolean(), showCounter: z.boolean(), showArrows: z.boolean(), showPause: z.boolean(), showSearch: z.boolean(),
    autoplaySeconds: z.number().int().min(0).max(120), searchLabel: z.string().max(80), searchPlaceholder: z.string().max(160),
    searchBackground: color, searchForeground: color, searchButton: color, searchRadius: z.number().min(0).max(999),
    searchContext: z.string().max(500).default("Answers link to published slides. Missing topics stay unverified."),
    searchMultipleSourcesNotice: z.string().max(300).default("Choose a source slide below."),
    searchFoundPrefix: z.string().max(120).default("Found in"),
    searchSourceLabel: z.string().max(120).default("FOUND IN SLIDE"),
    storyLinkLabel: z.string().max(120).default("Follow this thread"),
    noAnswerEyebrow: z.string().max(160).default("NEW TOPIC · NOT PUBLISHED"),
    noAnswerSubtitle: z.string().max(500).default("This presentation does not contain a verified answer yet."),
    noAnswerBody: z.string().max(1200).default("This slide exists only in your current visit. An owner can research the question and add an answer before publishing it."),
    noAnswerNotice: z.string().max(500).default("Unpublished topic slide added. No answer was invented."),
    noAnswerDraftNote: z.string().max(200).default("Draft for this visit only · verify before publishing"),
  }),
  slides: z.array(slideSchema).min(1).max(60),
}).superRefine((deck, context) => {
  const ids = deck.slides.map((slide) => slide.id);
  if (new Set(ids).size !== ids.length) context.addIssue({ code: "custom", message: "Slide IDs must be unique" });
});

export function assertPublishableDeck(deck: z.infer<typeof deckSchema>, now = Date.now()): void {
  const visible = new Set(deck.slides.filter((slide) => slide.visible).map((slide) => slide.id));
  if (visible.size === 0) throw new Error("Make at least one slide visible before publishing your website.");
  for (const slide of deck.slides.filter((item) => item.visible)) {
    if (slide.layout === "booking" && !slide.bookingSlots.some((slot) => Date.parse(slot.startsAt) > now)) {
      throw new Error(`“${slide.title.replace(/\n/g, " ")}” needs a future workshop time before publishing. Change its date or hide the slide.`);
    }
    for (const url of [slide.ctaUrl, ...slide.ctaButtons.map((button) => button.url)]) {
      if (url.startsWith("#slide:") && !visible.has(url.slice(7))) {
        throw new Error(`“${slide.title.replace(/\n/g, " ")}” has a button to a hidden or deleted slide. Edit its destination before publishing.`);
      }
    }
  }
}
