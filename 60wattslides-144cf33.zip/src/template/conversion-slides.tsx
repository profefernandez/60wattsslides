import { useState, type FormEvent } from "react";
import { ArrowRight, CalendarDays, CheckCircle2, Sparkles } from "lucide-react";
import { resolvedInteractionCopy, type TemplateDeck, type TemplateSlide } from "./deck";
import { bookingTime, type LeadInput } from "./crm";
import { submitLocalLead } from "./crm-local";
import { submitLead } from "./crm.functions";
import "./conversion-slides.css";

type Props = { slide: TemplateSlide; deck: TemplateDeck; siteSlug?: string | undefined; editorMode: boolean };

export function ConversionSlide({ slide, deck, siteSlug, editorMode }: Props) {
  const [selected, setSelected] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [consent, setConsent] = useState(false);
  const [website, setWebsite] = useState("");
  const [pending, setPending] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [error, setError] = useState("");
  const booking = slide.layout === "booking";
  const options = booking ? slide.bookingSlots : slide.pathChoices;
  const current = options.find((option) => option.id === selected);
  const copy = resolvedInteractionCopy(slide);
  const consentText = copy.consent.replaceAll("{brand}", deck.theme.brandName);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!siteSlug || editorMode || !current || !consent || pending) return;
    setPending(true); setError("");
    try {
      const input: LeadInput = { slug: siteSlug, slideId: slide.id, kind: booking ? "booking" : "pathway", choiceId: current.id, name, email, message, consent: true, website };
      if (siteSlug === "personal") await submitLocalLead(input, deck);
      else await submitLead({ data: input });
      setCompleted(true);
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Could not send the request. Please try again."); }
    finally { setPending(false); }
  }

  return <section className="sw-conversion sw-interactive" aria-label={booking ? "Request a workshop seat" : "Find your next step"}>
    <div className="sw-conversion-title">{booking ? <CalendarDays size={23} aria-hidden="true" /> : <Sparkles size={23} aria-hidden="true" />}<h2>{booking ? copy.title : slide.pathQuestion || copy.title}</h2></div>
    <p className="sw-conversion-subtitle">{copy.intro}</p>
    {options.length === 0 && <p className="sw-conversion-empty">{copy.empty}</p>}
    <div className="sw-conversion-options">
      {options.map((option) => {
        const expired = booking && "startsAt" in option && (!option.startsAt || Date.parse(option.startsAt) <= Date.now());
        return <button key={option.id} type="button" className={selected === option.id ? "is-chosen" : ""} aria-pressed={selected === option.id} disabled={expired || completed} onClick={() => { setSelected(option.id); setError(""); }}>
          <strong>{option.label}</strong>
          {booking && "startsAt" in option && <span>{bookingTime(option.startsAt)}{expired ? ` · ${copy.unavailable}` : ` · ${copy.optionHint}`}</span>}
          {!booking && <ArrowRight size={20} aria-hidden="true" />}
        </button>;
      })}
    </div>
    {!booking && current && "outcome" in current && <div className="sw-conversion-result" aria-live="polite"><span>{copy.resultLabel}</span><h3>{current.outcome}</h3><p>{current.nextStep}</p></div>}
    {editorMode && <p className="sw-conversion-preview-note">Editing preview: visitor forms are disabled here. Publish, then open your website to try the complete interaction.</p>}
    {!editorMode && completed && <p className="sw-conversion-confirm" role="status"><CheckCircle2 size={21} />{copy.confirmed}</p>}
    {!editorMode && siteSlug && current && !completed && <form className="sw-conversion-form" onSubmit={(event) => void submit(event)}>
      <p>{copy.formTitle}</p>
      <label>{copy.nameLabel}<input value={name} onChange={(event) => setName(event.target.value)} required minLength={2} maxLength={120} autoComplete="name" /></label>
      <label>{copy.emailLabel}<input type="email" value={email} onChange={(event) => setEmail(event.target.value)} required maxLength={254} autoComplete="email" /></label>
      <label>{copy.messageLabel}<textarea value={message} onChange={(event) => setMessage(event.target.value)} maxLength={500} rows={2} /></label>
      <label className="sw-conversion-trap" aria-hidden="true">Website<input type="text" tabIndex={-1} autoComplete="off" value={website} onChange={(event) => setWebsite(event.target.value)} /></label>
      <label className="sw-conversion-consent"><input type="checkbox" checked={consent} onChange={(event) => setConsent(event.target.checked)} required /> {consentText}</label>
      {error && <p role="alert" className="sw-conversion-error">{error}</p>}
      <button type="submit" disabled={pending || !consent}>{pending ? copy.sending : copy.submit}</button>
      <small>{copy.helper}</small>
    </form>}
  </section>;
}
