import { randomUUID } from "node:crypto";
import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { ownDeck, publishedDeck, publishDraft, recordAsset, saveDraft } from "./db.server";
import { deckSchema } from "./schema";

export const getMyDeck = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => ownDeck(context.userId));

export const saveMyDeck = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ deck: deckSchema, revision: z.number().int().nonnegative() }).parse(data))
  .handler(async ({ context, data }) => ({ revision: await saveDraft(context.userId, data.deck, data.revision) }));

export const publishMyDeck = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ deck: deckSchema, revision: z.number().int().nonnegative() }).parse(data))
  .handler(async ({ context, data }) => publishDraft(context.userId, data.deck, data.revision));

export const getPublishedDeck = createServerFn({ method: "GET" })
  .inputValidator((data: unknown) => z.object({ slug: z.string().regex(/^[a-z0-9-]{1,96}$/) }).parse(data))
  .handler(async ({ data }) => publishedDeck(data.slug));

const uploadInput = z.object({ name: z.string().min(1).max(120), contentType: z.string().max(100), size: z.number().int().positive().max(100 * 1024 * 1024) });
export const requestMediaUpload = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => uploadInput.parse(data))
  .handler(async ({ context, data }) => {
    const customer = await ownDeck(context.userId);
    if (customer.entitlement !== "active") throw new Error("An active subscription is required to upload media");
    const isImage = /^image\/(jpeg|png|webp|gif|avif)$/.test(data.contentType);
    const isVideo = /^video\/(mp4|webm|quicktime)$/.test(data.contentType);
    if (!isImage && !isVideo) throw new Error("Choose an image or MP4/WebM video");
    if (isImage && data.size > 20 * 1024 * 1024) throw new Error("Images must be under 20 MB");
    const api = process.env["MANUS_API_URL"], key = process.env["MANUS_API_KEY"];
    if (!api || !key) throw new Error("Media storage is unavailable");
    const safe = data.name.replace(/[^a-zA-Z0-9._-]/g, "-").slice(-70);
    const path = `customers/${context.userId}/${randomUUID()}-${safe}`;
    const result = await fetch(`${api.replace(/\/$/, "")}/v1/storage/presign/put?path=${encodeURIComponent(path)}`, { headers: { Authorization: `Bearer ${key}` } });
    const body = await result.json() as { url?: string; error?: string };
    if (!result.ok || !body.url) throw new Error(body.error || "Could not prepare upload");
    await recordAsset(context.userId, path, data.contentType);
    return { uploadUrl: body.url, assetUrl: `/manus-storage/${path}` };
  });
