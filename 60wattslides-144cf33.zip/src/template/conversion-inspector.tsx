import { Plus, Trash2 } from "lucide-react";
import { resolvedInteractionCopy, type InteractionCopy, type TemplateSlide } from "./deck";

const input = "studio-input";
type Props = { slide: TemplateSlide; onChange: (patch: Partial<TemplateSlide>) => void };
type CopyKey = keyof InteractionCopy;
const localDateTime = (iso: string): string => {
  if (!iso) return "";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  const pad = (value: number) => String(value).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
};
function CopyField({ label, field, rows, slide, onChange }: { label: string; field: CopyKey; rows?: number; slide: TemplateSlide; onChange: Props["onChange"] }) {
  const copy = resolvedInteractionCopy(slide);
  const update = (value: string) => onChange({ interactionCopy: { ...copy, [field]: value }, interactionCopyCustomized: true });
  return <label className="studio-field"><span>{label}</span>{rows ? <textarea className={input} rows={rows} value={copy[field]} onChange={(event) => update(event.target.value)} /> : <input className={input} value={copy[field]} onChange={(event) => update(event.target.value)} />}</label>;
}
function VisitorFormLanguage({ slide, onChange, includeAvailability = false, includeResult = false }: Props & { includeAvailability?: boolean; includeResult?: boolean }) {
  return <details className="studio-copy-controls"><summary>Visitor-facing language</summary><div>
    <CopyField label="Interaction heading" field="title" slide={slide} onChange={onChange} />
    <CopyField label="Introduction" field="intro" rows={2} slide={slide} onChange={onChange} />
    <CopyField label="No choices message" field="empty" rows={2} slide={slide} onChange={onChange} />
    {includeAvailability && <><CopyField label="Available-session hint" field="optionHint" slide={slide} onChange={onChange} /><CopyField label="Unavailable-session label" field="unavailable" slide={slide} onChange={onChange} /></>}
    {includeResult && <CopyField label="Result heading" field="resultLabel" slide={slide} onChange={onChange} />}
    <CopyField label="Form heading" field="formTitle" rows={2} slide={slide} onChange={onChange} />
    <CopyField label="Name label" field="nameLabel" slide={slide} onChange={onChange} />
    <CopyField label="Email label" field="emailLabel" slide={slide} onChange={onChange} />
    <CopyField label="Message label" field="messageLabel" slide={slide} onChange={onChange} />
    <CopyField label="Consent sentence" field="consent" rows={3} slide={slide} onChange={onChange} />
    <p className="studio-interactive-hint">Use <code>{"{brand}"}</code> in the consent sentence to insert your current company name.</p>
    <CopyField label="Submit button" field="submit" slide={slide} onChange={onChange} />
    <CopyField label="Sending state" field="sending" slide={slide} onChange={onChange} />
    <CopyField label="Small form note" field="helper" rows={2} slide={slide} onChange={onChange} />
    <CopyField label="Confirmation message" field="confirmed" rows={3} slide={slide} onChange={onChange} />
  </div></details>;
}
export function ConversionInspector({ slide, onChange }: Props) {
  if (slide.layout === "booking") return <section className="studio-interactive-fields" aria-label="Workshop booking settings">
    <h3 className="studio-section-title">Workshop booking</h3>
    <p className="studio-interactive-hint">Add your real dates before making this slide visible. Times you enter use your browser’s time zone; visitors see dates in theirs. A request appears in your CRM; it is not an automatic confirmation or payment. Confirm a request in CRM to reserve a seat.</p>
    {slide.bookingSlots.map((slot, index) => <div className="studio-option-row" key={slot.id}>
      <strong>Workshop {index + 1}</strong>
      <label className="studio-field"><span>Workshop name</span><input className={input} value={slot.label} maxLength={160} onChange={(event) => onChange({ bookingSlots: slide.bookingSlots.map((item) => item.id === slot.id ? { ...item, label: event.target.value } : item) })} /></label>
      <label className="studio-field"><span>Date and start time</span><input className={input} type="datetime-local" value={localDateTime(slot.startsAt)} onChange={(event) => onChange({ bookingSlots: slide.bookingSlots.map((item) => item.id === slot.id ? { ...item, startsAt: event.target.value ? new Date(event.target.value).toISOString() : "" } : item) })} /></label>
      <label className="studio-field"><span>Maximum confirmed seats</span><input className={input} type="number" min={1} max={10000} value={slot.capacity} onChange={(event) => onChange({ bookingSlots: slide.bookingSlots.map((item) => item.id === slot.id ? { ...item, capacity: Math.max(1, Math.min(10000, Number(event.target.value) || 1)) } : item) })} /></label>
      <button type="button" className="studio-secondary" onClick={() => onChange({ bookingSlots: slide.bookingSlots.filter((item) => item.id !== slot.id) })}><Trash2 size={17} /> Remove workshop</button>
    </div>)}
    <button type="button" className="studio-secondary" disabled={slide.bookingSlots.length >= 12} onClick={() => onChange({ bookingSlots: [...slide.bookingSlots, { id: crypto.randomUUID(), label: "New workshop", startsAt: "", capacity: 12 }] })}><Plus size={17} /> Add a workshop date</button>
    <VisitorFormLanguage slide={slide} onChange={onChange} includeAvailability />
  </section>;
  if (slide.layout === "pathway") return <section className="studio-interactive-fields" aria-label="Tailored-path settings">
    <h3 className="studio-section-title">A path made for each visitor</h3>
    <p className="studio-interactive-hint">Write the choices and the helpful next step for each. A visitor sees their answer immediately, with no AI guesses and no email required. A follow-up request goes to your CRM only with their consent.</p>
    <label className="studio-field"><span>The question visitors answer</span><input className={input} value={slide.pathQuestion} maxLength={240} onChange={(event) => onChange({ pathQuestion: event.target.value })} /></label>
    {slide.pathChoices.map((choice, index) => <div className="studio-option-row" key={choice.id}>
      <strong>Path {index + 1}</strong>
      <label className="studio-field"><span>Visitor choice</span><input className={input} value={choice.label} maxLength={160} onChange={(event) => onChange({ pathChoices: slide.pathChoices.map((item) => item.id === choice.id ? { ...item, label: event.target.value } : item) })} /></label>
      <label className="studio-field"><span>What they discover</span><textarea className={input} value={choice.outcome} maxLength={500} rows={2} onChange={(event) => onChange({ pathChoices: slide.pathChoices.map((item) => item.id === choice.id ? { ...item, outcome: event.target.value } : item) })} /></label>
      <label className="studio-field"><span>Your recommended next step</span><textarea className={input} value={choice.nextStep} maxLength={500} rows={2} onChange={(event) => onChange({ pathChoices: slide.pathChoices.map((item) => item.id === choice.id ? { ...item, nextStep: event.target.value } : item) })} /></label>
      <button type="button" className="studio-secondary" disabled={slide.pathChoices.length <= 2} onClick={() => onChange({ pathChoices: slide.pathChoices.filter((item) => item.id !== choice.id) })}><Trash2 size={17} /> Remove path</button>
    </div>)}
    <button type="button" className="studio-secondary" disabled={slide.pathChoices.length >= 6} onClick={() => onChange({ pathChoices: [...slide.pathChoices, { id: crypto.randomUUID(), label: "Another need", outcome: "A clear way forward.", nextStep: "Let's talk about it." }] })}><Plus size={17} /> Add a path</button>
    <VisitorFormLanguage slide={slide} onChange={onChange} includeResult />
  </section>;
  return null;
}
