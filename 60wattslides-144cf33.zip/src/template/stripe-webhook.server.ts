import Stripe from "stripe";
import type { TransactionSql } from "postgres";
import { database } from "./db.server";

const customerId = (value: string | Stripe.Customer | Stripe.DeletedCustomer | null): string | null => typeof value === "string" ? value : value?.id ?? null;
const subscriptionId = (value: string | Stripe.Subscription | null): string | null => typeof value === "string" ? value : value?.id ?? null;
const entitlement = (status: string) => status === "active" || status === "trialing" ? "active" : status === "past_due" ? "past_due" : "none";
const terminalStatus = (status: string) => status === "canceled" || status === "incomplete_expired";

type SubscriptionSnapshot = { userId: string; customerId: string | null; subscriptionId: string; status: string };
type RetrievedSubscription = { id: string; customer: string | Stripe.Customer | Stripe.DeletedCustomer | null; status: string };
type WebhookOptions = { stripe?: Stripe; retrieveSubscription?: (subscriptionId: string) => Promise<RetrievedSubscription> };

/**
 * Applies Stripe's currently retrieved subscription state. Do not pass raw webhook
 * status here: Stripe event timestamps have only second precision and can arrive out of order.
 */
export async function applySubscriptionSnapshot(tx: TransactionSql, snapshot: SubscriptionSnapshot) {
  const nextEntitlement = entitlement(snapshot.status);
  await tx`
    UPDATE customer_decks
    SET stripe_customer_id=${snapshot.customerId},stripe_subscription_id=${snapshot.subscriptionId},entitlement_status=${nextEntitlement},
        stripe_checkout_session_id=CASE WHEN ${terminalStatus(snapshot.status)} THEN NULL ELSE stripe_checkout_session_id END,
        stripe_checkout_expires_at=CASE WHEN ${terminalStatus(snapshot.status)} THEN 0 ELSE stripe_checkout_expires_at END
    WHERE user_id=${snapshot.userId}
      AND (stripe_subscription_id IS NULL OR stripe_subscription_id=${snapshot.subscriptionId} OR entitlement_status IN ('none','past_due'))
  `;
}

export async function handleStripeEvent(raw: Buffer, signature: string, options: WebhookOptions = {}): Promise<void> {
  const key = process.env["STRIPE_SECRET_KEY"], secret = process.env["STRIPE_WEBHOOK_SECRET"];
  if (!key || !secret) throw new Error("Stripe webhook is not configured");
  const stripe = options.stripe ?? new Stripe(key);
  const event = stripe.webhooks.constructEvent(raw, signature, secret);
  await database().begin(async (tx) => {
    const claim = await tx<{ event_id: string }[]>`
      INSERT INTO stripe_events (event_id) VALUES (${event.id})
      ON CONFLICT (event_id) DO NOTHING
      RETURNING event_id
    `;
    if (!claim.length) return;
    let userId: string | undefined;
    let receivedSubscription: string | null = null;
    let receivedCustomer: string | null = null;
    if (event.type === "checkout.session.completed") {
      const session = event.data.object as Stripe.Checkout.Session;
      userId = session.metadata?.["user_id"];
      receivedSubscription = subscriptionId(session.subscription);
      receivedCustomer = customerId(session.customer);
      if (!userId || !receivedSubscription || session.client_reference_id !== userId) return;
    } else if (["customer.subscription.created", "customer.subscription.updated", "customer.subscription.deleted"].includes(event.type)) {
      const eventSubscription = event.data.object as Stripe.Subscription;
      userId = eventSubscription.metadata?.["user_id"];
      receivedSubscription = eventSubscription.id;
      receivedCustomer = customerId(eventSubscription.customer);
      if (!userId) return;
    } else return;

    // Always retrieve the present Stripe state. A stale active event received after
    // a deletion is reconciled to its now-canceled subscription instead of reactivating access.
    const current = options.retrieveSubscription
      ? await options.retrieveSubscription(receivedSubscription)
      : await stripe.subscriptions.retrieve(receivedSubscription);
    await applySubscriptionSnapshot(tx, {
      userId,
      customerId: customerId(current.customer) ?? receivedCustomer,
      subscriptionId: current.id,
      status: current.status,
    });
  });
}
