import { z } from "zod";
import type { TemplateDeck } from "./deck";
import { leadInputSchema, leadStageSchema, type Lead, type LeadInput, type LeadStage } from "./crm";

export const PERSONAL_CRM_KEY = "slides-website:personal:crm:v1";
const rowSchema = z.object({
  id: z.string(), createdAt: z.string(), kind: z.enum(["booking", "pathway"]),
  name: z.string(), email: z.string(), message: z.string(), slideId: z.string(),
  slideTitle: z.string(), choiceId: z.string(), choiceLabel: z.string(),
  stage: leadStageSchema, notes: z.string(),
});
export const personalCrmBackupSchema = z.array(rowSchema).max(1000);
const withLock = async <T>(callback: () => T | Promise<T>): Promise<T> =>
  navigator.locks?.request ? navigator.locks.request("slides-website:personal:crm", callback) : callback();

export function getLocalLeads(): Lead[] {
  const raw = localStorage.getItem(PERSONAL_CRM_KEY);
  if (!raw) return [];
  return personalCrmBackupSchema.parse(JSON.parse(raw));
}

export async function submitLocalLead(input: LeadInput, published: TemplateDeck): Promise<void> {
  const data = leadInputSchema.parse(input);
  if (data.website) return; // Discard common bot submissions without showing a public error.
  if (data.slug !== "personal") throw new Error("This is not your browser-private website.");
  const slide = published.slides.find((item) => item.id === data.slideId && item.visible && item.layout === data.kind);
  if (!slide) throw new Error("This slide is not available on the published site.");
  const choice = data.kind === "booking" ? slide.bookingSlots.find((item) => item.id === data.choiceId) : slide.pathChoices.find((item) => item.id === data.choiceId);
  if (!choice) throw new Error("Choose an available option.");
  if (data.kind === "booking" && (!("startsAt" in choice) || Date.parse(choice.startsAt) <= Date.now())) throw new Error("This workshop time is no longer available.");
  await withLock(() => {
    const rows = getLocalLeads();
    if (rows.length >= 1000) throw new Error("CRM is full. Export your contacts as CSV before collecting more enquiries.");
    if (data.kind === "booking") {
      const holds = rows.filter((row) => row.kind === "booking" && row.slideId === slide.id && row.choiceId === data.choiceId && row.stage !== "archived");
      if (holds.some((row) => row.email.toLowerCase() === data.email.toLowerCase())) throw new Error("A request for this email and session already exists.");
      if ("capacity" in choice && holds.filter((row) => row.stage === "confirmed").length >= choice.capacity) throw new Error("This workshop has no confirmed seats left. Choose a different time.");
    }
    const lead: Lead = {
      id: crypto.randomUUID(), createdAt: new Date().toISOString(), kind: data.kind,
      name: data.name, email: data.email.toLowerCase(), message: data.message,
      slideId: slide.id, slideTitle: slide.title.replace(/\n/g, " "), choiceId: data.choiceId,
      choiceLabel: choice.label, stage: "new", notes: "",
    };
    localStorage.setItem(PERSONAL_CRM_KEY, JSON.stringify([lead, ...rows]));
  });
}

export async function updateLocalLead(id: string, stage: LeadStage, notes: string): Promise<void> {
  leadStageSchema.parse(stage);
  if (notes.length > 2000) throw new Error("Notes must be under 2000 characters.");
  await withLock(() => {
    const rows = getLocalLeads();
    const lead = rows.find((row) => row.id === id);
    if (!lead) throw new Error("This contact was not found.");
    if (stage === "confirmed" && lead.stage !== "confirmed") {
      if (lead.kind !== "booking") throw new Error("Only workshop requests can become confirmed bookings.");
      const raw = localStorage.getItem("slides-website:personal:project:v2");
      const published: TemplateDeck | null = raw ? JSON.parse(raw).published : null;
      const slot = published?.slides.find((slide) => slide.id === lead.slideId)?.bookingSlots.find((item) => item.id === lead.choiceId);
      if (!slot || Date.parse(slot.startsAt) <= Date.now()) throw new Error("The requested workshop time is no longer available.");
      if (rows.filter((row) => row.id !== id && row.slideId === lead.slideId && row.choiceId === lead.choiceId && row.stage === "confirmed").length >= slot.capacity) throw new Error("This session has no confirmed seats left.");
    }
    localStorage.setItem(PERSONAL_CRM_KEY, JSON.stringify(rows.map((row) => row.id === id ? { ...row, stage, notes } : row)));
  });
}

const safeCell = (value: string): string => {
  const safe = /^[=+@\-\t\r]/.test(value) ? `'${value}` : value;
  return `"${safe.replace(/"/g, '""')}"`;
};
export function crmCsv(leads: Lead[]): Blob {
  const columns = ["createdAt", "kind", "name", "email", "choiceLabel", "message", "stage", "notes", "slideTitle"] as const;
  const lines = [columns.join(","), ...leads.map((lead) => columns.map((column) => safeCell(lead[column])).join(","))];
  return new Blob(["\ufeff", lines.join("\r\n")], { type: "text/csv;charset=utf-8" });
}
