export const SLIDES_WEBSITE_PLAN = {
  name: "Slides Website",
  description: "A complete seven-slide website and editable customer CMS",
  currency: "usd",
  amountCents: 1999,
  interval: "month" as const,
};
