import { useEffect, useMemo, useRef, useState, type CSSProperties, type FormEvent } from "react";
import { ArrowLeft, ArrowRight, Pause, Play, Search, X } from "lucide-react";
import { newSlide, type TemplateDeck, type TemplateSlide } from "./deck";
import { HtmlCanvas, MemoryMatch, QuizPanel } from "./interactive-slides";
import { ConversionSlide } from "./conversion-slides";
import { youtubeEmbed } from "./media";
import { searchDeck, type SlideMatch } from "./search";
import "./template.css";

type Props = { deck: TemplateDeck; siteSlug?: string; editorMode?: boolean; selectedIndex?: number; onNavigate?: (index: number) => void; className?: string };
const safeLink = (value: string) => /^(https:\/\/|mailto:|tel:|#search$|#slide:[a-zA-Z0-9_-]{1,100}$)/i.test(value) ? value : "";
const lineMarkup = (slide: TemplateSlide) => {
  const legacyAccent = slide.headlineColors.length === 0;
  return slide.title.split("\n").map((line, i) => (
    <span className="sw-title-line" key={`${i}-${line}`} style={{ color: slide.headlineColors[i] || (legacyAccent && line.trim() === slide.accentLine.trim() && slide.accentLine.trim() ? slide.accent : undefined) }}>{line}</span>
  ));
};

export function SlidesWebsite({ deck, siteSlug, editorMode = false, selectedIndex, onNavigate, className = "" }: Props) {
  const visible = useMemo(() => deck.slides.filter((slide) => editorMode || slide.visible), [deck.slides, editorMode]);
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const [query, setQuery] = useState("");
  const [matches, setMatches] = useState<SlideMatch[]>([]);
  const [draft, setDraft] = useState<TemplateSlide | null>(null);
  const [notice, setNotice] = useState("");
  const [prefersReducedMotion, setPrefersReducedMotion] = useState(false);
  const startX = useRef(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const slides = draft ? [...visible, draft] : visible;
  const active = selectedIndex ?? index;
  const current = slides[Math.min(Math.max(active, 0), slides.length - 1)];
  const theme = deck.theme;
  const setActive = (next: number) => {
    if (!slides.length) return;
    const bounded = (next + slides.length) % slides.length;
    if (selectedIndex === undefined) setIndex(bounded);
    onNavigate?.(bounded);
    setMatches([]);
    setNotice("");
  };
  const renderCta = (label: string, url: string, outline = false, key?: string) => {
    if (!label || !safeLink(url)) return null;
    const className = `sw-cta ${outline ? "sw-cta--outline" : ""}`;
    if (url === "#search" || url.startsWith("#slide:")) return <button type="button" className={className} key={key} onClick={() => {
      if (url === "#search") inputRef.current?.focus();
      else { const next = visible.findIndex((item) => item.id === url.slice(7)); if (next >= 0) setActive(next); }
    }}>{label}<ArrowRight size={18} /></button>;
    return <a className={className} href={url} key={key} target={url.startsWith("https://") ? "_blank" : undefined} rel={url.startsWith("https://") ? "noopener noreferrer" : undefined}>{label}<ArrowRight size={18} /></a>;
  };
  useEffect(() => {
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    const sync = () => setPrefersReducedMotion(media.matches);
    sync(); media.addEventListener("change", sync);
    return () => media.removeEventListener("change", sync);
  }, []);
  useEffect(() => {
    if (selectedIndex !== undefined || paused || prefersReducedMotion || !theme.autoplaySeconds || slides.length < 2 || editorMode || draft || ["quiz", "memory", "html", "video", "booking", "pathway"].includes(current?.layout ?? "")) return;
    const timer = window.setInterval(() => {
      if (document.activeElement === inputRef.current || matches.length || notice) return;
      setIndex((currentIndex) => (currentIndex + 1) % slides.length);
    }, theme.autoplaySeconds * 1000);
    return () => window.clearInterval(timer);
  }, [selectedIndex, paused, prefersReducedMotion, theme.autoplaySeconds, slides.length, editorMode, draft, matches.length, notice, current?.layout]);
  useEffect(() => {
    const handleKey = (event: KeyboardEvent) => {
      const target = event.target;
      if (target instanceof HTMLElement && target.closest("input,textarea,select,[contenteditable='true'],.sw-interactive button")) return;
      if (event.key === "ArrowRight") setActive(active + 1);
      if (event.key === "ArrowLeft") setActive(active - 1);
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [active, slides.length, selectedIndex]);
  const style = {
    "--sw-ink": theme.ink, "--sw-forest": theme.forest, "--sw-gold": theme.gold, "--sw-paper": theme.paper,
    "--sw-progress": theme.progressColor,
    "--sw-display": `"${theme.displayFont}", sans-serif`, "--sw-body": `"${theme.bodyFont}", sans-serif`,
    "--sw-search-bg": theme.searchBackground, "--sw-search-fg": theme.searchForeground,
    "--sw-search-btn": theme.searchButton, "--sw-search-radius": `${theme.searchRadius}px`,
  } as CSSProperties;
  function submit(event: FormEvent) {
    event.preventDefault();
    const question = query.trim();
    if (!question) return;
    const found = searchDeck(deck, question);
    if (found.length) {
      setDraft(null);
      const first = visible.findIndex((slide) => slide.id === found[0]!.slide.id);
      if (first >= 0) setActive(first);
      setMatches(found);
      setNotice(found.length > 1 ? theme.searchMultipleSourcesNotice : `${theme.searchFoundPrefix} ${found[0]!.slide.title.replace(/\n/g, " ")}.`);
    } else {
      const topic = newSlide("editorial", visible.length);
      topic.id = `draft-${Date.now()}`;
      topic.visible = true;
      topic.eyebrow = theme.noAnswerEyebrow;
      topic.title = question.length > 80 ? `${question.slice(0, 77)}…` : question;
      topic.subtitle = theme.noAnswerSubtitle;
      topic.body = theme.noAnswerBody;
      topic.image = "";
      topic.background = theme.forest;
      topic.foreground = "#ffffff";
      topic.accent = theme.gold;
      topic.items = [];
      setDraft(topic);
      setMatches([]);
      setNotice(theme.noAnswerNotice);
      if (selectedIndex === undefined) setIndex(visible.length);
      onNavigate?.(visible.length);
      if (siteSlug && !editorMode) try { sessionStorage.setItem(`slides-website-draft:${siteSlug}`, JSON.stringify({ question, title: topic.title })); } catch { /* Optional browser-only handoff. */ }
    }
    setQuery("");
  }
  if (!current) return <div className={`sw-site sw-empty ${className}`} style={style}>No slides are visible yet.</div>;
  const slideStyle = {
    "--slide-bg": current.background, "--slide-fg": current.foreground, "--slide-accent": current.accent,
    "--slide-photo-width": `${current.imageWidth}%`, "--slide-copy-inset": `${current.copyInset}px`, "--slide-mobile-focus-x": `${current.imagePositionX}%`, "--slide-mobile-focus-y": `${current.mobileFocusY}%`, "--slide-title-size": `${current.titleSize}px`,
    "--slide-heading-font": current.headlineFont === "theme" ? "var(--sw-display)" : `"${current.headlineFont}", serif`,
    "--slide-title-weight": current.headlineWeight, "--slide-body-size": `${current.bodySize}px`, "--slide-overlay": current.overlay / 100,
    textAlign: current.alignment,
  } as CSSProperties;
  const isDraft = current.id.startsWith("draft-");
  const itemLabel = current.layout === "programs" ? "Light path" : current.layout === "workshops" ? "Session ledger" : current.layout === "faq" ? "Question field" : "Story beats";
  const supportsStoryBeats = !["quiz", "memory", "html", "booking", "pathway"].includes(current.layout);
  return (
    <div className={`sw-site ${editorMode ? "sw-editor-preview" : ""} ${className}`} style={style}
      onTouchStart={(event) => { startX.current = event.touches[0]?.clientX ?? 0; }}
      onTouchEnd={(event) => { const dx = (event.changedTouches[0]?.clientX ?? startX.current) - startX.current; if (Math.abs(dx) > 65) setActive(active + (dx < 0 ? 1 : -1)); }}>
      <div key={current.id} className={`sw-slide sw-slide--${current.layout}`} style={slideStyle} aria-label={`Slide ${active + 1} of ${slides.length}: ${current.title.replace(/\n/g, " ")}`}>
        <div className="sw-photo" style={{ backgroundImage: current.image ? `url("${current.image.replace(/"/g, "%22")}")` : undefined, backgroundPosition: `${current.imagePositionX}% ${current.imagePositionY}%`, backgroundSize: current.imageFit }} role={current.image ? "img" : undefined} aria-label={current.image ? current.imageAlt : undefined}>
          <div className="sw-photo-shade" />
        </div>
        <div className="sw-copy" style={{ textAlign: current.alignment, alignItems: current.alignment === "left" ? "flex-start" : current.alignment === "center" ? "center" : "flex-end" }}>
          {current.eyebrow && <p className="sw-eyebrow">{current.eyebrow}</p>}
          <h1 className="sw-headline">{lineMarkup(current)}</h1>
          {current.showRule && <span className="sw-gold-rule" aria-hidden="true" />}
          {current.subtitle && <p className="sw-subtitle">{current.subtitle}</p>}
          {current.body && <p className="sw-body">{current.body}</p>}
          {current.layout === "video" && current.videoUrl && youtubeEmbed(current.videoUrl) && <iframe className="sw-video sw-youtube" src={youtubeEmbed(current.videoUrl)!} title={`${current.title.replace(/\n/g, " ")} video`} sandbox="allow-scripts allow-same-origin allow-presentation" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowFullScreen referrerPolicy="strict-origin-when-cross-origin" />}
          {current.layout === "video" && current.videoUrl && !youtubeEmbed(current.videoUrl) && (current.videoUrl.startsWith("/manus-storage/") || /^https:\/\//.test(current.videoUrl) || current.videoUrl.startsWith("blob:")) && <video className="sw-video" controls playsInline src={current.videoUrl} poster={current.image || undefined} />}
          {current.layout === "quiz" && <QuizPanel key={current.id} slide={current} />}
          {current.layout === "memory" && <MemoryMatch key={current.id} slide={current} />}
          {(current.layout === "booking" || current.layout === "pathway") && <ConversionSlide key={current.id} slide={current} deck={deck} siteSlug={siteSlug} editorMode={editorMode} />}
          {supportsStoryBeats && !!current.items.length && <section className={`sw-items sw-items--${current.layout}`} aria-label={itemLabel}>{current.items.map((item, itemIndex) => <article className="sw-item" key={item.id}><div className="sw-item-marker" aria-hidden="true"><span>{String(itemIndex + 1).padStart(2, "0")}</span><i /></div><div className="sw-item-content">{item.meta && <small>{item.meta}</small>}<h2>{item.title}</h2><p>{item.body}</p>{safeLink(item.url) && <a href={item.url} target="_blank" rel="noopener noreferrer">{theme.storyLinkLabel} <ArrowRight size={14} /></a>}</div></article>)}</section>}
          {renderCta(current.ctaLabel, current.ctaUrl)}
          {current.ctaButtons.length > 0 && <div className="sw-cta-extras">{current.ctaButtons.map((button) => renderCta(button.label, button.url, button.style === "outline", button.id))}</div>}
          {isDraft && <span className="sw-draft-note">{theme.noAnswerDraftNote}</span>}
        </div>
        {current.layout === "html" && <HtmlCanvas slide={current} />}
      </div>
      <header className="sw-header">
        <div className="sw-brand">{theme.logoUrl && <img src={theme.logoUrl} alt="" />}<span><strong>{theme.brandName}</strong><small>{theme.tagline}</small></span></div>
        {theme.showProgress && <nav className={`sw-progress sw-progress--${theme.progressStyle}`} aria-label="Slides">{slides.map((slide, i) => <button type="button" key={slide.id} title={`Slide ${i + 1}: ${slide.title.replace(/\n/g, " ")}`} aria-label={`Go to slide ${i + 1}`} aria-current={i === active ? "step" : undefined} onClick={() => setActive(i)} className={i <= active ? "is-past" : ""}><span /></button>)}</nav>}
        <div className="sw-header-actions">{theme.showCounter && <span className="sw-counter">{String(active + 1).padStart(2, "0")} / {String(slides.length).padStart(2, "0")}</span>}{theme.showPause && theme.autoplaySeconds > 0 && <button className="sw-round sw-pause" type="button" onClick={() => setPaused(!paused)} aria-label={paused ? "Play slides" : "Pause slides"}>{paused ? <Play /> : <Pause />}</button>}</div>
      </header>
      {theme.showArrows && slides.length > 1 && <><button className="sw-arrow sw-arrow--previous" type="button" onClick={() => setActive(active - 1)} aria-label="Previous slide"><ArrowLeft /></button><button className="sw-arrow sw-arrow--next" type="button" onClick={() => setActive(active + 1)} aria-label="Next slide"><ArrowRight /></button></>}
      {theme.showSearch && <div className="sw-search-wrap" id="search">
        <p className="sw-search-context" role="status">{notice || theme.searchContext}</p>
        {matches.length > 0 && <div className="sw-search-results" aria-label="Matching slide sources"><button type="button" onClick={() => setMatches([])} className="sw-results-close" aria-label="Close results"><X size={17} /></button>{matches.map((match) => <button type="button" key={match.slide.id} onClick={() => { const target = visible.findIndex((slide) => slide.id === match.slide.id); if (target >= 0) setActive(target); setNotice(`${theme.searchFoundPrefix} ${match.slide.title.replace(/\n/g, " ")}`); }}><small>{theme.searchSourceLabel} {visible.findIndex((slide) => slide.id === match.slide.id) + 1}</small><strong>{match.slide.title.replace(/\n/g, " ")}</strong><span>“{match.excerpt}”</span></button>)}</div>}
        <form className="sw-search" onSubmit={submit}><Search className="sw-search-icon" aria-hidden="true" /><label htmlFor={`sw-search-${editorMode ? "editor" : "site"}`}>{theme.searchLabel}</label><input ref={inputRef} id={`sw-search-${editorMode ? "editor" : "site"}`} value={query} onChange={(event) => setQuery(event.target.value)} placeholder={theme.searchPlaceholder} maxLength={300} /><button type="submit" aria-label="Search this slide website"><ArrowRight /></button></form>
      </div>}
      <p className="sr-only" role="status" aria-live="polite">{notice}</p>
    </div>
  );
}
