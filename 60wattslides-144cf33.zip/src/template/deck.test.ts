import { describe, expect, it } from "vitest";
import { copyStarterDeck, newSlide, refreshUntouchedStarterPhotos, resolvedInteractionCopy, STARTER_DECK, starterPhotosNeedUpdate } from "./deck";
import { assertPublishableDeck, deckSchema } from "./schema";
import { searchDeck } from "./search";

describe("seven-slide website template", () => {
  it("starts with seven visible and individually editable compositions", () => {
    const deck = deckSchema.parse(copyStarterDeck());
    expect(deck.slides).toHaveLength(7);
    expect(deck.slides.every((slide) => slide.visible)).toBe(true);
    expect(new Set(deck.slides.map((slide) => slide.layout)).size).toBe(7);
    expect(deck.slides[0]?.image).toMatch(/^\/manus-storage\//);
    expect(deck.slides[0]?.accentLine).toBe("Build it.");
    expect(deck.slides[0]?.headlineColors).toEqual(["#fffdf8", "#e7bc66", "#fffdf8"]);
  });
  it("makes independent copies for customers", () => {
    const first = copyStarterDeck(); const second = copyStarterDeck();
    first.theme.brandName = "First company"; first.slides[0]!.title = "A different message";
    expect(second.theme.brandName).toBe(STARTER_DECK.theme.brandName);
    expect(second.slides[0]!.title).toBe(STARTER_DECK.slides[0]!.title);
  });
  it("refreshes only the older untouched sample photos, never a customer-uploaded photo", () => {
    const older = copyStarterDeck();
    older.slides.find((slide) => slide.id === "pathway")!.image = "/manus-storage/async-images/s4AEsHDA1xc8BnXtej654y/image-1.webp";
    older.slides.find((slide) => slide.id === "workshops")!.image = "/manus-storage/studio-room_0a9d7650.webp";
    older.slides.find((slide) => slide.id === "closing")!.image = "/manus-storage/sun-path_ce6f6535.webp";
    older.slides.find((slide) => slide.id === "programs")!.image = "local-media:53e89a6d-9a9e-4262-80b1-f7d37b8dbb99";
    expect(starterPhotosNeedUpdate(older)).toBe(true);
    const refreshed = refreshUntouchedStarterPhotos(older);
    expect(refreshed.slides.find((slide) => slide.id === "pathway")!.image).toBe(STARTER_DECK.slides.find((slide) => slide.id === "pathway")!.image);
    expect(refreshed.slides.find((slide) => slide.id === "workshops")!.image).toBe(STARTER_DECK.slides.find((slide) => slide.id === "workshops")!.image);
    expect(refreshed.slides.find((slide) => slide.id === "closing")!.image).toBe(STARTER_DECK.slides.find((slide) => slide.id === "closing")!.image);
    expect(refreshed.slides.find((slide) => slide.id === "programs")!.image).toBe("local-media:53e89a6d-9a9e-4262-80b1-f7d37b8dbb99");
    expect(starterPhotosNeedUpdate(refreshed)).toBe(false);
  });
  it("adds a fully filled, but hidden, new slide", () => {
    const added = newSlide("faq", 7);
    expect(added.visible).toBe(false);
    expect(added.items.length).toBeGreaterThan(0);
    expect(added.id).not.toBe("questions");
    expect(deckSchema.safeParse({ ...copyStarterDeck(), slides: [...copyStarterDeck().slides, added] }).success).toBe(true);
  });
  it("offers valid prefilled video, quiz, game, and HTML slides without publishing them", () => {
    const deck = copyStarterDeck();
    for (const layout of ["video", "quiz", "memory", "html"] as const) {
      const slide = newSlide(layout, deck.slides.length);
      expect(slide.layout).toBe(layout);
      expect(slide.visible).toBe(false);
      expect(slide.title.trim().length).toBeGreaterThan(0);
      deck.slides.push(slide);
    }
    expect(deck.slides[8]?.quizChoices.filter((choice) => choice.correct)).toHaveLength(1);
    expect(deck.slides[9]?.gamePairs.length).toBeGreaterThanOrEqual(2);
    expect(deck.slides[10]?.htmlContent).toContain("<script>");
    expect(deckSchema.safeParse(deck).success).toBe(true);
  });
  it("offers hidden workshop-booking and tailored-path slides without inventing real events", () => {
    const deck = copyStarterDeck();
    const booking = newSlide("booking", 7);
    const pathway = newSlide("pathway", 8);
    expect(booking.visible).toBe(false);
    expect(booking.bookingSlots[0]?.startsAt).toBe("");
    expect(pathway.visible).toBe(false);
    expect(pathway.pathChoices).toHaveLength(3);
    deck.slides.push(booking, pathway);
    expect(deckSchema.safeParse(deck).success).toBe(true);
    booking.visible = true;
    expect(deckSchema.safeParse(deck).success).toBe(false);
    booking.bookingSlots[0]!.startsAt = new Date(Date.now() + 86400000).toISOString();
    expect(deckSchema.safeParse(deck).success).toBe(true);
    expect(searchDeck(deck, "When is your first workshop?")[0]?.slide.id).toBe(booking.id);
  });
  it("keeps every visible interaction phrase editable while giving older saved decks useful defaults", () => {
    const booking = newSlide("booking", 7);
    const quiz = newSlide("quiz", 8);
    const older = copyStarterDeck();
    delete (older.slides[0] as Partial<typeof older.slides[0]>).interactionCopy;
    delete (older.theme as Partial<typeof older.theme>).searchContext;
    const parsed = deckSchema.parse(older);
    expect(parsed.slides[0]!.interactionCopy).toBeTruthy();
    expect(parsed.theme.searchContext).toContain("published slides");
    expect(resolvedInteractionCopy(booking).submit).toBe("Request my place");
    expect(resolvedInteractionCopy(quiz).incorrect).toBe("Not quite. Try another choice.");
    booking.interactionCopy.submit = "Reserve my seat";
    expect(resolvedInteractionCopy(booking).submit).toBe("Reserve my seat");
    booking.interactionCopy = { ...resolvedInteractionCopy(booking), helper: "" };
    booking.interactionCopyCustomized = true;
    expect(resolvedInteractionCopy(booking).helper).toBe("");
  });
  it("rejects an all-past workshop at publication without corrupting an existing readable draft", () => {
    const deck = copyStarterDeck();
    const booking = newSlide("booking", 7);
    booking.visible = true;
    booking.bookingSlots[0]!.startsAt = new Date(Date.now() - 86400000).toISOString();
    deck.slides.push(booking);
    expect(deckSchema.safeParse(deck).success).toBe(true);
    expect(() => assertPublishableDeck(deck)).toThrow(/future workshop time/);
    booking.bookingSlots[0]!.startsAt = new Date(Date.now() + 86400000).toISOString();
    expect(() => assertPublishableDeck(deck)).not.toThrow();
  });
  it("blocks a visible button to a deleted or hidden destination", () => {
    const deck = copyStarterDeck();
    deck.slides[0]!.ctaButtons = [{ id: crypto.randomUUID(), label: "Meet the team", style: "outline", url: `#slide:${deck.slides[1]!.id}` }];
    expect(() => assertPublishableDeck(deck)).not.toThrow();
    deck.slides[1]!.visible = false;
    expect(() => assertPublishableDeck(deck)).toThrow(/hidden or deleted slide/);
    deck.slides.splice(1, 1);
    expect(() => assertPublishableDeck(deck)).toThrow(/hidden or deleted slide/);
  });
  it("does not publish a site when every slide is intentionally hidden", () => {
    const deck = copyStarterDeck();
    for (const slide of deck.slides) slide.visible = false;
    expect(() => assertPublishableDeck(deck)).toThrow(/at least one slide visible/);
  });
});

describe("source-bound slide search", () => {
  it("quotes a real slide instead of generating an answer", () => {
    const found = searchDeck(copyStarterDeck(), "What programs do you offer?");
    expect(found.length).toBeGreaterThan(0);
    expect(found[0]!.slide.id).toBe("programs");
    expect(found[0]!.excerpt).toBeTruthy();
  });
  it("does not pretend to know missing workshop prices", () => {
    expect(searchDeck(copyStarterDeck(), "What is the workshop price?")).toHaveLength(0);
  });
  it("does not confuse a session topic with a missing date or location", () => {
    expect(searchDeck(copyStarterDeck(), "When are sessions?")).toHaveLength(0);
    expect(searchDeck(copyStarterDeck(), "Where are sessions?")).toHaveLength(0);
  });
  it("quotes an actual date when a slide provides one", () => {
    const deck = copyStarterDeck();
    deck.slides[4]!.body += " Next session: October 12, 2026 at 2 PM.";
    const found = searchDeck(deck, "When are sessions?");
    expect(found[0]?.slide.id).toBe("workshops");
    expect(found[0]?.excerpt).toContain("October 12");
  });
  it("never searches a hidden unpublished slide", () => {
    const deck = copyStarterDeck(); deck.slides[3]!.visible = false;
    expect(searchDeck(deck, "Explore what we can build").every((result) => result.slide.id !== "programs")).toBe(true);
  });
  it("never recommends a quiz distractor as if it were a correct answer", () => {
    const deck = copyStarterDeck();
    const quiz = newSlide("quiz", deck.slides.length); quiz.visible = true;
    deck.slides.push(quiz);
    expect(searchDeck(deck, "upload private case notes")).toHaveLength(0);
    expect(searchDeck(deck, "privacy human judgment")[0]?.slide.id).toBe(quiz.id);
  });
});
