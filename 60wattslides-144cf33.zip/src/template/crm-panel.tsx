import { useCallback, useEffect, useMemo, useState } from "react";
import { CalendarDays, Download, Mail, RefreshCw, Search, Sparkles } from "lucide-react";
import { crmCsv, getLocalLeads, updateLocalLead } from "./crm-local";
import { getMyLeads, updateMyLead } from "./crm.functions";
import type { Lead, LeadStage } from "./crm";
import "./crm-panel.css";

const stages: { value: LeadStage; label: string }[] = [
  { value: "new", label: "New" }, { value: "contacted", label: "Contacted" },
  { value: "confirmed", label: "Confirmed booking" },
  { value: "done", label: "Done" }, { value: "archived", label: "Archived" },
];

export function CrmPanel({ localMode, onOpenSlide, hasSlide }: { localMode: boolean; onOpenSlide?: (slideId: string) => void; hasSlide?: (slideId: string) => boolean }) {
  const [rows, setRows] = useState<Lead[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [stage, setStage] = useState<LeadStage>("new");
  const [notes, setNotes] = useState("");
  const [filter, setFilter] = useState<"all" | "booking" | "pathway">("all");
  const [term, setTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const refresh = useCallback(async () => {
    setLoading(true); setError("");
    try { setRows(localMode ? getLocalLeads() : await getMyLeads()); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Could not open your contacts."); }
    finally { setLoading(false); }
  }, [localMode]);
  useEffect(() => { void refresh(); }, [refresh]);
  useEffect(() => {
    if (!localMode) return;
    const sync = (event: StorageEvent) => { if (event.key === "slides-website:personal:crm:v1") void refresh(); };
    window.addEventListener("storage", sync);
    return () => window.removeEventListener("storage", sync);
  }, [localMode, refresh]);
  const visible = useMemo(() => rows.filter((lead) =>
    (filter === "all" || lead.kind === filter) &&
    `${lead.name} ${lead.email} ${lead.choiceLabel} ${lead.slideTitle}`.toLowerCase().includes(term.toLowerCase()),
  ), [rows, filter, term]);
  const selected = rows.find((lead) => lead.id === selectedId);
  const choose = (lead: Lead) => { setSelectedId(lead.id); setStage(lead.stage); setNotes(lead.notes); setMessage(""); };

  async function saveContact() {
    if (!selected) return;
    setSaving(true); setError(""); setMessage("");
    try {
      if (localMode) await updateLocalLead(selected.id, stage, notes);
      else await updateMyLead({ data: { id: selected.id, stage, notes } });
      await refresh(); setMessage("Contact updated.");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Could not save this contact."); }
    finally { setSaving(false); }
  }
  function exportCsv() {
    const blob = crmCsv(rows);
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url; link.download = `slides-website-contacts-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.append(link); link.click(); link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 30_000);
  }

  return <main className="crm-workspace">
    <header className="crm-head"><div><p className="crm-kicker">YOUR RELATIONSHIPS</p><h1>Contacts & bookings</h1><p>See who requested a workshop or asked about their next step. Your notes stay private.</p></div><div className="crm-head-actions"><button type="button" onClick={() => void refresh()} disabled={loading}><RefreshCw size={20} /> Refresh</button><button type="button" onClick={exportCsv} disabled={!rows.length}><Download size={20} /> Export CSV</button></div></header>
    {localMode && <p className="crm-boundary" role="note">This personal CRM lives in this browser only. Export contacts as CSV or use Project options → Export ZIP before changing devices. ZIP files contain private contact details.</p>}
    {error && <p className="crm-error" role="alert">{error}</p>}
    {message && <p className="crm-success" role="status">{message}</p>}
    <div className="crm-metrics"><div><strong>{rows.length}</strong><span>Total contacts</span></div><div><strong>{rows.filter((row) => row.kind === "booking").length}</strong><span>Workshop requests</span></div><div><strong>{rows.filter((row) => row.stage === "new").length}</strong><span>Needs follow-up</span></div></div>
    <div className="crm-controls"><div className="crm-filter" role="group" aria-label="Filter contacts">{(["all", "booking", "pathway"] as const).map((value) => <button key={value} type="button" aria-pressed={filter === value} onClick={() => setFilter(value)}>{value === "all" ? "All contacts" : value === "booking" ? "Workshops" : "Tailored paths"}</button>)}</div><label className="crm-search"><Search size={20} /><span className="sr-only">Search contacts</span><input value={term} onChange={(event) => setTerm(event.target.value)} placeholder="Search contacts" /></label></div>
    <div className="crm-columns"><section className="crm-list" aria-label="Contacts">
      {loading ? <p className="crm-placeholder">Loading your contacts…</p> : visible.length ? visible.map((lead) => <button key={lead.id} type="button" className={selectedId === lead.id ? "is-selected" : ""} onClick={() => choose(lead)}><span className="crm-kind">{lead.kind === "booking" ? <CalendarDays size={20} /> : <Sparkles size={20} />}{lead.kind === "booking" ? "Workshop" : "Tailored path"}</span><strong>{lead.name}</strong><span>{lead.choiceLabel}</span><small>{new Date(lead.createdAt).toLocaleDateString()} · {stages.find((item) => item.value === lead.stage)?.label}</small></button>) : <div className="crm-placeholder"><strong>{rows.length ? "No matches in this view" : "No contacts yet"}</strong><p>{rows.length ? "Try another search or filter." : "Add a Book a workshop or A path made for you slide, publish it, then open your website to try it. Editor previews never collect contact details."}</p></div>}
    </section><section className="crm-detail" aria-label="Contact details">
      {selected ? <><div className="crm-detail-title"><span>{selected.kind === "booking" ? "WORKSHOP REQUEST" : "FOLLOW-UP ENQUIRY"}</span><h2>{selected.name}</h2><p>{new Date(selected.createdAt).toLocaleString()}</p></div><dl><dt>Email</dt><dd><a href={`mailto:${selected.email}`}><Mail size={19} />{selected.email}</a></dd><dt>From slide</dt><dd>{selected.slideTitle}{onOpenSlide && (hasSlide?.(selected.slideId) === false ? <span className="crm-source-missing">This source slide has been removed.</span> : <button type="button" className="crm-source-link" onClick={() => onOpenSlide(selected.slideId)}>Open source slide ↗</button>)}</dd><dt>{selected.kind === "booking" ? "Requested workshop" : "Chosen path"}</dt><dd>{selected.choiceLabel}</dd>{selected.message && <><dt>Visitor message</dt><dd>{selected.message}</dd></>}</dl><label className="crm-field">Stage<select value={stage} onChange={(event) => setStage(event.target.value as LeadStage)}>{stages.filter((item) => item.value !== "confirmed" || selected.kind === "booking").map((item) => <option key={item.value} value={item.value}>{item.label}</option>)}</select></label><label className="crm-field">Private notes<textarea value={notes} onChange={(event) => setNotes(event.target.value)} rows={5} maxLength={2000} placeholder="Add a reminder or a useful detail for your follow-up." /></label><button className="crm-save" type="button" onClick={() => void saveContact()} disabled={saving || (stage === selected.stage && notes === selected.notes)}>{saving ? "Saving…" : "Save contact"}</button><p className="crm-detail-note">A booking is a request until you mark it Confirmed booking. Changing its stage does not email the visitor; confirm with them yourself.</p></> : <div className="crm-placeholder"><strong>Select a contact</strong><p>Choose someone from the list to see their request, update the stage and leave private notes.</p></div>}
    </section></div>
  </main>;
}
