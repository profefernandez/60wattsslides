import { randomUUID } from "node:crypto";
import { database, ownDeck } from "./db.server";
import { assetUsage, type MediaAsset, youtubeId } from "./media";
import { deckSchema } from "./schema";

type MediaRow = { id: string; kind: MediaAsset["type"]; title: string; asset_url: string; alt_text: string; created_at: Date | string };
function toAsset(row: MediaRow): MediaAsset {
  return { id: row.id, type: row.kind, name: row.title, url: row.asset_url, alt: row.alt_text, createdAt: new Date(row.created_at).toISOString() };
}
export async function listOwnedMedia(userId: string): Promise<MediaAsset[]> {
  await ownDeck(userId);
  const rows = await database()<MediaRow[]>`
    SELECT id,kind,title,asset_url,alt_text,created_at FROM media_assets
    WHERE user_id=${userId} ORDER BY created_at DESC LIMIT 150
  `;
  return rows.map(toAsset);
}
export async function registerOwnedUpload(userId: string, url: string, title: string, alt = ""): Promise<MediaAsset> {
  const customer = await ownDeck(userId);
  if (customer.entitlement !== "active") throw new Error("An active account is required to save media");
  if (!url.startsWith("/manus-storage/customers/") || url.length > 2000) throw new Error("Choose an uploaded file from this account");
  const path = url.slice("/manus-storage/".length);
  const uploads = await database()<{ content_type: string }[]>`
    SELECT content_type FROM customer_assets WHERE user_id=${userId} AND asset_path=${path}
    ORDER BY id DESC LIMIT 1
  `;
  if (!uploads[0]) throw new Error("This upload does not belong to your account");
  const type = uploads[0].content_type.startsWith("image/") ? "image" : uploads[0].content_type.startsWith("video/") ? "video" : null;
  if (!type) throw new Error("Unsupported media type");
  await database()`
    INSERT INTO media_assets (id,user_id,kind,title,asset_url,alt_text)
    VALUES (${randomUUID()}::uuid,${userId},${type},${title},${url},${alt})
    ON CONFLICT (user_id,asset_url) DO UPDATE SET title=EXCLUDED.title,alt_text=EXCLUDED.alt_text
  `;
  const rows = await database()<MediaRow[]>`
    SELECT id,kind,title,asset_url,alt_text,created_at FROM media_assets
    WHERE user_id=${userId} AND asset_url=${url} LIMIT 1
  `;
  return toAsset(rows[0]!);
}
export async function registerOwnedYoutube(userId: string, input: string, title: string): Promise<MediaAsset> {
  const customer = await ownDeck(userId);
  if (customer.entitlement !== "active") throw new Error("An active account is required to save media");
  const videoId = youtubeId(input);
  if (!videoId) throw new Error("Paste a valid YouTube video URL");
  const url = `https://www.youtube.com/watch?v=${videoId}`;
  await database()`
    INSERT INTO media_assets (id,user_id,kind,title,asset_url,alt_text)
    VALUES (${randomUUID()}::uuid,${userId},'youtube',${title},${url},'')
    ON CONFLICT (user_id,asset_url) DO UPDATE SET title=EXCLUDED.title
  `;
  const rows = await database()<MediaRow[]>`
    SELECT id,kind,title,asset_url,alt_text,created_at FROM media_assets
    WHERE user_id=${userId} AND asset_url=${url} LIMIT 1
  `;
  return toAsset(rows[0]!);
}
export async function deleteOwnedMedia(userId: string, assetId: string): Promise<void> {
  await database().begin(async (tx) => {
    // Save/publish obtains an UPDATE lock on this same row. Lock it first, then examine
    // the current JSON snapshots and delete the library row in one transaction.
    const decks = await tx<{ draft_json: unknown; published_json: unknown | null }[]>`
      SELECT draft_json,published_json FROM customer_decks WHERE user_id=${userId} FOR UPDATE
    `;
    if (!decks[0]) throw new Error("This account was not found");
    const rows = await tx<MediaRow[]>`
      SELECT id,kind,title,asset_url,alt_text,created_at FROM media_assets
      WHERE user_id=${userId} AND id=${assetId}::uuid LIMIT 1 FOR UPDATE
    `;
    const asset = rows[0] && toAsset(rows[0]);
    if (!asset) throw new Error("This asset was not found in your library");
    for (const raw of [decks[0].draft_json, decks[0].published_json]) {
      if (!raw) continue;
      const deck = deckSchema.parse(typeof raw === "string" ? JSON.parse(raw) : raw);
      const usage = assetUsage(asset, deck);
      if (usage.logo || usage.slides.length) throw new Error("Remove this asset from its draft and published slides before deleting its library entry");
    }
    await tx`DELETE FROM media_assets WHERE user_id=${userId} AND id=${assetId}::uuid`;
  });
  // Storage bytes are retained: self-hosted media storage gets its own lifecycle step.
}
