import { useEffect, useMemo, useRef, useState } from "react";
import { RotateCcw } from "lucide-react";
import { resolvedInteractionCopy, type TemplateSlide } from "./deck";
import "./interactive-slides.css";

export function QuizPanel({ slide }: { slide: TemplateSlide }) {
  const [chosenId, setChosenId] = useState<string | null>(null);
  useEffect(() => setChosenId(null), [slide.id]);
  const chosen = slide.quizChoices.find((choice) => choice.id === chosenId);
  const copy = resolvedInteractionCopy(slide);
  return <section className="sw-interactive sw-quiz" aria-label="Multiple-choice question">
    {copy.kicker && <span className="sw-interactive-kicker">{copy.kicker}</span>}
    <h2>{slide.quizQuestion || copy.prompt || "Add your question in the editor"}</h2>
    <div className="sw-quiz-choices">{slide.quizChoices.map((choice, index) =>
      <button key={choice.id} type="button" aria-pressed={chosenId === choice.id}
        className={chosenId === choice.id ? choice.correct ? "is-correct" : "is-incorrect" : ""}
        onClick={() => setChosenId(choice.id)}><span>{String.fromCharCode(65 + index)}</span>{choice.text}</button>
    )}</div>
    <div className="sw-quiz-feedback" role="status" aria-live="polite">
      {chosen ? <><strong>{chosen.correct ? copy.correct : copy.incorrect}</strong>{chosen.correct && slide.quizExplanation && <span>{slide.quizExplanation}</span>}</> : <span>{copy.idle}</span>}
    </div>
    {chosen && <button type="button" className="sw-interactive-reset" onClick={() => setChosenId(null)}><RotateCcw size={15} /> {copy.reset}</button>}
  </section>;
}

type MemoryNode = { key: string; pairId: string; face: string };
function stableOrder(key: string): number { let n = 2166136261; for (const char of key) n = Math.imul(n ^ char.charCodeAt(0), 16777619); return n >>> 0; }
export function MemoryMatch({ slide }: { slide: TemplateSlide }) {
  const nodes = useMemo<MemoryNode[]>(() => slide.gamePairs.flatMap((pair) => [
    { key: `${pair.id}:term`, pairId: pair.id, face: pair.term },
    { key: `${pair.id}:meaning`, pairId: pair.id, face: pair.meaning },
  ]).sort((a, b) => stableOrder(a.key) - stableOrder(b.key)), [slide.gamePairs]);
  const [open, setOpen] = useState<string[]>([]);
  const [matched, setMatched] = useState<string[]>([]);
  const [turns, setTurns] = useState(0);
  useEffect(() => { setOpen([]); setMatched([]); setTurns(0); }, [slide.id, nodes]);
  useEffect(() => {
    if (open.length !== 2) return;
    const [first, second] = open.map((key) => nodes.find((node) => node.key === key));
    const timer = window.setTimeout(() => {
      if (first && second && first.pairId === second.pairId) setMatched((previous) => [...previous, first.pairId]);
      setOpen([]);
    }, 900);
    return () => window.clearTimeout(timer);
  }, [open, nodes]);
  const complete = slide.gamePairs.length > 0 && matched.length === slide.gamePairs.length;
  const copy = resolvedInteractionCopy(slide);
  return <section className="sw-interactive sw-memory" aria-label="Memory-match game">
    {copy.kicker && <span className="sw-interactive-kicker">{copy.kicker}</span>}
    <div className="sw-memory-head"><h2>{complete ? copy.complete : copy.prompt}</h2><span>{matched.length}/{slide.gamePairs.length} {copy.pairsLabel} · {turns} {turns === 1 ? copy.turnSingular : copy.turnPlural}</span></div>
    <div className="sw-memory-grid">{nodes.map((node, index) => {
      const revealed = open.includes(node.key) || matched.includes(node.pairId);
      return <button type="button" key={node.key} className={revealed ? "is-revealed" : ""}
        aria-label={revealed ? node.face : `Reveal light ${index + 1}`}
        disabled={open.length === 2 || matched.includes(node.pairId)}
        onClick={() => { if (open.includes(node.key)) return; setOpen((previous) => [...previous, node.key]); if (open.length === 1) setTurns((count) => count + 1); }}>
        {revealed ? node.face : <span aria-hidden="true">✦</span>}
      </button>;
    })}</div>
    <button type="button" className="sw-interactive-reset" onClick={() => { setOpen([]); setMatched([]); setTurns(0); }}><RotateCcw size={15} /> {copy.reset}</button>
    {complete && <p role="status">{copy.confirmed}</p>}
  </section>;
}

const iframePolicy = "default-src 'none'; base-uri 'none'; form-action 'none'; connect-src 'none'; frame-src 'none'; img-src data: blob:; media-src data: blob:; font-src data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'";
export function HtmlCanvas({ slide }: { slide: TemplateSlide }) {
  const frameRef = useRef<HTMLIFrameElement>(null);
  const document = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="${iframePolicy}"></head><body>${slide.htmlContent}</body></html>`;
  useEffect(() => {
    const timer = window.setTimeout(() => { if (frameRef.current) frameRef.current.srcdoc = document; }, 300);
    return () => window.clearTimeout(timer);
  }, [document]);
  return <div className="sw-html-canvas"><iframe ref={frameRef} title={`${slide.title.replace(/\n/g, " ")} interactive HTML`} sandbox="allow-scripts" referrerPolicy="no-referrer" srcDoc={document} /></div>;
}
