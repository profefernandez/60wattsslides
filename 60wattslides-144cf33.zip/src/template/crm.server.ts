import { createHash, randomUUID } from "node:crypto";
import { database } from "./db.server";
import { deckSchema } from "./schema";
import { leadInputSchema, leadStageSchema, type Lead, type LeadInput, type LeadStage } from "./crm";

type CrmRow = {
  id: string; created_at: Date | string; kind: Lead["kind"]; display_name: string; email: string;
  message: string; slide_id: string; slide_title: string; choice_id: string; choice_label: string;
  stage: LeadStage; notes: string;
};
const toLead = (row: CrmRow): Lead => ({
  id: String(row.id), createdAt: new Date(row.created_at).toISOString(),
  kind: row.kind as Lead["kind"], name: String(row.display_name), email: String(row.email),
  message: String(row.message), slideId: String(row.slide_id), slideTitle: String(row.slide_title),
  choiceId: String(row.choice_id), choiceLabel: String(row.choice_label),
  stage: row.stage as LeadStage, notes: String(row.notes),
});
const databaseCode = (error: unknown) => error && typeof error === "object" && "code" in error ? String(error.code) : "";

export async function submitHostedLead(input: LeadInput): Promise<void> {
  const data = leadInputSchema.parse(input);
  if (data.website) return;
  if (data.slug === "personal") throw new Error("Open your private site to submit this form.");
  try {
    await database().begin(async (tx) => {
      const owners = await tx<{ user_id: string; published_json: unknown }[]>`
        SELECT user_id,published_json FROM customer_decks
        WHERE slug=${data.slug} AND entitlement_status='active' AND published_json IS NOT NULL FOR UPDATE
      `;
      const owner = owners[0];
      if (!owner) throw new Error("This website is not currently accepting requests.");
      const published = deckSchema.parse(typeof owner.published_json === "string" ? JSON.parse(owner.published_json) : owner.published_json);
      const slide = published.slides.find((item) => item.id === data.slideId && item.visible && item.layout === data.kind);
      if (!slide) throw new Error("This interaction is not published on the website.");
      const choice = data.kind === "booking" ? slide.bookingSlots.find((item) => item.id === data.choiceId) : slide.pathChoices.find((item) => item.id === data.choiceId);
      if (!choice) throw new Error("Choose an available option.");
      let bookingKey: string | null = null;
      if (data.kind === "booking") {
        if (!("startsAt" in choice) || Date.parse(choice.startsAt) <= Date.now()) throw new Error("This workshop time is no longer available.");
        bookingKey = createHash("sha256").update([owner.user_id, slide.id, choice.id, data.email.toLowerCase()].join("\0")).digest("hex");
        const counts = await tx<{ total: number | string }[]>`
          SELECT COUNT(*) AS total FROM crm_leads
          WHERE user_id=${owner.user_id} AND slide_id=${slide.id} AND choice_id=${choice.id}
            AND kind='booking' AND stage='confirmed'
        `;
        if (Number(counts[0]?.total ?? 0) >= ("capacity" in choice ? choice.capacity : 0)) throw new Error("This workshop has no confirmed seats left. Please choose another time.");
        const sessionHour = await tx<{ total: number | string }[]>`
          SELECT COUNT(*) AS total FROM crm_leads
          WHERE user_id=${owner.user_id} AND slide_id=${slide.id} AND choice_id=${choice.id}
            AND kind='booking' AND created_at > NOW() - INTERVAL '1 hour'
        `;
        if (Number(sessionHour[0]?.total ?? 0) >= 5) throw new Error("This time is receiving many requests. Please try again later or contact the organizer.");
      }
      // The locked owner row above serializes these limits across concurrent requests.
      const emailDay = await tx<{ total: number | string }[]>`
        SELECT COUNT(*) AS total FROM crm_leads
        WHERE user_id=${owner.user_id} AND email=${data.email.toLowerCase()} AND created_at > NOW() - INTERVAL '1 day'
      `;
      if (Number(emailDay[0]?.total ?? 0) >= 3) throw new Error("Please wait before sending another request.");
      const siteHour = await tx<{ total: number | string }[]>`
        SELECT COUNT(*) AS total FROM crm_leads
        WHERE user_id=${owner.user_id} AND created_at > NOW() - INTERVAL '1 hour'
      `;
      if (Number(siteHour[0]?.total ?? 0) >= 25) throw new Error("This site is receiving many requests. Please try again later.");
      await tx`
        INSERT INTO crm_leads (id,user_id,slide_id,slide_title,kind,display_name,email,message,choice_id,choice_label,booking_key)
        VALUES (${randomUUID()}::uuid,${owner.user_id},${slide.id},${slide.title.replace(/\n/g, " ")},${data.kind},${data.name},${data.email.toLowerCase()},${data.message},${choice.id},${choice.label},${bookingKey})
      `;
    });
  } catch (error) {
    if (databaseCode(error) === "23505") throw new Error("A request for this email and workshop already exists.");
    throw error;
  }
}

export async function getHostedLeads(userId: string): Promise<Lead[]> {
  if (!userId || userId.length > 128) throw new Error("Invalid owner account");
  const rows = await database()<CrmRow[]>`SELECT * FROM crm_leads WHERE user_id=${userId} ORDER BY created_at DESC LIMIT 500`;
  return rows.map(toLead);
}

export async function updateHostedLead(userId: string, id: string, stage: LeadStage, notes: string): Promise<void> {
  leadStageSchema.parse(stage);
  if (!userId || userId.length > 128 || !/^[a-f0-9-]{36}$/.test(id) || notes.length > 2000) throw new Error("Invalid CRM update");
  await database().begin(async (tx) => {
    const owners = await tx<{ published_json: unknown | null }[]>`
      SELECT published_json FROM customer_decks WHERE user_id=${userId} FOR UPDATE
    `;
    const leads = await tx<{ kind: string; stage: string; slide_id: string; choice_id: string }[]>`
      SELECT kind,stage,slide_id,choice_id FROM crm_leads WHERE user_id=${userId} AND id=${id}::uuid FOR UPDATE
    `;
    const lead = leads[0];
    if (!lead) throw new Error("This contact was not found in your CRM.");
    if (stage === "confirmed" && lead.stage !== "confirmed") {
      if (lead.kind !== "booking") throw new Error("Only workshop requests can become confirmed bookings.");
      const raw = owners[0]?.published_json;
      const published = raw ? deckSchema.parse(typeof raw === "string" ? JSON.parse(raw) : raw) : null;
      const slot = published?.slides.find((slide) => slide.id === lead.slide_id)?.bookingSlots.find((item) => item.id === lead.choice_id);
      if (!slot || Date.parse(slot.startsAt) <= Date.now()) throw new Error("The requested workshop time is no longer available.");
      const counts = await tx<{ total: number | string }[]>`
        SELECT COUNT(*) AS total FROM crm_leads
        WHERE user_id=${userId} AND slide_id=${lead.slide_id} AND choice_id=${lead.choice_id}
          AND kind='booking' AND stage='confirmed'
      `;
      if (Number(counts[0]?.total ?? 0) >= slot.capacity) throw new Error("This session has no confirmed seats left.");
    }
    await tx`UPDATE crm_leads SET stage=${stage},notes=${notes} WHERE user_id=${userId} AND id=${id}::uuid`;
  });
}
