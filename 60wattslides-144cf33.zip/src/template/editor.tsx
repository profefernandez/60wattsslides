import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Check, ImagePlus, LayoutTemplate, LogOut, Plus, Save, Upload, Video, X } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { newSlide, refreshUntouchedStarterPhotos, starterPhotosNeedUpdate, type DeckTheme, type Layout, type SlideItem, type TemplateDeck, type TemplateSlide } from "./deck";
import { InteractiveInspector } from "./interactive-inspector";
import { ConversionInspector } from "./conversion-inspector";
import { CrmPanel } from "./crm-panel";
import { MediaLibrary } from "./media-library";
import { SiteSettings } from "./site-settings";
import { SlideQuickEditor, type QuickSection } from "./slide-quick-editor";
import { SlideThumbnail } from "./slide-thumbnail";
import { youtubeId } from "./media";
import { addMyYoutube } from "./media.functions";
import { finalizeMyUpload } from "./media.functions";
import { addPersonalLibraryAsset, PERSONAL_STATE_KEY, createPersonalBackup, importPersonalBackup, publishPersonalSite, savePersonalDraft, storePersonalMedia } from "./personal-workspace";
import { getMyDeck, publishMyDeck, requestMediaUpload, saveMyDeck } from "./deck.functions";
import { SlidesWebsite } from "./renderer";
import type { OwnDeck } from "./db.server";
import "./editor.css";
import "./editor-redesign.css";

const layouts: { id: Layout; name: string; hint: string }[] = [
  { id: "split", name: "Signature split", hint: "Photo left · bold dark story" },
  { id: "profile", name: "Portrait story", hint: "Introduce the person behind the work" },
  { id: "editorial", name: "Editorial pathway", hint: "Light paper · image right" },
  { id: "programs", name: "What we do", hint: "Photography and a connected light path" },
  { id: "workshops", name: "Sessions", hint: "Image and a continuous session ledger" },
  { id: "faq", name: "Questions", hint: "A numbered question field" },
  { id: "closing", name: "Closing invitation", hint: "A clear next action" },
  { id: "video", name: "Video story", hint: "A photo/video with editable copy" },
  { id: "quiz", name: "Multiple choice", hint: "Ask a question and reveal a verified answer" },
  { id: "memory", name: "Memory match", hint: "A playable pair-matching lesson" },
  { id: "html", name: "Custom HTML", hint: "A safe canvas for HTML, CSS and JavaScript" },
  { id: "booking", name: "Book a workshop", hint: "Choose a real date and request a seat without leaving the slide" },
  { id: "pathway", name: "A path made for you", hint: "A tailored next step for every visitor, without AI guesses" },
];
const fonts: DeckTheme["displayFont"][] = ["Manrope", "Inter", "Source Serif 4", "Playfair Display"];
const inputClass = "studio-input";
function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) { return <label className="studio-field"><span>{label}</span>{children}{hint && <small>{hint}</small>}</label>; }
function Toggle({ label, checked, onChange }: { label: string; checked: boolean; onChange: (next: boolean) => void }) { return <label className="studio-toggle"><span>{label}</span><input type="checkbox" checked={checked} onChange={(event) => onChange(event.target.checked)} /></label>; }
function Color({ label, value, onChange }: { label: string; value: string; onChange: (color: string) => void }) { return <Field label={label}><span className="studio-color"><input type="color" value={value} onChange={(event) => onChange(event.target.value)} /><input aria-label={`${label} hex value`} className={inputClass} value={value} onChange={(event) => { if (/^#[0-9a-fA-F]{6}$/.test(event.target.value)) onChange(event.target.value); }} /></span></Field>; }
function Range({ label, value, min, max, suffix, onChange }: { label: string; value: number; min: number; max: number; suffix?: string; onChange: (value: number) => void }) { return <Field label={`${label} · ${value}${suffix ?? ""}`}><input className="studio-range" type="range" min={min} max={max} value={value} onChange={(event) => onChange(Number(event.target.value))} /></Field>; }

export function CustomerEditor({ initial, refresh, localMode = false, hasSavedDraft = true }: { initial: OwnDeck; refresh: () => Promise<unknown>; localMode?: boolean; hasSavedDraft?: boolean }) {
  const [deck, setDeck] = useState<TemplateDeck>(() => refreshUntouchedStarterPhotos(structuredClone(initial.deck)));
  const [revision, setRevision] = useState(initial.revision);
  const [selected, setSelected] = useState(0);
  const [workspace, setWorkspace] = useState<"slides" | "media" | "crm" | "settings">("slides");
  const [tab, setTab] = useState<"media" | "design">("media");
  const [device, setDevice] = useState<"desktop" | "mobile">("desktop");
  const previewRef = useRef<HTMLDivElement>(null);
  const [previewScale, setPreviewScale] = useState(0.7);
  const [adding, setAdding] = useState(false);
  const [changingLayout, setChangingLayout] = useState(false);
  const [inspectorOpen, setInspectorOpen] = useState(true);
  const [quickSection, setQuickSection] = useState<QuickSection>("text");
  const [specialOpen, setSpecialOpen] = useState(true);
  const [projectOptionsOpen, setProjectOptionsOpen] = useState(false);
  const [dirty, setDirty] = useState((localMode && !hasSavedDraft) || starterPhotosNeedUpdate(initial.deck));
  const [savedOnce, setSavedOnce] = useState(hasSavedDraft);
  const [stale, setStale] = useState(false);
  const [busy, setBusy] = useState(false);
  const [published, setPublished] = useState(initial.published);
  const [searchDraft, setSearchDraft] = useState<{ question: string; title: string } | null>(null);
  const slide = deck.slides[selected];
  const active = initial.entitlement === "active";
  const canEdit = active || localMode;
  const questionKey = `slides-website-draft:${initial.slug}`;
  useEffect(() => setSpecialOpen(true), [slide?.id, slide?.layout]);
  useEffect(() => { if (window.matchMedia("(max-width: 600px)").matches) setDevice("mobile"); }, []);
  useEffect(() => {
    const frame = previewRef.current;
    if (!frame || adding || changingLayout || workspace !== "slides") return;
    const update = () => setPreviewScale(frame.clientWidth / 1100);
    update();
    const observer = new ResizeObserver(update);
    observer.observe(frame);
    return () => observer.disconnect();
  }, [adding, changingLayout, device, workspace]);
  useEffect(() => { try { const raw = sessionStorage.getItem(questionKey); if (raw) setSearchDraft(JSON.parse(raw)); } catch { /* Browser storage may be disabled. */ } }, [questionKey]);
  useEffect(() => {
    if (!localMode) return;
    const onStorage = (event: StorageEvent) => {
      if (event.key !== PERSONAL_STATE_KEY || !event.newValue) return;
      try { if (JSON.parse(event.newValue).revision !== revision) setStale(true); }
      catch { setStale(true); }
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, [localMode, revision]);
  const changeDeck = (next: TemplateDeck) => { setDeck(next); setDirty(true); };
  const changeSlide = (patch: Partial<TemplateSlide>) => changeDeck({ ...deck, slides: deck.slides.map((item, index) => index === selected ? { ...item, ...patch } : item) });
  const changeLayout = (layout: Layout) => {
    if (!slide) return;
    const preset = newSlide(layout, selected);
    const bookingSlots = slide.bookingSlots.length ? slide.bookingSlots : preset.bookingSlots;
    const mustHide = layout === "booking" && slide.visible && !bookingSlots.some((slot) => slot.startsAt && Date.parse(slot.startsAt) > Date.now());
    changeSlide({ layout, visible: mustHide ? false : slide.visible, quizQuestion: slide.quizQuestion || preset.quizQuestion,
      quizChoices: slide.quizChoices.length ? slide.quizChoices : preset.quizChoices,
      quizExplanation: slide.quizExplanation || preset.quizExplanation,
      gamePairs: slide.gamePairs.length ? slide.gamePairs : preset.gamePairs,
      htmlContent: slide.htmlContent || preset.htmlContent,
      bookingSlots,
      pathQuestion: slide.pathQuestion || preset.pathQuestion,
      pathChoices: slide.pathChoices.length ? slide.pathChoices : preset.pathChoices,
      interactionCopy: slide.layout === layout ? slide.interactionCopy : preset.interactionCopy,
      interactionCopyCustomized: slide.layout === layout ? slide.interactionCopyCustomized : false });
    setChangingLayout(false);
    setTab("media");
    setInspectorOpen(true);
    if (mustHide) toast.info("This slide is hidden until you add a real, future workshop time.");
  };
  const changeTheme = (patch: Partial<DeckTheme>) => {
    const slides = deck.slides.map((item) => ({
      ...item,
      background: patch.paper && item.background === deck.theme.paper ? patch.paper : patch.ink && item.background === deck.theme.ink ? patch.ink : item.background,
      foreground: patch.forest && item.foreground === deck.theme.forest ? patch.forest : item.foreground,
      accent: patch.gold && item.accent === deck.theme.gold ? patch.gold : item.accent,
    }));
    changeDeck({ ...deck, theme: { ...deck.theme, ...patch }, slides });
  };
  const changeItem = (index: number, patch: Partial<SlideItem>) => changeSlide({ items: slide!.items.map((item, i) => i === index ? { ...item, ...patch } : item) });
  const add = (layout: Layout) => {
    const copy = newSlide(layout, selected + 1);
    const slides = [...deck.slides]; slides.splice(selected + 1, 0, copy);
    changeDeck({ ...deck, slides }); setSelected(selected + 1); setAdding(false); setChangingLayout(false); setTab("media"); setInspectorOpen(true);
    toast.info("New slide added hidden. Replace the sample content, then turn on Visible.");
  };
  const move = (direction: number) => { const next = selected + direction; if (next < 0 || next >= deck.slides.length) return; const slides = [...deck.slides]; [slides[selected], slides[next]] = [slides[next]!, slides[selected]!]; changeDeck({ ...deck, slides }); setSelected(next); };
  const remove = () => {
    if (deck.slides.length <= 1) { toast.error("Keep at least one slide."); return; }
    if (!window.confirm(`Delete “${slide?.title.replace(/\n/g, " ")}”? Buttons on other slides pointing here will also be removed. This change takes effect when you save.`)) return;
    const target = `#slide:${slide!.id}`;
    changeDeck({ ...deck, slides: deck.slides.filter((_, i) => i !== selected).map((item) => ({
      ...item, ctaUrl: item.ctaUrl === target ? "" : item.ctaUrl,
      ctaButtons: item.ctaButtons.filter((button) => button.url !== target),
    })) });
    setSelected(Math.max(0, selected - 1));
  };
  async function save() {
    if (localMode) {
      if (stale) { toast.error("Another tab changed your project. Export this version as a ZIP, then reload before editing further."); return; }
      setBusy(true);
      try { const nextRevision = await savePersonalDraft(deck, revision); setRevision(nextRevision); setDirty(false); setSavedOnce(true); toast.success("Draft saved in this browser. Export a ZIP backup for safekeeping."); }
      catch (error) { if (error instanceof Error && error.message.startsWith("Another tab changed")) setStale(true); toast.error(error instanceof Error ? error.message : "Could not save your draft"); }
      finally { setBusy(false); }
      return;
    }
    if (!active) { toast.error("Subscribe to edit your website."); return; }
    setBusy(true);
    try { const result = await saveMyDeck({ data: { deck, revision } }); setRevision(result.revision); setDirty(false); toast.success("Draft saved. Your public site has not changed yet."); }
    catch (error) { toast.error(error instanceof Error ? error.message : "Could not save"); }
    finally { setBusy(false); }
  }
  async function publish() {
    if (localMode) {
      if (stale) { toast.error("Another tab changed your project. Export this version as a ZIP, then reload before publishing."); return; }
      setBusy(true);
      try { const nextRevision = await publishPersonalSite(deck, revision); setRevision(nextRevision); setDirty(false); setSavedOnce(true); setPublished(true); toast.success("Your site is ready at /my-site in this browser. It is not publicly shared."); }
      catch (error) { if (error instanceof Error && error.message.startsWith("Another tab changed")) setStale(true); toast.error(error instanceof Error ? error.message : "Could not publish your local preview"); }
      finally { setBusy(false); }
      return;
    }
    if (!active) { toast.error("Subscribe to publish your website."); return; }
    setBusy(true);
    try { const result = await publishMyDeck({ data: { deck, revision } }); setRevision(result.revision); setDirty(false); setPublished(true); toast.success(`Published at /s/${result.slug}`); }
    catch (error) { toast.error(error instanceof Error ? error.message : "Could not publish"); }
    finally { setBusy(false); }
  }
  async function upload(file: File, target: "image" | "videoUrl" | "logoUrl" | "library") {
    if (localMode) {
      setBusy(true);
      try {
        const url = await storePersonalMedia(file);
        if (target === "logoUrl") changeTheme({ logoUrl: url }); else if (target !== "library") changeSlide({ [target]: url, ...(target === "videoUrl" ? { layout: "video" as Layout } : {}) });
        if (target !== "library") toast.success("Media stored in this browser. Save your draft to keep the slide change.");
      } catch (error) { toast.error(error instanceof Error ? error.message : "Could not store that file"); if (target === "library") throw error; }
      finally { setBusy(false); }
      return;
    }
    if (!active) { toast.error("Subscribe to upload media."); return; }
    setBusy(true);
    try {
      const { uploadUrl, assetUrl } = await requestMediaUpload({ data: { name: file.name, contentType: file.type, size: file.size } });
      const response = await fetch(uploadUrl, { method: "PUT", headers: { "Content-Type": file.type }, body: file });
      if (!response.ok) throw new Error("Upload failed. Try another file.");
      await finalizeMyUpload({ data: { url: assetUrl, title: file.name, alt: "" } });
      if (target === "logoUrl") changeTheme({ logoUrl: assetUrl }); else if (target !== "library") changeSlide({ [target]: assetUrl, ...(target === "videoUrl" ? { layout: "video" as Layout } : {}) });
      if (target !== "library") toast.success("Uploaded. Save your draft to keep this change.");
    } catch (error) { toast.error(error instanceof Error ? error.message : "Upload failed"); if (target === "library") throw error; }
    finally { setBusy(false); }
  }
  async function embedYouTube(url: string) {
    const id = youtubeId(url);
    if (!id) { toast.error("Paste a valid YouTube video link."); return; }
    try {
      if (localMode) addPersonalLibraryAsset({ id: crypto.randomUUID(), type: "youtube", name: "YouTube video", url: `https://www.youtube.com/watch?v=${id}`, alt: "", createdAt: new Date().toISOString() });
      else await addMyYoutube({ data: { url, title: "YouTube video" } });
      changeSlide({ layout: "video", videoUrl: `https://www.youtube.com/watch?v=${id}` });
      toast.success("YouTube video added to your library and this slide.");
    } catch (error) { toast.error(error instanceof Error ? error.message : "Could not embed the video"); }
  }
  async function exportBackup() {
    setBusy(true);
    try {
      const blob = await createPersonalBackup(deck);
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `slides-website-backup-${new Date().toISOString().slice(0, 10)}.zip`;
      document.body.append(link);
      link.click();
      link.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 30_000);
      toast.success("Project ZIP downloaded with media and private contacts. Store it securely.");
    } catch (error) { toast.error(error instanceof Error ? error.message : "Could not export project"); }
    finally { setBusy(false); }
  }
  async function importBackup(file: File) {
    if (!window.confirm("Import this ZIP and replace this browser's current slides, published preview, media library and private CRM contacts? Export a backup first if you want to keep them.")) return;
    setBusy(true);
    try {
      const restored = await importPersonalBackup(file);
      setDeck(restored.deck);
      setSelected(0);
      setTab("media");
      setPublished(restored.published);
      setRevision(restored.revision);
      setDirty(false);
      setSavedOnce(true);
      setStale(false);
      toast.success("Project, media library, contacts and published local preview restored.");
    } catch (error) { toast.error(error instanceof Error ? error.message : "Could not import backup"); }
    finally { setBusy(false); }
  }
  function importQuestion() {
    if (!searchDraft) return;
    const copy = newSlide("editorial", deck.slides.length);
    copy.title = searchDraft.title; copy.subtitle = "Unanswered visitor topic — add a verified source and useful explanation.";
    copy.body = `Visitor question: ${searchDraft.question}`; copy.image = "";
    changeDeck({ ...deck, slides: [...deck.slides, copy] }); setSelected(deck.slides.length); setTab("media");
    setSearchDraft(null); sessionStorage.removeItem(questionKey); toast.info("Imported as a hidden draft. Verify it before making it visible.");
  }
  return <div className="studio studio--focus">
    <header className="studio-topbar">
      <a href="/" className="studio-wordmark"><img src="/60-watts-mark.svg" alt="" /> SLIDES WEBSITE <span>STUDIO</span></a>
      <nav className="studio-workspace-tabs" aria-label="Studio workspace">
        <button type="button" aria-current={workspace === "slides" ? "page" : undefined} onClick={() => setWorkspace("slides")}>Slides</button>
        <button type="button" aria-current={workspace === "media" ? "page" : undefined} onClick={() => setWorkspace("media")}>Media Library</button>
        <button type="button" aria-current={workspace === "crm" ? "page" : undefined} onClick={() => setWorkspace("crm")}>CRM</button>
        <button type="button" aria-current={workspace === "settings" ? "page" : undefined} onClick={() => setWorkspace("settings")}>Site Settings</button>
      </nav>
      <div className="studio-topbar-actions">
        <span className="studio-save-status">{localMode ? stale ? "Updated in another tab" : dirty ? savedOnce ? "Unsaved browser changes" : "New project · save your draft" : "Saved in this browser" : dirty ? "Unsaved changes" : "All draft changes saved"}</span>
        <button type="button" className="studio-project-toggle studio-secondary" aria-expanded={projectOptionsOpen} aria-controls="studio-project-actions" onClick={() => setProjectOptionsOpen(!projectOptionsOpen)}>Project options</button>
        <div className={`studio-utility-actions ${projectOptionsOpen ? "is-open" : ""}`} id="studio-project-actions">
          <a href={localMode ? published ? "/my-site" : "/" : published ? `/s/${initial.slug}` : "/"} target="_blank" rel="noopener noreferrer" className="studio-secondary">{published ? localMode ? "View my site" : "View live website" : "View template"}</a>
          {localMode ? <>
            <button className="studio-secondary studio-backup" type="button" disabled={busy} onClick={() => void exportBackup()}>Export ZIP</button>
            <label className="studio-secondary studio-backup">Import ZIP<input type="file" accept=".zip,application/zip" hidden disabled={busy} onChange={(event) => { const file = event.target.files?.[0]; if (file) void importBackup(file); event.currentTarget.value = ""; }} /></label>
            <span className="studio-backup-note">ZIP contains your private CRM contacts. Store it securely.</span>
          </> : <>
            <a href="/payments" className="studio-secondary">Payments</a>
            <button className="studio-secondary" type="button" onClick={() => void supabase.auth.signOut().then(() => { window.location.href = "/auth"; })}><LogOut size={19} /> Sign out</button>
          </>}
        </div>
        {localMode ? <>
          <button className="studio-primary" type="button" onClick={() => void save()} disabled={!dirty || busy || stale}><Save size={16} /> Save draft</button>
          <button className="studio-primary studio-publish" type="button" onClick={() => void publish()} disabled={busy || stale}><Check size={16} /> Publish locally</button>
        </> : <>
          <button className="studio-primary" type="button" onClick={() => void save()} disabled={!dirty || busy || !active}><Save size={16} /> Save draft</button>
          <button className="studio-primary studio-publish" type="button" onClick={() => void publish()} disabled={busy || !active}><Check size={16} /> Publish</button>
        </>}
      </div>
    </header>
    {localMode && <div className="studio-demo-banner" role="status"><strong>My Studio.</strong> Saved in this browser only; export a ZIP from Project options.</div>}
    {localMode && stale && <div className="studio-draft-alert" role="alert"><span>This project changed in another tab. Export a ZIP of anything unsaved here, then reload to see the newer version. Save and Publish are paused until then.</span></div>}
    {!active && !localMode && <div className="studio-paywall"><strong>Your seven-slide website is ready.</strong> Subscribe for $19.99/month to edit and publish your own copy. <button type="button" onClick={() => void refresh()}>I’ve completed checkout · refresh access</button></div>}
    {searchDraft && <div className="studio-draft-alert"><span>Question saved while browsing this site: “{searchDraft.question}”</span><button type="button" onClick={importQuestion} disabled={!canEdit}>Add hidden slide for review</button><button type="button" onClick={() => { setSearchDraft(null); sessionStorage.removeItem(questionKey); }} aria-label="Dismiss visitor question"><X size={16} /></button></div>}
    {workspace === "crm" ? <CrmPanel localMode={localMode} hasSlide={(id) => deck.slides.some((item) => item.id === id)} onOpenSlide={(id) => { const index = deck.slides.findIndex((item) => item.id === id); if (index >= 0) { setSelected(index); setWorkspace("slides"); setQuickSection("text"); setInspectorOpen(true); } }} /> : workspace === "media" ? <MediaLibrary key={`media-${revision}`} deck={deck} currentSlideId={slide?.id ?? ""} localMode={localMode} disabled={!canEdit || busy} onUpload={(file) => upload(file, "library")} onUseSlide={(asset) => { if (asset.type === "image") changeSlide({ image: asset.url, imageAlt: asset.alt }); else changeSlide({ layout: "video", videoUrl: asset.url }); setWorkspace("slides"); setQuickSection("media"); setInspectorOpen(true); }} onUseLogo={(asset) => { changeTheme({ logoUrl: asset.url }); setWorkspace("settings"); }} onOpenSlide={(id) => { const index = deck.slides.findIndex((item) => item.id === id); if (index >= 0) { setSelected(index); setWorkspace("slides"); setQuickSection("media"); setInspectorOpen(true); } }} /> : workspace === "settings" ? <SiteSettings deck={deck} localMode={localMode} disabled={!canEdit || busy} onChange={changeTheme} onLogoUpload={(file) => void upload(file, "logoUrl")} onOpenLibrary={() => setWorkspace("media")} /> : <div className={`studio-body ${inspectorOpen && !adding && !changingLayout ? "has-inspector" : ""}`}>
      <aside className="studio-outline">
        <div className="studio-aside-head"><h2>Slides <span>{deck.slides.length}</span></h2><p>Choose a slide to edit.</p></div>
        <nav aria-label="Choose a slide to edit">{deck.slides.map((item, index) =>
          <button key={item.id} type="button" aria-current={index === selected ? "page" : undefined} className={`studio-slide-link ${index === selected ? "is-selected" : ""}`} title={item.title.replace(/\n/g, " ")}
            onClick={() => { setSelected(index); setAdding(false); setChangingLayout(false); setTab("media"); }} aria-label={`Slide ${index + 1}: ${item.title.replace(/\n/g, " ")} · ${item.visible ? "Live" : "Hidden draft"}`}>
            <SlideThumbnail slide={item} />
            <span className="studio-thumb-meta"><span>{index + 1} <strong>{item.title.replace(/\n/g, " ") || "Untitled"}</strong></span><small className={item.visible ? "is-live" : "is-hidden"}>{item.visible ? "Live" : "Draft"}</small></span>
          </button>)}</nav>
        <button className="studio-add-button" type="button" onClick={() => { setAdding(true); setChangingLayout(false); }} disabled={!canEdit}><Plus size={18} /> Add a slide</button>
      </aside>
      <main className="studio-preview-area">
        <div className="studio-preview-head"><div><small>YOUR WEBSITE · LIVE PREVIEW</small><h2>{adding ? "Choose a layout" : changingLayout ? `Change slide ${selected + 1}'s layout` : `Slide ${selected + 1} of ${deck.slides.length} · ${slide?.title.replace(/\n/g, " ")}`}</h2></div>
          <div className="studio-preview-controls">
            {!adding && !changingLayout && <>
              <label className="studio-slide-select">Jump to slide<select value={selected} onChange={(event) => { setSelected(Number(event.target.value)); setTab("media"); }} aria-label="Jump to slide">{deck.slides.map((item, index) => <option value={index} key={item.id}>{index + 1}. {item.title.replace(/\n/g, " ").slice(0, 42)}</option>)}</select></label>
              <button type="button" className="studio-edit-toggle" aria-expanded={inspectorOpen} aria-controls="studio-slide-controls" onClick={() => {
                if (window.matchMedia("(max-width: 850px)").matches) {
                  setInspectorOpen(true);
                  window.requestAnimationFrame(() => document.getElementById("studio-slide-controls")?.scrollIntoView({ behavior: "smooth", block: "start" }));
                } else setInspectorOpen(!inspectorOpen);
              }} disabled={!canEdit}><span className="studio-edit-label-desktop">{inspectorOpen ? "Hide controls" : "Edit this slide"}</span><span className="studio-edit-label-mobile">Edit text, media &amp; buttons ↓</span></button>
            </>}
          </div>
        </div>
        {adding || changingLayout ? <><div className="studio-gallery-guide"><button type="button" className="studio-secondary" onClick={() => { setAdding(false); setChangingLayout(false); }}><ArrowLeft size={20} /> Back to preview</button><p>{adding ? "Choose a finished starting point. Your new slide will be hidden until you make it visible." : "Choose a different layout for this slide. Your existing headline, text, and media stay in place."}</p></div><div className="studio-layout-gallery">{layouts.map((layout) => <button type="button" key={layout.id} onClick={() => adding ? add(layout.id) : changeLayout(layout.id)}><span className={`studio-layout-image studio-layout-${layout.id}`} style={{ backgroundImage: `url(${newSlide(layout.id,0).image})` }} /><strong>{layout.name}</strong><small>{layout.hint}</small></button>)}</div></> : <><div ref={previewRef} style={{ "--studio-preview-scale": previewScale } as CSSProperties} className={`studio-preview-frame ${device === "mobile" ? "is-mobile" : ""}`}><SlidesWebsite deck={deck} editorMode selectedIndex={selected} onNavigate={setSelected} /></div><div className="studio-canvas-toolbar"><button type="button" aria-label="Previous slide" onClick={() => setSelected(Math.max(0, selected - 1))} disabled={selected === 0}><ArrowLeft size={17} /></button><span className="studio-canvas-count">{selected + 1} <span>of</span> {deck.slides.length}</span><button type="button" aria-label="Next slide" onClick={() => setSelected(Math.min(deck.slides.length - 1, selected + 1))} disabled={selected === deck.slides.length - 1}><ArrowRight size={17} /></button><span className="studio-canvas-separator" /><div className="studio-device-buttons" role="group" aria-label="Preview size"><button type="button" aria-label="Desktop preview" aria-pressed={device === "desktop"} onClick={() => setDevice("desktop")}>Desktop</button><button type="button" aria-label="Mobile preview" aria-pressed={device === "mobile"} onClick={() => setDevice("mobile")}>Mobile</button></div><details className="studio-organize"><summary>Organize</summary><div><button type="button" onClick={() => move(-1)} disabled={selected === 0}><ArrowUp size={16} /> Move earlier</button><button type="button" onClick={() => move(1)} disabled={selected === deck.slides.length - 1}><ArrowDown size={16} /> Move later</button></div></details></div></>}
      </main>
      {inspectorOpen && !adding && !changingLayout && <aside className="studio-inspector" id="studio-slide-controls"><div className="studio-inspector-head"><div><small>CURRENT SLIDE · {selected + 1} / {deck.slides.length}</small><h2>{slide?.title.replace(/\n/g, " ")}</h2></div><button type="button" aria-label="Close slide controls" onClick={() => setInspectorOpen(false)}><X size={17} /></button></div>
        <div className="studio-inspector-tabs" role="tablist" aria-label="Edit slide">{(["text", "media", "buttons"] as const).map((section) => <button key={section} type="button" role="tab" aria-selected={quickSection === section} onClick={() => setQuickSection(section)}>{section === "text" ? "Text" : section === "media" ? "Media" : "Buttons"}</button>)}</div>
        {slide && <><SlideQuickEditor section={quickSection} slide={slide} deck={deck} onChange={changeSlide} onUpload={(file, target) => void upload(file, target)} onOpenLibrary={() => setWorkspace("media")} onEmbedYouTube={(url) => void embedYouTube(url)} disabled={!canEdit || busy} />
        {(["booking", "pathway", "quiz", "memory", "html"] as const).some((kind) => kind === slide.layout) && <details className="studio-special-editor" open={specialOpen} onToggle={(event) => setSpecialOpen(event.currentTarget.open)}><summary>{slide.layout === "booking" ? "Workshop booking" : slide.layout === "pathway" ? "Tailored path" : slide.layout === "quiz" ? "Quiz" : slide.layout === "memory" ? "Memory match" : "Custom HTML"} settings</summary><InteractiveInspector slide={slide} onChange={changeSlide} /><ConversionInspector slide={slide} onChange={changeSlide} /></details>}
        <div className="studio-inspector-footer"><button type="button" className="studio-change-layout" onClick={() => setChangingLayout(true)} disabled={!canEdit || busy}><LayoutTemplate size={17} /> Change layout</button><label className="studio-quick-visible"><span>Visible on website</span><input type="checkbox" checked={slide.visible} disabled={!canEdit || busy} onChange={(event) => { if (event.target.checked && slide.layout === "booking" && !slide.bookingSlots.some((slot) => slot.startsAt && Date.parse(slot.startsAt) > Date.now())) { toast.error("Add a future workshop date before making this slide visible."); return; } changeSlide({ visible: event.target.checked }); }} /></label></div>
        <details className="studio-advanced-controls"><summary>More slide controls · photo crop &amp; layout styling</summary><div className="studio-tabs" role="tablist" aria-label="Advanced editor sections">{(["media", "design"] as const).map((section) => <button key={section} type="button" role="tab" aria-selected={tab === section} onClick={() => setTab(section)}>{section === "media" ? "Photo crop & video" : "Design"}</button>)}</div><div className="studio-fields">
          {tab === "media" && (["quiz","memory","html","booking","pathway"].includes(slide.layout) ? <p className="studio-interactive-hint">This layout is an interactive canvas rather than a photo or video slide. Edit its content in the Content tab; choose another composition to add photo or video media.</p> : <><div className="studio-upload"><ImagePlus size={22} /><strong>Replace the photo</strong><span>Use your own company imagery. JPG, PNG, WebP and more.</span><input type="file" accept="image/jpeg,image/png,image/webp,image/gif,image/avif" disabled={!canEdit || busy} onChange={(e) => { const file = e.target.files?.[0]; if (file) void upload(file, "image"); }} /></div><Field label="Photo URL"><input className={inputClass} value={slide.image} onChange={(e) => changeSlide({ image: e.target.value })} /></Field><Field label="Photo description (accessibility)"><input className={inputClass} value={slide.imageAlt} onChange={(e) => changeSlide({ imageAlt: e.target.value })} /></Field><Range label="Photo horizontal focus" value={slide.imagePositionX} min={0} max={100} suffix="%" onChange={(imagePositionX) => changeSlide({ imagePositionX })} /><Range label="Photo vertical focus" value={slide.imagePositionY} min={0} max={100} suffix="%" onChange={(imagePositionY) => changeSlide({ imagePositionY })} /><Range label="Mobile photo vertical focus" value={slide.mobileFocusY} min={0} max={100} suffix="%" onChange={(mobileFocusY) => changeSlide({ mobileFocusY })} /><Field label="Photo fit"><select className={inputClass} value={slide.imageFit} onChange={(e) => changeSlide({ imageFit: e.target.value as "cover" | "contain" })}><option value="cover">Fill the space</option><option value="contain">Show full image</option></select></Field><Range label="Photo width" value={slide.imageWidth} min={25} max={75} suffix="%" onChange={(imageWidth) => changeSlide({ imageWidth })} /><Range label="Photo darkening" value={slide.overlay} min={0} max={85} suffix="%" onChange={(overlay) => changeSlide({ overlay })} /><div className="studio-upload"><Video size={21} /><strong>Add a video</strong><span>MP4, WebM, or a secure hosted file.</span><input type="file" accept="video/mp4,video/webm,video/quicktime" disabled={!canEdit || busy} onChange={(e) => { const file = e.target.files?.[0]; if (file) void upload(file, "videoUrl"); }} /></div><Field label="Video URL"><input className={inputClass} value={slide.videoUrl} onChange={(e) => changeSlide({ videoUrl: e.target.value })} placeholder="https://..." /></Field></>)}
          {tab === "design" && <><Field label="Slide composition"><select className={inputClass} value={slide.layout} onChange={(e) => changeLayout(e.target.value as Layout)}>{layouts.map((layout) => <option key={layout.id} value={layout.id}>{layout.name}</option>)}</select></Field><Color label="Slide background" value={slide.background} onChange={(background) => changeSlide({ background })} /><Color label="Text color" value={slide.foreground} onChange={(foreground) => changeSlide({ foreground })} /><Color label="Accent / highlight" value={slide.accent} onChange={(accent) => changeSlide({ accent })} /><Range label="Headline size" value={slide.titleSize} min={28} max={150} suffix="px" onChange={(titleSize) => changeSlide({ titleSize })} /><Range label="Headline weight" value={slide.headlineWeight} min={300} max={900} onChange={(headlineWeight) => changeSlide({ headlineWeight })} /><Field label="Headline font"><select className={inputClass} value={slide.headlineFont} onChange={(e) => changeSlide({ headlineFont: e.target.value as TemplateSlide["headlineFont"] })}><option value="theme">Use website font</option>{fonts.map((font) => <option key={font}>{font}</option>)}</select></Field><Range label="Supporting text size" value={slide.bodySize} min={12} max={48} suffix="px" onChange={(bodySize) => changeSlide({ bodySize })} /><Range label="Text panel spacing" value={slide.copyInset} min={20} max={140} suffix="px" onChange={(copyInset) => changeSlide({ copyInset })} /><Field label="Text alignment"><select className={inputClass} value={slide.alignment} onChange={(e) => changeSlide({ alignment: e.target.value as TemplateSlide["alignment"] })}><option value="left">Left</option><option value="center">Center</option><option value="right">Right</option></select></Field><Toggle label="Show gold divider" checked={slide.showRule} onChange={(showRule) => changeSlide({ showRule })} /></>}
          <div className="studio-fields-footer"><button className="studio-danger" type="button" onClick={remove} disabled={deck.slides.length <= 1}>Delete this slide</button><p>{localMode ? "Your project stays in this browser. Export a ZIP regularly; Publish locally creates a separate private site snapshot." : "Draft edits stay private until you click Publish. Your original seven-slide template is never overwritten for other customers."}</p></div>
        </div></details></>}
      </aside>}
    </div>}
  </div>;
}
