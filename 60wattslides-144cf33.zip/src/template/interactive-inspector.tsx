import { Plus, Trash2 } from "lucide-react";
import { resolvedInteractionCopy, type InteractionCopy, type TemplateSlide } from "./deck";

type Props = { slide: TemplateSlide; onChange: (patch: Partial<TemplateSlide>) => void };
type CopyKey = keyof InteractionCopy;

function CopyField({ label, field, rows, slide, onChange }: { label: string; field: CopyKey; rows?: number; slide: TemplateSlide; onChange: Props["onChange"] }) {
  const copy = resolvedInteractionCopy(slide);
  const update = (value: string) => onChange({ interactionCopy: { ...copy, [field]: value }, interactionCopyCustomized: true });
  return <label className="studio-field"><span>{label}</span>{rows ? <textarea className="studio-input" rows={rows} value={copy[field]} onChange={(event) => update(event.target.value)} /> : <input className="studio-input" value={copy[field]} onChange={(event) => update(event.target.value)} />}</label>;
}

export function InteractiveInspector({ slide, onChange }: Props) {
  if (slide.layout === "quiz") return <section className="studio-interactive-fields" aria-label="Multiple-choice settings">
    <h3 className="studio-section-title">Multiple-choice interaction</h3>
    <label className="studio-field"><span>Question</span><textarea className="studio-input" rows={3} value={slide.quizQuestion} onChange={(event) => onChange({ quizQuestion: event.target.value })} /></label>
    <p className="studio-interactive-hint">Select exactly one correct answer. A visitor can try again after a wrong choice.</p>
    {slide.quizChoices.map((choice, index) => <div className="studio-option-row" key={choice.id}>
      <label className="studio-field"><span>Option {String.fromCharCode(65 + index)}</span><input className="studio-input" value={choice.text} onChange={(event) => onChange({ quizChoices: slide.quizChoices.map((item) => item.id === choice.id ? { ...item, text: event.target.value } : item) })} /></label>
      <label className="studio-correct-answer"><input type="radio" name={`correct-${slide.id}`} checked={choice.correct} onChange={() => onChange({ quizChoices: slide.quizChoices.map((item) => ({ ...item, correct: item.id === choice.id })) })} /> Correct answer</label>
      <button type="button" className="studio-icon-button" disabled={slide.quizChoices.length <= 2} onClick={() => onChange({ quizChoices: slide.quizChoices.filter((item) => item.id !== choice.id).map((item, i, all) => ({ ...item, correct: all.some((option) => option.correct) ? item.correct : i === 0 })) })} aria-label={`Remove option ${index + 1}`}><Trash2 size={15} /></button>
    </div>)}
    <button type="button" className="studio-secondary" disabled={slide.quizChoices.length >= 8} onClick={() => onChange({ quizChoices: [...slide.quizChoices, { id: crypto.randomUUID(), text: "New answer choice", correct: false }] })}><Plus size={15} /> Add answer option</button>
    <label className="studio-field"><span>Explanation after the correct answer</span><textarea className="studio-input" rows={3} value={slide.quizExplanation} onChange={(event) => onChange({ quizExplanation: event.target.value })} /></label>
    <details className="studio-copy-controls"><summary>Visitor-facing language</summary><div>
      <CopyField label="Small instruction line" field="kicker" slide={slide} onChange={onChange} />
      <CopyField label="Fallback when no question is entered" field="prompt" rows={2} slide={slide} onChange={onChange} />
      <CopyField label="Before an answer is chosen" field="idle" rows={2} slide={slide} onChange={onChange} />
      <CopyField label="Correct answer feedback" field="correct" slide={slide} onChange={onChange} />
      <CopyField label="Incorrect answer feedback" field="incorrect" slide={slide} onChange={onChange} />
      <CopyField label="Try-again button" field="reset" slide={slide} onChange={onChange} />
    </div></details>
  </section>;
  if (slide.layout === "memory") return <section className="studio-interactive-fields" aria-label="Memory-match settings">
    <h3 className="studio-section-title">Memory-match game</h3>
    <p className="studio-interactive-hint">Each pair becomes two light nodes. Visitors reveal nodes, match them, see their turns, and can start again.</p>
    {slide.gamePairs.map((pair, index) => <div className="studio-option-row" key={pair.id}>
      <strong>Pair {index + 1}</strong>
      <label className="studio-field"><span>Front / idea</span><input className="studio-input" value={pair.term} onChange={(event) => onChange({ gamePairs: slide.gamePairs.map((item) => item.id === pair.id ? { ...item, term: event.target.value } : item) })} /></label>
      <label className="studio-field"><span>Match / meaning</span><input className="studio-input" value={pair.meaning} onChange={(event) => onChange({ gamePairs: slide.gamePairs.map((item) => item.id === pair.id ? { ...item, meaning: event.target.value } : item) })} /></label>
      <button type="button" className="studio-icon-button" disabled={slide.gamePairs.length <= 1} onClick={() => onChange({ gamePairs: slide.gamePairs.filter((item) => item.id !== pair.id) })} aria-label={`Remove pair ${index + 1}`}><Trash2 size={15} /></button>
    </div>)}
    <button type="button" className="studio-secondary" disabled={slide.gamePairs.length >= 6} onClick={() => onChange({ gamePairs: [...slide.gamePairs, { id: crypto.randomUUID(), term: "New idea", meaning: "Its meaning" }] })}><Plus size={15} /> Add a matching pair</button>
    <details className="studio-copy-controls"><summary>Visitor-facing language</summary><div>
      <CopyField label="Small instruction line" field="kicker" slide={slide} onChange={onChange} />
      <CopyField label="Game prompt" field="prompt" slide={slide} onChange={onChange} />
      <CopyField label="Completion heading" field="complete" slide={slide} onChange={onChange} />
      <CopyField label="Completion message" field="confirmed" rows={2} slide={slide} onChange={onChange} />
      <CopyField label="New-round button" field="reset" slide={slide} onChange={onChange} />
      <CopyField label="Pair counter word" field="pairsLabel" slide={slide} onChange={onChange} />
      <CopyField label="One turn" field="turnSingular" slide={slide} onChange={onChange} />
      <CopyField label="Multiple turns" field="turnPlural" slide={slide} onChange={onChange} />
    </div></details>
  </section>;
  if (slide.layout === "html") return <section className="studio-interactive-fields" aria-label="Custom HTML settings">
    <h3 className="studio-section-title">Your custom HTML canvas</h3>
    <p className="studio-interactive-hint">Write HTML, CSS in a style tag and optional inline JavaScript. It runs in an isolated iframe with no access to your site's data; external fetches and form submissions are blocked.</p>
    <label className="studio-field"><span>HTML, CSS and JavaScript</span><textarea className="studio-input studio-code-editor" rows={15} spellCheck={false} value={slide.htmlContent} onChange={(event) => onChange({ htmlContent: event.target.value })} /></label>
  </section>;
  if (slide.layout === "video") return <section className="studio-interactive-fields" aria-label="Video slide guidance">
    <h3 className="studio-section-title">Video story</h3>
    <p className="studio-interactive-hint">Open the Media tab to upload your video or paste a secure URL. Your photo becomes the player poster image.</p>
  </section>;
  return null;
}
