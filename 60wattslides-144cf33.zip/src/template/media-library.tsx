import { useEffect, useMemo, useState } from "react";
import { ImagePlus, Link2, Search, Trash2, Upload, Video } from "lucide-react";
import { toast } from "sonner";
import { STARTER_DECK, type TemplateDeck } from "./deck";
import { addMyYoutube, listMyMedia, removeMyMedia } from "./media.functions";
import { assetUsage, type MediaAsset, youtubeId } from "./media";
import { addPersonalLibraryAsset, personalMediaId, personalMediaUrl, personalSavedUses, readPersonalLibrary, removePersonalLibraryAsset } from "./personal-workspace";
import "./media-library.css";

type Props = {
  deck: TemplateDeck; currentSlideId: string; localMode: boolean; disabled: boolean;
  onUpload: (file: File) => Promise<void>;
  onUseSlide: (asset: MediaAsset) => void;
  onUseLogo: (asset: MediaAsset) => void;
  onOpenSlide: (id: string) => void;
};
function currentLibraryAssets(deck: TemplateDeck, indexed: MediaAsset[], localMode: boolean): MediaAsset[] {
  const references = [{ url: deck.theme.logoUrl, name: "Website logo", type: "image" as const, alt: `${deck.theme.brandName} logo` }, ...deck.slides.flatMap((slide) => [
    { url: slide.image, name: `${slide.title.replace(/\n/g, " ").slice(0, 40)} · photo`, type: "image" as const, alt: slide.imageAlt },
    { url: slide.videoUrl, name: `${slide.title.replace(/\n/g, " ").slice(0, 40)} · video`, type: "video" as const, alt: "" },
  ]), ...STARTER_DECK.slides.map((slide) => ({
    url: slide.image, name: `Starter photo · ${slide.title.replace(/\n/g, " ").slice(0, 30)}`,
    type: "image" as const, alt: slide.imageAlt,
  }))];
  const known = new Set(indexed.map((asset) => asset.url));
  const unique = new Map<string, typeof references[number]>();
  for (const reference of references) {
    const url = localMode ? personalMediaId(reference.url) : reference.url;
    if (url && !known.has(url) && !unique.has(url)) unique.set(url, { ...reference, url });
  }
  const virtual = [...unique.entries()].map(([url, reference], index): MediaAsset => ({
    id: `template-${index}`, url,
    type: youtubeId(url) ? "youtube" : reference.type,
    name: reference.name,
    alt: reference.alt, createdAt: new Date(0).toISOString(),
  }));
  return [...indexed, ...virtual];
}
export function MediaLibrary({ deck, currentSlideId, localMode, disabled, onUpload, onUseSlide, onUseLogo, onOpenSlide }: Props) {
  const [indexed, setIndexed] = useState<MediaAsset[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [previewUrls, setPreviewUrls] = useState<Record<string, string>>({});
  const [selectedId, setSelectedId] = useState("");
  const [filter, setFilter] = useState<"all" | MediaAsset["type"]>("all");
  const [query, setQuery] = useState("");
  const [youtube, setYoutube] = useState("");
  const [youtubeTitle, setYoutubeTitle] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function refresh() {
    try { const result = localMode ? readPersonalLibrary() : await listMyMedia(); setIndexed(result); setLoaded(true); setError(""); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Could not load your media"); }
  }
  useEffect(() => { void refresh(); }, [localMode]);
  const assets = useMemo(() => currentLibraryAssets(deck, indexed, localMode), [deck, indexed, localMode]);
  useEffect(() => {
    if (!loaded || !assets.length || assets.some((asset) => asset.id === selectedId)) return;
    const current = deck.slides.find((slide) => slide.id === currentSlideId);
    const url = localMode ? personalMediaId(current?.image || current?.videoUrl || "") : current?.image || current?.videoUrl || "";
    setSelectedId(assets.find((asset) => asset.url === url)?.id ?? assets[0]!.id);
  }, [assets, selectedId, loaded, currentSlideId, deck, localMode]);
  useEffect(() => {
    let active = true;
    void Promise.all(assets.filter((asset) => asset.url.startsWith("local-media:")).map(async (asset) => [asset.id, await personalMediaUrl(asset.url)] as const)).then((pairs) => {
      if (active) setPreviewUrls(Object.fromEntries(pairs));
    }).catch((cause) => { if (active) setError(cause instanceof Error ? cause.message : "A local photo could not be loaded"); });
    return () => { active = false; };
  }, [assets]);
  const chosen = assets.find((asset) => asset.id === selectedId);
  const visible = assets.filter((asset) => (filter === "all" || asset.type === filter) && `${asset.name} ${asset.alt}`.toLowerCase().includes(query.toLowerCase()));
  const normalized = { ...deck, theme: { ...deck.theme, logoUrl: localMode ? personalMediaId(deck.theme.logoUrl) : deck.theme.logoUrl }, slides: deck.slides.map((slide) => ({ ...slide, image: localMode ? personalMediaId(slide.image) : slide.image, videoUrl: localMode ? personalMediaId(slide.videoUrl) : slide.videoUrl })) };
  const usage = chosen ? assetUsage(chosen, normalized) : null;
  async function addYoutube() {
    const id = youtubeId(youtube);
    if (!id) { setError("Paste a valid YouTube video URL"); return; }
    setBusy(true);
    try {
      const asset = localMode ? (() => {
        const item: MediaAsset = { id: crypto.randomUUID(), type: "youtube", url: `https://www.youtube.com/watch?v=${id}`, name: youtubeTitle.trim() || "YouTube video", alt: "", createdAt: new Date().toISOString() };
        addPersonalLibraryAsset(item); return item;
      })() : await addMyYoutube({ data: { url: youtube, title: youtubeTitle.trim() || "YouTube video" } });
      await refresh(); setSelectedId(asset.id); setYoutube(""); setYoutubeTitle(""); toast.success("YouTube video added to your library. Choose Use on slide to show it.");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Could not add YouTube video"); }
    finally { setBusy(false); }
  }
  async function removeAsset() {
    if (!chosen || chosen.id.startsWith("template-")) return;
    if (usage?.logo || usage?.slides.length || (localMode && personalSavedUses(chosen.url))) { setError("This asset is still used by a draft or published slide. Remove it there first; then delete its library entry."); return; }
    if (!window.confirm(`Remove “${chosen.name}” from the library? This does not delete the original file from hosted storage.`)) return;
    setBusy(true);
    try {
      if (localMode) removePersonalLibraryAsset(chosen.id); else await removeMyMedia({ data: { id: chosen.id } });
      setSelectedId(""); await refresh(); toast.success("Asset removed from the library.");
    } catch (cause) { setError(cause instanceof Error ? cause.message : "Could not remove asset"); }
    finally { setBusy(false); }
  }
  async function upload(file: File) {
    setBusy(true); setError("");
    try { await onUpload(file); await refresh(); toast.success("Saved to your media library. Select it to use it on a slide."); }
    catch (cause) { setError(cause instanceof Error ? cause.message : "Upload failed"); }
    finally { setBusy(false); }
  }
  return <main className="media-workspace">
    <header className="media-head"><div><span>YOUR WEBSITE ASSETS</span><h1>Media Library</h1><p>Upload once. Use photos and videos across your slides.</p></div><div className="media-head-actions"><label><ImagePlus size={18} /> Upload photos<input type="file" accept="image/jpeg,image/png,image/webp,image/gif,image/avif" hidden disabled={disabled || busy} onChange={(event) => { const file = event.target.files?.[0]; if (file) void upload(file); event.currentTarget.value = ""; }} /></label><label><Video size={18} /> Upload video<input type="file" accept="video/mp4,video/webm,video/quicktime" hidden disabled={disabled || busy} onChange={(event) => { const file = event.target.files?.[0]; if (file) void upload(file); event.currentTarget.value = ""; }} /></label></div></header>
    {localMode && <p className="media-note">Personal uploads stay in this browser. Export a project ZIP to take the library with you.</p>}
    {error && <p role="alert" className="media-error">{error}</p>}
    <form className="media-youtube" onSubmit={(event) => { event.preventDefault(); void addYoutube(); }}><Link2 size={18} /><label><span className="sr-only">YouTube URL</span><input value={youtube} onChange={(event) => setYoutube(event.target.value)} placeholder="Paste a YouTube video URL" /></label><label><span className="sr-only">Video name</span><input value={youtubeTitle} maxLength={160} onChange={(event) => setYoutubeTitle(event.target.value)} placeholder="Name it for your library" /></label><button type="submit" disabled={disabled || busy || !youtubeId(youtube)}>Embed YouTube</button></form>
    <div className="media-controls"><div role="group" aria-label="Filter media">{(["all", "image", "video", "youtube"] as const).map((type) => <button type="button" key={type} aria-pressed={filter === type} onClick={() => setFilter(type)}>{type === "all" ? "All media" : type === "image" ? "Photos" : type === "video" ? "Videos" : "YouTube"}</button>)}</div><label><Search size={18} /><span className="sr-only">Search assets</span><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search media" /></label></div>
    <div className="media-layout"><section className="media-grid" aria-label="Media assets">{visible.map((asset) => <button type="button" key={asset.id} className={`media-card ${asset.id === selectedId ? "is-selected" : ""}`} onClick={() => setSelectedId(asset.id)}><span className="media-card-visual">{asset.type === "image" ? <img src={previewUrls[asset.id] ?? asset.url} alt="" loading="lazy" /> : asset.type === "video" ? <><Video size={36} /><small>VIDEO</small></> : <><Video size={36} /><small>YOUTUBE</small></>}</span><strong>{asset.name}</strong><span>{asset.type === "image" ? "Photo" : asset.type === "video" ? "Video" : "YouTube"}</span></button>)}{!visible.length && <div className="media-empty"><Upload size={36} /><h2>{assets.length ? "No matching media" : "Your library is ready"}</h2><p>{assets.length ? "Try a different filter or search." : "Upload a photo, video, or YouTube link to use it on any slide."}</p></div>}</section>
    <aside className="media-details"><h2>Asset details</h2>{chosen ? <><div className="media-details-visual">{chosen.type === "image" ? <img src={previewUrls[chosen.id] ?? chosen.url} alt={chosen.alt || "Selected media"} /> : <Video size={44} />}</div><h3>{chosen.name}</h3><p>{chosen.type === "youtube" ? "YouTube embed" : chosen.type === "video" ? "Uploaded video" : "Photo"}</p><div className="media-usage"><strong>Used on</strong>{usage?.logo && <span>Website logo</span>}{usage?.slides.map((item) => <button type="button" key={item.id} onClick={() => onOpenSlide(item.id)}>{item.title || "Untitled slide"} ↗</button>)}{!usage?.logo && !usage?.slides.length && <span>Not used on a slide yet</span>}</div><button type="button" className="media-use" disabled={disabled} onClick={() => onUseSlide({ ...chosen, url: previewUrls[chosen.id] ?? chosen.url })}>{chosen.type === "image" ? "Use photo on selected slide" : "Use video on selected slide"}</button>{chosen.type === "image" && <button type="button" disabled={disabled} onClick={() => onUseLogo({ ...chosen, url: previewUrls[chosen.id] ?? chosen.url })}>Use as website logo</button>}<p className="media-current">Selected slide: {deck.slides.find((item) => item.id === currentSlideId)?.title.replace(/\n/g, " ")}</p>{!chosen.id.startsWith("template-") && <button className="media-delete" type="button" disabled={disabled || busy || !!usage?.logo || !!usage?.slides.length} onClick={() => void removeAsset()}><Trash2 size={17} /> Remove from library</button>}</> : <p>Choose an asset to see where it is used and add it to a slide.</p>}</aside></div>
  </main>;
}
