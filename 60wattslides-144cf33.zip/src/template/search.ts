import type { TemplateDeck, TemplateSlide } from "./deck";
import { bookingTime } from "./crm";

const STOP = new Set("a an and are as at be by can do does for from how i in is it me my of on or our the this to we what when where which who why will with you your about please tell know there any offer provide show find".split(" "));
const SYNONYMS: Record<string, string> = { cost: "price", fee: "price", pricing: "price", tuition: "price", programme: "program", programmes: "program", workshop: "session", classes: "session", registration: "register", signup: "register" };
const tokens = (value: string): string[] => (value.toLowerCase().match(/[a-z0-9]+/g) ?? [])
  .filter((term) => !STOP.has(term))
  .map((term) => SYNONYMS[term] ?? (term.endsWith("s") && term.length > 4 ? term.slice(0, -1) : term));

type RequiredEvidence = "price" | "date" | "location" | null;
function requestedEvidence(question: string): RequiredEvidence {
  if (/\b(how much|cost|costs|price|pricing|fee|fees|tuition)\b/i.test(question)) return "price";
  if (/\b(when|date|dates|time|times|schedule|upcoming|next session)\b/i.test(question)) return "date";
  if (/\b(where|location|address|venue|which city)\b/i.test(question)) return "location";
  return null;
}
function hasAnswerEvidence(content: string, intent: RequiredEvidence): boolean {
  if (!intent) return true;
  if (intent === "price") return /(?:\$\s?\d|\b(?:free|complimentary|no charge|no cost)\b|\b\d+(?:\.\d{2})?\s?(?:usd|dollars)\b)/i.test(content);
  if (intent === "date") return /\b(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday|january|february|march|april|may|june|july|august|september|october|november|december|today|tomorrow)\b|\b\d{4}-\d{1,2}-\d{1,2}\b|\b\d{1,2}(?::\d{2})?\s?(?:am|pm)\b/i.test(content);
  return /\b(?:location|address|venue)\s*[:\-]\s*\S|\b(?:located|based)\s+(?:in|at)\s+\S|\b(?:in|at)\s+[A-Z][a-z]+(?:,\s*[A-Z][A-Za-z]+)?\b/.test(content);
}

export type SlideMatch = { slide: TemplateSlide; excerpt: string; score: number; coverage: number };
export function searchDeck(deck: TemplateDeck, question: string): SlideMatch[] {
  const wanted = [...new Set(tokens(question))];
  if (!wanted.length) return [];
  const intent = requestedEvidence(question);
  return deck.slides.filter((slide) => slide.visible).flatMap((slide) => {
    const fields = [slide.title, slide.subtitle, slide.body, slide.quizQuestion, slide.quizExplanation,
      ...slide.quizChoices.filter((choice) => choice.correct).map((choice) => choice.text), ...slide.gamePairs.flatMap((pair) => [pair.term, pair.meaning]),
      ...slide.bookingSlots.filter((slot) => slot.startsAt && Date.parse(slot.startsAt) > Date.now()).map((slot) => `${slot.label}: ${bookingTime(slot.startsAt)}`),
      slide.pathQuestion, ...slide.pathChoices.flatMap((choice) => [choice.label, choice.outcome, choice.nextStep]),
      ...slide.items.flatMap((item) => [item.title, item.body, item.meta])]
      .map((value) => value.trim()).filter(Boolean);
    const matching = fields.map((excerpt) => {
      const hay = new Set(tokens(excerpt));
      const found = wanted.filter((term) => hay.has(term));
      return { excerpt, count: found.length, coverage: found.length / wanted.length };
    }).sort((a, b) => b.coverage - a.coverage || b.count - a.count);
    const best = intent ? matching.find((item) => hasAnswerEvidence(item.excerpt, intent)) : matching[0];
    const all = new Set(tokens(fields.join(" ")));
    const coverage = wanted.filter((term) => all.has(term)).length / wanted.length;
    const threshold = wanted.length <= 2 ? 1 : 0.67;
    if (!best || best.count === 0 || coverage < threshold) return [];
    return [{ slide, excerpt: best.excerpt, score: best.count + coverage, coverage }];
  }).sort((a, b) => b.coverage - a.coverage || b.score - a.score).slice(0, 4);
}
