import { randomBytes } from "node:crypto";
import postgres, { type Sql } from "postgres";
import { copyStarterDeck, type TemplateDeck } from "./deck";
import { assertPublishableDeck, deckSchema } from "./schema";

let pool: Sql | undefined;
export type Database = Sql;

function postgresUrl(): string {
  const url = process.env["POSTGRES_URL"];
  if (!url) throw new Error("Customer storage is not configured. Set POSTGRES_URL to your PostgreSQL connection string.");
  if (!/^postgres(?:ql)?:\/\//i.test(url)) throw new Error("POSTGRES_URL must be a PostgreSQL connection string.");
  return url;
}

export function database(): Database {
  return pool ??= postgres(postgresUrl(), { max: 5, idle_timeout: 20, connect_timeout: 10 });
}

export async function closeDatabase() {
  if (!pool) return;
  const current = pool;
  pool = undefined;
  await current.end({ timeout: 5 });
}

export type OwnDeck = { deck: TemplateDeck; slug: string; entitlement: string; published: boolean; revision: number };
type DeckRow = { slug: string; draft_json: unknown; published_json: unknown | null; entitlement_status: string; draft_revision: number | string };

function parseDeck(payload: unknown): TemplateDeck {
  return deckSchema.parse(typeof payload === "string" ? JSON.parse(payload) : payload);
}

function requireHostedMedia(deck: TemplateDeck) {
  const urls = [deck.theme.logoUrl, ...deck.slides.flatMap((slide) => [slide.image, slide.videoUrl])];
  if (urls.some((url) => url.startsWith("local-media:") || url.startsWith("blob:"))) {
    throw new Error("Browser-local media cannot be saved to a hosted site. Upload it to your account first.");
  }
}

export async function ownDeck(userId: string): Promise<OwnDeck> {
  if (!userId || userId.length > 128) throw new Error("Invalid account");
  const db = database();
  let rows = await db<DeckRow[]>`
    SELECT slug,draft_json,published_json,entitlement_status,draft_revision
    FROM customer_decks WHERE user_id=${userId}
  `;
  if (!rows.length) {
    const slug = `site-${userId.replace(/[^a-zA-Z0-9]/g, "").slice(0, 8)}-${randomBytes(3).toString("hex")}`;
    await db`
      INSERT INTO customer_decks (user_id,slug,draft_json)
      VALUES (${userId},${slug},${JSON.stringify(copyStarterDeck())}::jsonb)
      ON CONFLICT (user_id) DO NOTHING
    `;
    rows = await db<DeckRow[]>`
      SELECT slug,draft_json,published_json,entitlement_status,draft_revision
      FROM customer_decks WHERE user_id=${userId}
    `;
  }
  const row = rows[0];
  if (!row) throw new Error("Could not create your website");
  return { deck: parseDeck(row.draft_json), slug: row.slug, entitlement: row.entitlement_status, published: !!row.published_json, revision: Number(row.draft_revision) };
}

export async function saveDraft(userId: string, deck: TemplateDeck, revision: number): Promise<number> {
  const validated = deckSchema.parse(deck);
  requireHostedMedia(validated);
  const rows = await database()<{ draft_revision: number | string }[]>`
    UPDATE customer_decks
    SET draft_json=${JSON.stringify(validated)}::jsonb,draft_revision=draft_revision+1
    WHERE user_id=${userId} AND entitlement_status='active' AND draft_revision=${revision}
    RETURNING draft_revision
  `;
  if (!rows.length) throw new Error("Could not save: your subscription ended or this draft changed in another tab. Refresh before editing again.");
  return Number(rows[0]!.draft_revision);
}

export async function publishDraft(userId: string, deck: TemplateDeck, revision: number): Promise<{ slug: string; revision: number }> {
  const validated = deckSchema.parse(deck);
  requireHostedMedia(validated);
  assertPublishableDeck(validated);
  const payload = JSON.stringify(validated);
  const rows = await database()<{ slug: string; draft_revision: number | string }[]>`
    UPDATE customer_decks
    SET draft_json=${payload}::jsonb,published_json=${payload}::jsonb,draft_revision=draft_revision+1
    WHERE user_id=${userId} AND entitlement_status='active' AND draft_revision=${revision}
    RETURNING slug,draft_revision
  `;
  const row = rows[0];
  if (!row) throw new Error("Could not publish: your subscription ended or this draft changed in another tab. Refresh before publishing again.");
  return { slug: row.slug, revision: Number(row.draft_revision) };
}

export async function publishedDeck(slug: string): Promise<TemplateDeck | null> {
  const rows = await database()<{ published_json: unknown }[]>`
    SELECT published_json FROM customer_decks
    WHERE slug=${slug} AND entitlement_status='active' AND published_json IS NOT NULL
  `;
  return rows[0] ? parseDeck(rows[0].published_json) : null;
}

export async function recordAsset(userId: string, path: string, contentType: string) {
  await database()`INSERT INTO customer_assets (user_id,asset_path,content_type) VALUES (${userId},${path},${contentType})`;
}

export async function billingIdentity(userId: string): Promise<string | null> {
  const rows = await database()<{ stripe_customer_id: string | null }[]>`
    SELECT stripe_customer_id FROM customer_decks WHERE user_id=${userId}
  `;
  return rows[0]?.stripe_customer_id ?? null;
}
