import { createServerFn } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";
import { z } from "zod";
import Stripe from "stripe";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { billingIdentity, database, ownDeck } from "./db.server";
import { SLIDES_WEBSITE_PLAN } from "./products";

type CheckoutRow = { entitlement_status: string; slug: string; stripe_customer_id: string | null; stripe_subscription_id: string | null; stripe_checkout_session_id: string | null; stripe_checkout_expires_at: number | string };

export const startSubscription = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ origin: z.string().url() }).parse(data))
  .handler(async ({ context, data }) => {
    const key = process.env["STRIPE_SECRET_KEY"];
    if (!key) throw new Error("Test checkout is not available yet");
    const request = getRequest();
    const sentOrigin = request.headers.get("origin") || (request.headers.get("referer") ? new URL(request.headers.get("referer")!).origin : "");
    const browserOrigin = new URL(data.origin).origin;
    if (!sentOrigin || browserOrigin !== sentOrigin) throw new Error("Checkout origin did not match this website");
    await ownDeck(context.userId);
    const stripe = new Stripe(key);
    return database().begin(async (tx) => {
      const rows = await tx<CheckoutRow[]>`
        SELECT entitlement_status,slug,stripe_customer_id,stripe_subscription_id,stripe_checkout_session_id,stripe_checkout_expires_at
        FROM customer_decks WHERE user_id=${context.userId} FOR UPDATE
      `;
      const row = rows[0];
      if (!row) throw new Error("Your website could not be found");
      if (row.entitlement_status === "active") return { alreadyActive: true, pending: false, url: "" };
      if (row.stripe_checkout_session_id && Number(row.stripe_checkout_expires_at) > Math.floor(Date.now() / 1000)) {
        const existing = await stripe.checkout.sessions.retrieve(row.stripe_checkout_session_id);
        if (existing.status === "open" && existing.url) return { alreadyActive: false, pending: false, url: existing.url };
        if (existing.status === "complete") return { alreadyActive: false, pending: true, url: "" };
      }
      if (row.stripe_subscription_id) {
        const subscription = await stripe.subscriptions.retrieve(row.stripe_subscription_id);
        if (!( ["canceled", "incomplete_expired"] as string[]).includes(subscription.status)) return { alreadyActive: false, pending: true, url: "" };
      }
      const email = typeof context.claims.email === "string" ? context.claims.email : undefined;
      const session = await stripe.checkout.sessions.create({
        mode: "subscription", client_reference_id: context.userId,
        ...(row.stripe_customer_id ? { customer: row.stripe_customer_id } : email ? { customer_email: email } : {}),
        metadata: { user_id: context.userId, slug: row.slug },
        subscription_data: { metadata: { user_id: context.userId } },
        line_items: [{ price_data: { currency: SLIDES_WEBSITE_PLAN.currency, unit_amount: SLIDES_WEBSITE_PLAN.amountCents,
          recurring: { interval: SLIDES_WEBSITE_PLAN.interval }, product_data: { name: SLIDES_WEBSITE_PLAN.name, description: SLIDES_WEBSITE_PLAN.description } }, quantity: 1 }],
        allow_promotion_codes: true,
        success_url: `${browserOrigin}/admin?checkout=success`, cancel_url: `${browserOrigin}/admin?checkout=canceled`,
      }, { idempotencyKey: `slides-website-${context.userId}-${new Date().toISOString().slice(0, 13)}-${row.stripe_checkout_session_id || "first"}` });
      if (!session.url) throw new Error("Checkout could not be created");
      await tx`
        UPDATE customer_decks
        SET stripe_checkout_session_id=${session.id},stripe_checkout_expires_at=${session.expires_at}
        WHERE user_id=${context.userId}
      `;
      return { alreadyActive: false, pending: false, url: session.url };
    });
  });

export const getPaymentHistory = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const customer = await billingIdentity(context.userId);
    if (!customer) return [];
    const key = process.env["STRIPE_SECRET_KEY"];
    if (!key) throw new Error("Payment history is unavailable");
    const invoices = await new Stripe(key).invoices.list({ customer, limit: 30 });
    return invoices.data.map((invoice) => ({
      id: invoice.id, date: invoice.created, amount: invoice.total, currency: invoice.currency,
      status: invoice.status ?? "processing", items: invoice.lines.data.map((line) => line.description || "Slides Website subscription"),
      invoiceUrl: invoice.hosted_invoice_url || "",
    }));
  });

export const openBillingPortal = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ origin: z.string().url() }).parse(data))
  .handler(async ({ context, data }) => {
    const customer = await billingIdentity(context.userId);
    if (!customer) throw new Error("You do not have a subscription to manage yet");
    const key = process.env["STRIPE_SECRET_KEY"];
    if (!key) throw new Error("Billing is unavailable");
    const request = getRequest();
    const sentOrigin = request.headers.get("origin") || (request.headers.get("referer") ? new URL(request.headers.get("referer")!).origin : "");
    const origin = new URL(data.origin).origin;
    if (origin !== sentOrigin) throw new Error("Billing origin did not match this website");
    const portal = await new Stripe(key).billingPortal.sessions.create({ customer, return_url: `${origin}/payments` });
    return { url: portal.url };
  });
