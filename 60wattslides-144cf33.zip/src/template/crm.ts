import { z } from "zod";

export const leadInputSchema = z.object({
  slug: z.string().min(1).max(96).regex(/^[a-z0-9-]+$/),
  slideId: z.string().min(1).max(100),
  kind: z.enum(["booking", "pathway"]),
  choiceId: z.string().max(100).default(""),
  name: z.string().trim().min(2).max(120),
  email: z.string().email().max(254),
  message: z.string().trim().max(500).default(""),
  consent: z.literal(true),
  website: z.string().max(200).default(""),
});

export type LeadInput = z.infer<typeof leadInputSchema>;
export type LeadStage = "new" | "contacted" | "confirmed" | "done" | "archived";
export const leadStageSchema = z.enum(["new", "contacted", "confirmed", "done", "archived"]);
export type Lead = {
  id: string;
  createdAt: string;
  kind: "booking" | "pathway";
  name: string;
  email: string;
  message: string;
  slideId: string;
  slideTitle: string;
  choiceId: string;
  choiceLabel: string;
  stage: LeadStage;
  notes: string;
};

export function bookingTime(value: string): string {
  if (!value || Number.isNaN(Date.parse(value))) return "Date to be announced";
  return new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(new Date(value));
}
