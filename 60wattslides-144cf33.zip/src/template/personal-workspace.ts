import JSZip from "jszip";
import { copyStarterDeck, type TemplateDeck } from "./deck";
import { assertPublishableDeck, deckSchema } from "./schema";
import { mediaAssetSchema, type MediaAsset } from "./media";
import { getLocalLeads, personalCrmBackupSchema, PERSONAL_CRM_KEY } from "./crm-local";

// A single storage value keeps draft, publication and revision together.
export const PERSONAL_STATE_KEY = "slides-website:personal:project:v2";
export const PERSONAL_LIBRARY_KEY = "slides-website:personal:library:v1";
const OLD_DRAFT_KEY = "slides-website:personal:draft:v1";
const OLD_PUBLISHED_KEY = "slides-website:personal:published:v1";
const DB_NAME = "slides-website:personal-media:v1";
const STORE_NAME = "assets";
const LOCAL_MEDIA = /^local-media:[a-f0-9-]{36}$/;
const ALLOWED_MIME = new Set(["image/jpeg", "image/png", "image/webp", "image/gif", "image/avif", "video/mp4", "video/webm", "video/quicktime"]);
const MAX_MEDIA_BYTES = 150 * 1024 * 1024;
const CLEANUP_GRACE_MS = 24 * 60 * 60 * 1000;
const objectUrls = new Map<string, string>();
const idsByObjectUrl = new Map<string, string>();
type MediaRecord = { blob: Blob; createdAt: number };
type StoredProject = { revision: number; draft: TemplateDeck | null; published: TemplateDeck | null };
let databasePromise: Promise<IDBDatabase> | undefined;

function openMediaDatabase(): Promise<IDBDatabase> {
  if (databasePromise) return databasePromise;
  databasePromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => { if (!request.result.objectStoreNames.contains(STORE_NAME)) request.result.createObjectStore(STORE_NAME); };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Could not open local media storage"));
  });
  return databasePromise;
}
function commitMedia(items: { id: string; blob: Blob }[]): Promise<void> {
  if (!items.length) return Promise.resolve();
  return openMediaDatabase().then((database) => new Promise<void>((resolve, reject) => {
    const transaction = database.transaction(STORE_NAME, "readwrite");
    const store = transaction.objectStore(STORE_NAME);
    for (const item of items) store.put({ blob: item.blob, createdAt: Date.now() } satisfies MediaRecord, item.id);
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error ?? new Error("Could not store media"));
    transaction.onabort = () => reject(transaction.error ?? new Error("Media storage was interrupted"));
  }));
}
async function getMedia(id: string): Promise<Blob | null> {
  const database = await openMediaDatabase();
  return new Promise((resolve, reject) => {
    const request = database.transaction(STORE_NAME, "readonly").objectStore(STORE_NAME).get(id);
    request.onsuccess = () => {
      const value: unknown = request.result;
      if (value instanceof Blob) resolve(value); // Existing v1 uploads remain readable.
      else if (value && typeof value === "object" && "blob" in value && value.blob instanceof Blob) resolve(value.blob);
      else resolve(null);
    };
    request.onerror = () => reject(request.error ?? new Error("Could not load saved media"));
  });
}
function remember(id: string, blob: Blob): string {
  const previous = objectUrls.get(id);
  if (previous) { URL.revokeObjectURL(previous); idsByObjectUrl.delete(previous); }
  const url = URL.createObjectURL(blob);
  objectUrls.set(id, url);
  idsByObjectUrl.set(url, id);
  return url;
}
export async function storePersonalMedia(file: File): Promise<string> {
  if (!ALLOWED_MIME.has(file.type)) throw new Error("Choose a JPG, PNG, WebP, GIF, AVIF, MP4, WebM, or MOV file");
  if (file.size > MAX_MEDIA_BYTES) throw new Error("Use a media file under 150 MB");
  const id = `local-media:${crypto.randomUUID()}`;
  await commitMedia([{ id, blob: file }]);
  const asset: MediaAsset = { id, type: file.type.startsWith("image/") ? "image" : "video", name: file.name, url: id, alt: "", createdAt: new Date().toISOString() };
  localStorage.setItem(PERSONAL_LIBRARY_KEY, JSON.stringify([asset, ...readPersonalLibrary()]));
  return remember(id, file);
}
export function personalMediaId(url: string): string { return idsByObjectUrl.get(url) ?? url; }
export async function personalMediaUrl(id: string): Promise<string> {
  if (!LOCAL_MEDIA.test(id)) return id;
  if (objectUrls.has(id)) return objectUrls.get(id)!;
  const blob = await getMedia(id);
  if (!blob) throw new Error("This photo or video is missing from the browser. Restore a ZIP backup.");
  return remember(id, blob);
}
export function readPersonalLibrary(): MediaAsset[] {
  const raw = localStorage.getItem(PERSONAL_LIBRARY_KEY);
  if (!raw) return [];
  try { return mediaAssetSchema.array().max(150).parse(JSON.parse(raw)); }
  catch { throw new Error("Your saved media library is invalid. Restore a ZIP backup before changing it."); }
}
export function addPersonalLibraryAsset(asset: MediaAsset): void {
  const validated = mediaAssetSchema.parse(asset);
  const current = readPersonalLibrary();
  if (current.some((entry) => entry.id === validated.id)) throw new Error("This asset already exists");
  localStorage.setItem(PERSONAL_LIBRARY_KEY, JSON.stringify([validated, ...current]));
}
export function removePersonalLibraryAsset(id: string): void {
  localStorage.setItem(PERSONAL_LIBRARY_KEY, JSON.stringify(readPersonalLibrary().filter((asset) => asset.id !== id)));
}
function toStoredDeck(deck: TemplateDeck): TemplateDeck {
  const copy = structuredClone(deck);
  const stored = (url: string) => {
    const id = idsByObjectUrl.get(url);
    if (url.startsWith("blob:") && !id) throw new Error("A temporary media URL cannot be saved. Upload the photo or video in the Media tab instead.");
    return id ?? url;
  };
  copy.theme.logoUrl = stored(copy.theme.logoUrl);
  for (const slide of copy.slides) { slide.image = stored(slide.image); slide.videoUrl = stored(slide.videoUrl); }
  return deckSchema.parse(copy);
}
async function restoreMedia(deck: TemplateDeck): Promise<TemplateDeck> {
  const copy = structuredClone(deck);
  const resolve = async (value: string) => {
    if (!LOCAL_MEDIA.test(value)) return value;
    const existing = objectUrls.get(value);
    if (existing) return existing;
    const blob = await getMedia(value);
    if (!blob) throw new Error("This project refers to missing local media. Import a complete ZIP backup to restore it.");
    return remember(value, blob);
  };
  copy.theme.logoUrl = await resolve(copy.theme.logoUrl);
  for (const slide of copy.slides) { slide.image = await resolve(slide.image); slide.videoUrl = await resolve(slide.videoUrl); }
  return copy;
}
function readLegacy(key: string): TemplateDeck | null {
  const raw = localStorage.getItem(key);
  if (!raw) return null;
  return deckSchema.parse(JSON.parse(raw));
}
function readProject(): StoredProject {
  try {
    const raw = localStorage.getItem(PERSONAL_STATE_KEY);
    if (!raw) return { revision: 0, draft: readLegacy(OLD_DRAFT_KEY), published: readLegacy(OLD_PUBLISHED_KEY) };
    const parsed: unknown = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || !("revision" in parsed) || !("draft" in parsed) || !("published" in parsed)) throw new Error("Invalid project state");
    const value = parsed as StoredProject;
    if (!Number.isSafeInteger(value.revision) || value.revision < 0) throw new Error("Invalid project revision");
    return {
      revision: value.revision,
      draft: value.draft == null ? null : deckSchema.parse(value.draft),
      published: value.published == null ? null : deckSchema.parse(value.published),
    };
  } catch {
    throw new Error("Your browser project could not be read. Restore a ZIP backup before resetting this browser's data.");
  }
}
export async function loadPersonalProject(): Promise<{ deck: TemplateDeck; revision: number; published: boolean; hasSavedDraft: boolean }> {
  for (let attempt = 0; attempt < 2; attempt++) {
    const project = readProject();
    const deck = await restoreMedia(project.draft ?? copyStarterDeck());
    if (readProject().revision === project.revision) return {
      deck,
      revision: project.revision,
      published: project.published !== null,
      hasSavedDraft: project.draft !== null,
    };
  }
  throw new Error("This browser project changed while opening. Reload the studio to see the latest version.");
}
export async function loadPersonalPublished(): Promise<TemplateDeck | null> {
  const published = readProject().published;
  return published ? restoreMedia(published) : null;
}
async function withWriteLock<T>(action: () => Promise<T>): Promise<T> {
  if (navigator.locks?.request) return navigator.locks.request("slides-website-personal-writes", action);
  // The revision check is still useful where the Web Locks API is unavailable.
  return action();
}
function assertRevision(current: StoredProject, expected: number): void {
  if (current.revision !== expected) throw new Error("Another tab changed this project. Export a ZIP of your work, then reload this tab before saving or publishing.");
}
function mediaIds(decks: (TemplateDeck | null)[]): string[] {
  const urls = decks.flatMap((deck) => deck ? [deck.theme.logoUrl, ...deck.slides.flatMap((slide) => [slide.image, slide.videoUrl])] : []);
  return [...new Set(urls.filter((value) => LOCAL_MEDIA.test(value)))];
}
export function personalSavedUses(url: string): boolean {
  return mediaIds([readProject().draft, readProject().published]).includes(personalMediaId(url));
}
async function cleanupUnusedMedia(project: StoredProject): Promise<void> {
  const used = new Set([...mediaIds([project.draft, project.published]), ...readPersonalLibrary().map((asset) => asset.url).filter((url) => LOCAL_MEDIA.test(url))]);
  const now = Date.now();
  const database = await openMediaDatabase();
  await new Promise<void>((resolve, reject) => {
    const transaction = database.transaction(STORE_NAME, "readwrite");
    const store = transaction.objectStore(STORE_NAME);
    const request = store.openCursor();
    request.onsuccess = () => {
      const cursor = request.result;
      if (!cursor) return;
      const id = String(cursor.key);
      if (!used.has(id) && !objectUrls.has(id)) {
        const value: unknown = cursor.value;
        if (value instanceof Blob) cursor.update({ blob: value, createdAt: now } satisfies MediaRecord);
        else if (value && typeof value === "object" && "createdAt" in value && typeof value.createdAt === "number" && now - value.createdAt > CLEANUP_GRACE_MS) cursor.delete();
      }
      cursor.continue();
    };
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error ?? new Error("Could not clean up unused uploads"));
    transaction.onabort = () => reject(transaction.error ?? new Error("Media cleanup was interrupted"));
  });
}
function cleanupLater(project: StoredProject): void { void cleanupUnusedMedia(project).catch(() => undefined); }
export async function savePersonalDraft(deck: TemplateDeck, expectedRevision: number): Promise<number> {
  const draft = toStoredDeck(deck);
  return withWriteLock(async () => {
    const current = readProject(); assertRevision(current, expectedRevision);
    const next: StoredProject = { ...current, revision: current.revision + 1, draft };
    localStorage.setItem(PERSONAL_STATE_KEY, JSON.stringify(next));
    cleanupLater(next);
    return next.revision;
  });
}
export async function publishPersonalSite(deck: TemplateDeck, expectedRevision: number): Promise<number> {
  const stored = toStoredDeck(deck);
  assertPublishableDeck(stored);
  return withWriteLock(async () => {
    const current = readProject(); assertRevision(current, expectedRevision);
    const next: StoredProject = { revision: current.revision + 1, draft: stored, published: stored };
    localStorage.setItem(PERSONAL_STATE_KEY, JSON.stringify(next));
    cleanupLater(next);
    return next.revision;
  });
}
export async function createPersonalBackup(currentDraft: TemplateDeck): Promise<Blob> {
  const draft = toStoredDeck(currentDraft);
  const published = readProject().published;
  const library = readPersonalLibrary();
  const zip = new JSZip();
  const media: { id: string; type: string }[] = [];
  for (const id of [...new Set([...mediaIds([draft, published]), ...library.map((asset) => asset.url).filter((url) => LOCAL_MEDIA.test(url))])]) {
    const blob = await getMedia(id);
    if (!blob) throw new Error(`A media file is missing from this browser: ${id}`);
    media.push({ id, type: blob.type });
    zip.file(`media/${id.slice("local-media:".length)}`, blob);
  }
  zip.file("project.json", JSON.stringify({ format: "slides-website-project-v1", draft, published, library, crm: getLocalLeads(), media }, null, 2));
  return zip.generateAsync({ type: "blob", compression: "DEFLATE", compressionOptions: { level: 1 } });
}
function remapDeck(deck: TemplateDeck, ids: Map<string, string>): TemplateDeck {
  const copy = structuredClone(deck);
  const replace = (value: string) => ids.get(value) ?? value;
  copy.theme.logoUrl = replace(copy.theme.logoUrl);
  for (const slide of copy.slides) { slide.image = replace(slide.image); slide.videoUrl = replace(slide.videoUrl); }
  return deckSchema.parse(copy);
}
export async function importPersonalBackup(file: File): Promise<{ deck: TemplateDeck; published: boolean; revision: number }> {
  if (file.size > 250 * 1024 * 1024) throw new Error("Choose a ZIP backup under 250 MB");
  const zip = await JSZip.loadAsync(file);
  const projectFile = zip.file("project.json");
  if (!projectFile) throw new Error("This ZIP does not contain a Slides Website project");
  const projectText = await projectFile.async("string");
  if (projectText.length > 6_000_000) throw new Error("Project manifest is too large");
  const project = JSON.parse(projectText) as { format?: string; draft?: unknown; published?: unknown; library?: unknown; crm?: unknown; media?: { id: string; type: string }[] };
  if (project.format !== "slides-website-project-v1") throw new Error("Unsupported project backup format");
  const originalDraft = deckSchema.parse(project.draft);
  const originalPublished = project.published == null ? null : deckSchema.parse(project.published);
  const originalLibrary = mediaAssetSchema.array().max(150).parse(project.library ?? []);
  // Older backups have no CRM field. Replacing a project with one of them clears
  // the old project's contacts instead of cross-linking them to unrelated slides.
  const importedContacts = personalCrmBackupSchema.parse(project.crm ?? []);
  const oldIds = [...new Set([...mediaIds([originalDraft, originalPublished]), ...originalLibrary.map((asset) => asset.url).filter((url) => LOCAL_MEDIA.test(url))])];
  if (!Array.isArray(project.media) || project.media.length !== oldIds.length || oldIds.length > 125) throw new Error("The backup's media index does not match its slides");
  const newIds = new Map(oldIds.map((id) => [id, `local-media:${crypto.randomUUID()}`]));
  const media: { id: string; blob: Blob }[] = [];
  let unpackedBytes = 0;
  for (const oldId of oldIds) {
    const declaration = project.media.find((item) => item.id === oldId);
    const entry = zip.file(`media/${oldId.slice("local-media:".length)}`);
    if (!declaration || !entry || !ALLOWED_MIME.has(declaration.type)) throw new Error("The backup is missing a valid media file");
    const bytes = await entry.async("blob");
    if (bytes.size > MAX_MEDIA_BYTES) throw new Error("A media file is too large");
    unpackedBytes += bytes.size;
    if (unpackedBytes > 300 * 1024 * 1024) throw new Error("The unpacked media exceeds the 300 MB project limit");
    media.push({ id: newIds.get(oldId)!, blob: new Blob([bytes], { type: declaration.type }) });
  }
  const draft = remapDeck(originalDraft, newIds);
  const published = originalPublished ? remapDeck(originalPublished, newIds) : null;
  const library = originalLibrary.map((asset) => ({ ...asset, id: newIds.get(asset.id) ?? asset.id, url: newIds.get(asset.url) ?? asset.url }));
  const revision = await withWriteLock(async () => {
    const current = readProject();
    const next: StoredProject = { revision: current.revision + 1, draft, published };
    // All imported assets are committed in one IndexedDB transaction under fresh IDs.
    // If either the media batch or the state write fails, the old project remains intact.
    await commitMedia(media);
    const previousLibrary = localStorage.getItem(PERSONAL_LIBRARY_KEY);
    const previousCrm = localStorage.getItem(PERSONAL_CRM_KEY);
    try {
      localStorage.setItem(PERSONAL_LIBRARY_KEY, JSON.stringify(library));
      localStorage.setItem(PERSONAL_CRM_KEY, JSON.stringify(importedContacts));
      localStorage.setItem(PERSONAL_STATE_KEY, JSON.stringify(next));
    } catch (error) {
      if (previousLibrary === null) localStorage.removeItem(PERSONAL_LIBRARY_KEY); else localStorage.setItem(PERSONAL_LIBRARY_KEY, previousLibrary);
      if (previousCrm === null) localStorage.removeItem(PERSONAL_CRM_KEY); else localStorage.setItem(PERSONAL_CRM_KEY, previousCrm);
      throw error;
    }
    cleanupLater(next);
    return next.revision;
  });
  return { deck: await restoreMedia(draft), published: !!published, revision };
}
