import { z } from "zod";

export const mediaAssetSchema = z.object({
  id: z.string().min(1).max(120),
  type: z.enum(["image", "video", "youtube"]),
  name: z.string().trim().min(1).max(160),
  url: z.string().min(1).max(2000),
  alt: z.string().max(200).default(""),
  createdAt: z.string().max(40),
});
export type MediaAsset = z.infer<typeof mediaAssetSchema>;

export function youtubeId(input: string): string | null {
  try {
    const url = new URL(input);
    if (url.protocol !== "https:") return null;
    let id = "";
    if (["youtube.com", "www.youtube.com", "m.youtube.com", "youtube-nocookie.com", "www.youtube-nocookie.com"].includes(url.hostname)) {
      if (url.pathname === "/watch") id = url.searchParams.get("v") ?? "";
      else if (/^\/(?:embed|shorts)\/[\w-]{11}$/.test(url.pathname)) id = url.pathname.split("/")[2] ?? "";
    } else if (url.hostname === "youtu.be") id = url.pathname.slice(1);
    return /^[A-Za-z0-9_-]{11}$/.test(id) ? id : null;
  } catch { return null; }
}
export const youtubeEmbed = (input: string) => {
  const id = youtubeId(input);
  return id ? `https://www.youtube-nocookie.com/embed/${id}` : null;
};
export function assetUsage(asset: MediaAsset, deck: { theme: { logoUrl: string }; slides: { id: string; title: string; image: string; videoUrl: string }[] }) {
  return {
    logo: deck.theme.logoUrl === asset.url,
    slides: deck.slides.filter((slide) => slide.image === asset.url || slide.videoUrl === asset.url).map((slide) => ({ id: slide.id, title: slide.title.replace(/\n/g, " ") })),
  };
}
