import { describe, expect, it } from "vitest";
import { copyStarterDeck } from "./deck";
import { deckSchema } from "./schema";
import { youtubeId, youtubeEmbed, assetUsage } from "./media";
import { normalizeHostname } from "./domain.server";

describe("reusable website media", () => {
  it("embeds only validated YouTube video IDs through the privacy-enhanced host", () => {
    expect(youtubeId("https://youtu.be/dQw4w9WgXcQ")).toBe("dQw4w9WgXcQ");
    expect(youtubeEmbed("https://www.youtube.com/watch?v=dQw4w9WgXcQ")).toBe("https://www.youtube-nocookie.com/embed/dQw4w9WgXcQ");
    for (const input of ["http://youtu.be/dQw4w9WgXcQ", "https://youtube.com.evil.test/watch?v=dQw4w9WgXcQ", "javascript:alert(1)", "https://youtu.be/not-a-real-id"]) expect(youtubeId(input)).toBeNull();
  });
  it("reports exactly the slides and logo that use an asset", () => {
    const deck = copyStarterDeck();
    const asset = { id: "portrait", type: "image" as const, name: "Portrait", url: deck.slides[0]!.image, alt: "", createdAt: new Date().toISOString() };
    expect(assetUsage(asset, deck).slides[0]?.id).toBe(deck.slides[0]!.id);
    expect(assetUsage({ ...asset, url: deck.theme.logoUrl }, deck).logo).toBe(true);
  });
});
describe("owner-editable slide buttons and domains", () => {
  it("accepts a slide destination and per-line color while rejecting unsafe button schemes", () => {
    const deck = copyStarterDeck();
    deck.slides[0]!.ctaButtons = [{ id: crypto.randomUUID(), label: "Meet the team", style: "outline", url: `#slide:${deck.slides[1]!.id}` }];
    deck.slides[0]!.headlineColors = ["#ffffff", "#e7bc66", "#ffffff"];
    expect(deckSchema.safeParse(deck).success).toBe(true);
    deck.slides[0]!.ctaButtons[0]!.url = "javascript:alert(1)";
    expect(deckSchema.safeParse(deck).success).toBe(false);
  });
  it("normalizes hostnames without accepting protocols, private names or IP addresses", () => {
    expect(normalizeHostname(" WWW.Example.Org. ")).toBe("www.example.org");
    for (const value of ["https://example.org", "127.0.0.1", "localhost", "customer.manus.computer", "example.org/path"]) expect(() => normalizeHostname(value)).toThrow();
  });
});
