import { useState } from "react";
import { ImagePlus, Link2, Plus, Trash2, Upload, Video } from "lucide-react";
import type { TemplateDeck, TemplateSlide } from "./deck";
import { youtubeId } from "./media";
import "./slide-quick-editor.css";

export type QuickSection = "text" | "media" | "buttons";
type Props = {
  section: QuickSection;
  slide: TemplateSlide;
  deck: TemplateDeck;
  onChange: (patch: Partial<TemplateSlide>) => void;
  onUpload: (file: File, target: "image" | "videoUrl") => void;
  onOpenLibrary: () => void;
  onEmbedYouTube: (url: string) => void;
  disabled: boolean;
};

const fonts: TemplateSlide["headlineFont"][] = ["theme", "Manrope", "Inter", "Source Serif 4", "Playfair Display"];
const mediaLayouts = new Set(["split", "profile", "editorial", "programs", "workshops", "faq", "closing", "video"]);

function Destination({ value, deck, onChange, disabled }: { value: string; deck: TemplateDeck; onChange: (value: string) => void; disabled: boolean }) {
  return <label className="studio-quick-field">Destination
    <select disabled={disabled} value={value === "#search" || value.startsWith("#slide:") ? value : "external"} onChange={(event) => onChange(event.target.value === "external" ? "" : event.target.value)}>
      <option value="external">Website, email, phone or map</option><option value="#search">Website search bar</option>
      {deck.slides.map((item, index) => <option key={item.id} value={`#slide:${item.id}`}>Slide {index + 1}: {item.title.replace(/\n/g, " ").slice(0, 24)}{item.visible ? "" : " (hidden)"}</option>)}
    </select>
    {!value.startsWith("#slide:") && value !== "#search" && <input aria-label="CTA external destination" value={value} disabled={disabled} onChange={(event) => onChange(event.target.value)} placeholder="https://, mailto:, tel:, or a map link" />}
  </label>;
}

export function SlideQuickEditor({ section, slide, deck, onChange, onUpload, onOpenLibrary, onEmbedYouTube, disabled }: Props) {
  const [youtube, setYoutube] = useState("");
  const lines = slide.title.split("\n").slice(0, 12);
  const updateCta = (index: number, patch: Partial<TemplateSlide["ctaButtons"][number]>) => onChange({ ctaButtons: slide.ctaButtons.map((item, i) => i === index ? { ...item, ...patch } : item) });
  const updateItem = (index: number, patch: Partial<TemplateSlide["items"][number]>) => onChange({ items: slide.items.map((item, i) => i === index ? { ...item, ...patch } : item) });
  const canUseStoryBeats = !["quiz", "memory", "html", "booking", "pathway"].includes(slide.layout);
  const storyBeatName = slide.layout === "programs" ? "Light Path" : slide.layout === "workshops" ? "Session ledger" : slide.layout === "faq" ? "Question field" : "Story beats";
  const storyBeatSingular = slide.layout === "programs" ? "Waypoint" : slide.layout === "workshops" ? "Session" : slide.layout === "faq" ? "Question" : "Story beat";

  return <div className="studio-quick" aria-label="Edit the selected slide">
    {section === "text" && <section className="studio-quick-section" id="studio-quick-text">
      <label className="studio-quick-field">Headline<textarea aria-label="Headline" rows={3} value={slide.title} maxLength={250} disabled={disabled} onChange={(event) => onChange({ title: event.target.value, headlineColors: slide.headlineColors.slice(0, event.target.value.split("\n").length) })} /></label>
      <div className="studio-quick-type-grid">
        <label className="studio-quick-field">Typeface<select value={slide.headlineFont} disabled={disabled} onChange={(event) => onChange({ headlineFont: event.target.value as TemplateSlide["headlineFont"] })}>{fonts.map((font) => <option value={font} key={font}>{font === "theme" ? "Website default" : font}</option>)}</select></label>
        <label className="studio-quick-field">Size <span className="studio-quick-unit"><input aria-label="Headline size" type="number" min={28} max={150} value={slide.titleSize} disabled={disabled} onChange={(event) => onChange({ titleSize: Math.min(150, Math.max(28, Number(event.target.value) || 28)) })} />px</span></label>
      </div>
      <div className="studio-quick-type-grid">
        <label className="studio-quick-field">Weight<select value={slide.headlineWeight} disabled={disabled} onChange={(event) => onChange({ headlineWeight: Number(event.target.value) })}><option value={400}>Regular</option><option value={500}>Medium</option><option value={600}>Semibold</option><option value={700}>Bold</option><option value={800}>Extra bold</option><option value={900}>Black</option></select></label>
        <label className="studio-quick-field">Alignment<select value={slide.alignment} disabled={disabled} onChange={(event) => onChange({ alignment: event.target.value as TemplateSlide["alignment"] })}><option value="left">Left</option><option value="center">Center</option><option value="right">Right</option></select></label>
      </div>
      <div className="studio-quick-lines"><strong>Color each headline line</strong>{lines.map((line, index) => <label key={`${index}-${line}`}><span>{line || `Line ${index + 1}`}</span><input aria-label={`Color for headline line ${index + 1}`} type="color" value={slide.headlineColors[index] ?? (line.trim() === slide.accentLine.trim() && slide.accentLine.trim() ? slide.accent : slide.foreground)} disabled={disabled} onChange={(event) => { const colors = lines.map((text, i) => slide.headlineColors[i] ?? (text.trim() === slide.accentLine.trim() && slide.accentLine.trim() ? slide.accent : slide.foreground)); colors[index] = event.target.value; onChange({ headlineColors: colors }); }} /></label>)}</div>
      <label className="studio-quick-field">Supporting text<textarea aria-label="Supporting text" rows={3} value={slide.subtitle} maxLength={400} disabled={disabled} onChange={(event) => onChange({ subtitle: event.target.value })} /></label>
      <details className="studio-quick-disclosure"><summary>Section label &amp; more story text</summary><label className="studio-quick-field">Small section label<input value={slide.eyebrow} disabled={disabled} onChange={(event) => onChange({ eyebrow: event.target.value })} /></label><label className="studio-quick-field">Additional story<textarea rows={3} value={slide.body} disabled={disabled} onChange={(event) => onChange({ body: event.target.value })} /></label></details>
      {canUseStoryBeats && <details className="studio-quick-disclosure studio-quick-beats" open={slide.items.length > 0}><summary>{storyBeatName} content</summary><p>Every point visitors see can be edited here.</p>{slide.items.map((item, index) => <div className="studio-quick-beat" key={item.id}><div><strong>{storyBeatSingular} {index + 1}</strong><button type="button" disabled={disabled} aria-label={`Remove story beat ${index + 1}`} onClick={() => onChange({ items: slide.items.filter((_, i) => i !== index) })}><Trash2 size={15} /> Remove</button></div><label className="studio-quick-field">Small label<input value={item.meta} disabled={disabled} maxLength={100} onChange={(event) => updateItem(index, { meta: event.target.value })} /></label><label className="studio-quick-field">Heading<input value={item.title} disabled={disabled} maxLength={160} onChange={(event) => updateItem(index, { title: event.target.value })} /></label><label className="studio-quick-field">Description<textarea rows={2} value={item.body} disabled={disabled} maxLength={700} onChange={(event) => updateItem(index, { body: event.target.value })} /></label><label className="studio-quick-field">Optional link<input value={item.url} disabled={disabled} maxLength={2000} onChange={(event) => updateItem(index, { url: event.target.value })} placeholder="https:// or leave empty" /></label></div>)}<button className="studio-quick-add" type="button" disabled={disabled || slide.items.length >= 12} onClick={() => onChange({ items: [...slide.items, { id: crypto.randomUUID(), title: "New story beat", body: "Describe this part of your story.", meta: "", url: "" }] })}><Plus size={16} /> Add a story beat</button></details>}
    </section>}

    {section === "media" && <section className="studio-quick-section" id="studio-quick-media">
      {mediaLayouts.has(slide.layout) ? <>
        {slide.image ? <div className="studio-quick-current"><img src={slide.image} alt={slide.imageAlt || "Current slide photo"} /><div><strong>Current photo</strong><button type="button" disabled={disabled} onClick={() => onChange({ image: "", imageAlt: "" })}><Trash2 size={15} /> Remove from slide</button></div></div> : <p className="studio-quick-empty">No photo on this slide. Choose one below.</p>}
        <div className="studio-quick-actions"><label className="studio-quick-upload"><ImagePlus size={17} /> Upload / replace photo<input type="file" accept="image/jpeg,image/png,image/webp,image/gif,image/avif" disabled={disabled} onChange={(event) => { const file = event.target.files?.[0]; if (file) onUpload(file, "image"); event.currentTarget.value = ""; }} /></label><button type="button" disabled={disabled} onClick={onOpenLibrary}>Choose from Media Library</button></div>
        <label className="studio-quick-field">Photo description<input value={slide.imageAlt} maxLength={200} disabled={disabled} onChange={(event) => onChange({ imageAlt: event.target.value })} placeholder="Describe the photo for accessibility" /></label>
        <div className="studio-quick-divider" />
        <strong className="studio-quick-subhead">Video</strong>
        <div className="studio-quick-actions"><label className="studio-quick-upload"><Upload size={17} /> Upload video<input type="file" accept="video/mp4,video/webm,video/quicktime" disabled={disabled} onChange={(event) => { const file = event.target.files?.[0]; if (file) onUpload(file, "videoUrl"); event.currentTarget.value = ""; }} /></label>{slide.videoUrl && <button type="button" disabled={disabled} onClick={() => onChange({ videoUrl: "" })}><Trash2 size={15} /> Remove video</button>}</div>
        <form className="studio-quick-youtube" onSubmit={(event) => { event.preventDefault(); if (!youtubeId(youtube)) return; onEmbedYouTube(youtube); setYoutube(""); }}><label className="studio-quick-field">Embed YouTube<input value={youtube} disabled={disabled} onChange={(event) => setYoutube(event.target.value)} placeholder="Paste a YouTube video link" /></label><button type="submit" disabled={disabled || !youtubeId(youtube)}><Video size={17} /> Add video</button></form>
      </> : <div className="studio-quick-empty"><strong>This is an interactive slide.</strong><p>Its experience is edited in the controls below. To use a photo or video, choose a photo or video layout.</p></div>}
    </section>}

    {section === "buttons" && <section className="studio-quick-section" id="studio-quick-buttons"><p className="studio-quick-intro">Give visitors a next step right on this slide.</p>
      <div className="studio-quick-button"><strong>Main button</strong><label className="studio-quick-field">Button label<input value={slide.ctaLabel} maxLength={100} disabled={disabled} onChange={(event) => onChange({ ctaLabel: event.target.value })} placeholder="Book a workshop" /></label><Destination value={slide.ctaUrl} deck={deck} disabled={disabled} onChange={(ctaUrl) => onChange({ ctaUrl })} /></div>
      {slide.ctaButtons.map((button, index) => <div className="studio-quick-button" key={button.id}><div className="studio-quick-button-head"><strong>Button {index + 2}</strong><button type="button" aria-label={`Remove button ${index + 2}`} onClick={() => onChange({ ctaButtons: slide.ctaButtons.filter((_, i) => i !== index) })} disabled={disabled}><Trash2 size={16} /></button></div><label className="studio-quick-field">Button label<input value={button.label} disabled={disabled} maxLength={100} onChange={(event) => updateCta(index, { label: event.target.value })} /></label><Destination value={button.url} deck={deck} disabled={disabled} onChange={(url) => updateCta(index, { url })} /><label className="studio-quick-field">Style<select value={button.style} disabled={disabled} onChange={(event) => updateCta(index, { style: event.target.value as "gold" | "outline" })}><option value="gold">Gold filled</option><option value="outline">Outline</option></select></label></div>)}
      <button className="studio-quick-add" type="button" onClick={() => onChange({ ctaButtons: [...slide.ctaButtons, { id: crypto.randomUUID(), label: "", url: "", style: "outline" }] })} disabled={disabled || slide.ctaButtons.length >= 4}><Plus size={16} /> Add CTA button</button>
      <p className="studio-quick-help"><Link2 size={15} /> Link to another slide, your search bar, email, a tap-to-call number, or a secure map/web address.</p>
    </section>}
  </div>;
}
