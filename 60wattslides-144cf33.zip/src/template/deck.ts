export type Layout = "split" | "profile" | "editorial" | "programs" | "workshops" | "faq" | "closing" | "video" | "quiz" | "memory" | "html" | "booking" | "pathway";
export type FontFamily = "Manrope" | "Inter" | "Source Serif 4" | "Playfair Display";
export type SlideItem = { id: string; title: string; body: string; meta: string; url: string };
export type QuizChoice = { id: string; text: string; correct: boolean };
export type MemoryPair = { id: string; term: string; meaning: string };
export type BookingSlot = { id: string; label: string; startsAt: string; capacity: number };
export type PathChoice = { id: string; label: string; outcome: string; nextStep: string };
export type CtaButton = { id: string; label: string; url: string; style: "gold" | "outline" };
export type InteractionCopy = {
  kicker: string; prompt: string; idle: string; correct: string; incorrect: string; reset: string; complete: string;
  title: string; intro: string; empty: string; optionHint: string; unavailable: string; resultLabel: string;
  formTitle: string; nameLabel: string; emailLabel: string; messageLabel: string; consent: string;
  submit: string; sending: string; helper: string; confirmed: string;
  pairsLabel: string; turnSingular: string; turnPlural: string;
};

export type TemplateSlide = {
  id: string;
  layout: Layout;
  visible: boolean;
  eyebrow: string;
  title: string;
  accentLine: string;
  headlineColors: string[];
  subtitle: string;
  body: string;
  image: string;
  imageAlt: string;
  imagePositionX: number;
  imagePositionY: number;
  mobileFocusY: number;
  imageFit: "cover" | "contain";
  videoUrl: string;
  background: string;
  foreground: string;
  accent: string;
  imageWidth: number;
  copyInset: number;
  overlay: number;
  titleSize: number;
  headlineFont: FontFamily | "theme";
  headlineWeight: number;
  bodySize: number;
  alignment: "left" | "center" | "right";
  showRule: boolean;
  ctaLabel: string;
  ctaUrl: string;
  ctaButtons: CtaButton[];
  items: SlideItem[];
  quizQuestion: string;
  quizChoices: QuizChoice[];
  quizExplanation: string;
  gamePairs: MemoryPair[];
  htmlContent: string;
  bookingSlots: BookingSlot[];
  pathQuestion: string;
  pathChoices: PathChoice[];
  interactionCopy: InteractionCopy;
  interactionCopyCustomized: boolean;
};

export type DeckTheme = {
  brandName: string;
  tagline: string;
  logoUrl: string;
  ink: string;
  forest: string;
  gold: string;
  paper: string;
  displayFont: FontFamily;
  bodyFont: FontFamily;
  progressStyle: "segments" | "dots" | "line";
  progressColor: string;
  showProgress: boolean;
  showCounter: boolean;
  showArrows: boolean;
  showPause: boolean;
  showSearch: boolean;
  autoplaySeconds: number;
  searchLabel: string;
  searchPlaceholder: string;
  searchBackground: string;
  searchForeground: string;
  searchButton: string;
  searchRadius: number;
  searchContext: string;
  searchMultipleSourcesNotice: string;
  searchFoundPrefix: string;
  searchSourceLabel: string;
  storyLinkLabel: string;
  noAnswerEyebrow: string;
  noAnswerSubtitle: string;
  noAnswerBody: string;
  noAnswerNotice: string;
  noAnswerDraftNote: string;
};

export type TemplateDeck = { version: 1; theme: DeckTheme; slides: TemplateSlide[] };

const sample = (id: string, title: string, body = "", meta = "", url = ""): SlideItem => ({ id, title, body, meta, url });
const emptyInteractionCopy = (): InteractionCopy => ({
  kicker: "", prompt: "", idle: "", correct: "", incorrect: "", reset: "", complete: "",
  title: "", intro: "", empty: "", optionHint: "", unavailable: "", resultLabel: "", formTitle: "", nameLabel: "", emailLabel: "", messageLabel: "", consent: "",
  submit: "", sending: "", helper: "", confirmed: "", pairsLabel: "", turnSingular: "", turnPlural: "",
});
const base = (id: string, layout: Layout, title: string, image: string): TemplateSlide => ({
  id, layout, visible: true, eyebrow: "60 WATTS OF CLARITY", title, accentLine: "", headlineColors: [], subtitle: "", body: "",
  image, imageAlt: "Editorial photograph for this slide", imagePositionX: 50, imagePositionY: 50, mobileFocusY: 50, imageFit: "cover", videoUrl: "",
  background: "#111514", foreground: "#fffdf8", accent: "#e7bc66", imageWidth: 50, copyInset: 72, overlay: 0,
  titleSize: 92, headlineFont: "theme", headlineWeight: 800, bodySize: 27, alignment: "left", showRule: true, ctaLabel: "", ctaUrl: "", ctaButtons: [], items: [],
  quizQuestion: "", quizChoices: [], quizExplanation: "", gamePairs: [], htmlContent: "",
  bookingSlots: [], pathQuestion: "", pathChoices: [], interactionCopy: emptyInteractionCopy(), interactionCopyCustomized: false,
});

const interactionDefaults: Partial<Record<Layout, Partial<InteractionCopy>>> = {
  quiz: { kicker: "YOUR TURN · CHOOSE ONE", idle: "Choose an answer to reveal feedback.", correct: "That’s right.", incorrect: "Not quite. Try another choice.", reset: "Start again" },
  memory: { kicker: "PLAY THE IDEA · MATCH THE PAIRS", prompt: "Reveal two lights to find a match.", complete: "Perfect match.", reset: "New round", confirmed: "You found every pair. Take the idea with you.", pairsLabel: "pairs", turnSingular: "turn", turnPlural: "turns" },
  booking: { title: "Choose a workshop", intro: "Pick a time, then request a place without leaving this page.", empty: "Workshop times will appear here when the owner adds them.", optionHint: "request a place", unavailable: "unavailable", formTitle: "Request this place", nameLabel: "Your name", emailLabel: "Email address", messageLabel: "Anything we should know? (optional)", consent: "I agree to share these details with {brand} about this request.", submit: "Request my place", sending: "Sending…", helper: "This is a request, not a confirmed reservation.", confirmed: "Request received. The owner will confirm details; no payment was collected." },
  pathway: { title: "What would help you most?", intro: "Choose what matters to you. Your next step appears immediately.", empty: "The owner is preparing the choices for this slide.", resultLabel: "Your next step", formTitle: "Want a follow-up? Share your details (optional).", nameLabel: "Your name", emailLabel: "Email address", messageLabel: "Anything we should know? (optional)", consent: "I agree to share these details with {brand} about this request.", submit: "Save my request", sending: "Sending…", helper: "Your choice works without giving your details.", confirmed: "Your follow-up request is saved. The owner can see it in their CRM." },
};

/** Returns usable default visitor copy for legacy decks, while preserving every owner override. */
export function resolvedInteractionCopy(slide: TemplateSlide): InteractionCopy {
  const fallback = { ...emptyInteractionCopy(), ...(interactionDefaults[slide.layout] ?? {}) } as InteractionCopy;
  if (slide.interactionCopyCustomized) return { ...fallback, ...slide.interactionCopy };
  for (const [key, value] of Object.entries(slide.interactionCopy) as [keyof InteractionCopy, string][]) {
    if (value.trim()) fallback[key] = value;
  }
  return fallback;
}

export const STARTER_DECK: TemplateDeck = {
  version: 1,
  theme: {
    brandName: "60 WATTS OF CLARITY",
    tagline: "AI FOR A MORE HUMAN TOMORROW",
    logoUrl: "/60-watts-mark.svg",
    ink: "#111514", forest: "#22594a", gold: "#e7bc66", paper: "#f8f7f2",
    displayFont: "Manrope", bodyFont: "Inter", progressStyle: "segments", progressColor: "#e7bc66",
    showProgress: true, showCounter: true, showArrows: true, showPause: true, showSearch: true, autoplaySeconds: 20,
    searchLabel: "Search the slides", searchPlaceholder: "Ask about our services, workshops, or story...",
    searchBackground: "#ffffff", searchForeground: "#20392f", searchButton: "#22594a", searchRadius: 999,
    searchContext: "Answers link to published slides. Missing topics stay unverified.", searchMultipleSourcesNotice: "Choose a source slide below.", searchFoundPrefix: "Found in", searchSourceLabel: "FOUND IN SLIDE", storyLinkLabel: "Follow this thread",
    noAnswerEyebrow: "NEW TOPIC · NOT PUBLISHED", noAnswerSubtitle: "This presentation does not contain a verified answer yet.", noAnswerBody: "This slide exists only in your current visit. An owner can research the question and add an answer before publishing it.", noAnswerNotice: "Unpublished topic slide added. No answer was invented.", noAnswerDraftNote: "Draft for this visit only · verify before publishing",
  },
  slides: [
    {
      ...base("opening", "split", "Learn it.\nBuild it.\nDeploy it.", "/manus-storage/split-portrait_52da614a.webp"),
      eyebrow: "", accentLine: "Build it.", headlineColors: ["#fffdf8", "#e7bc66", "#fffdf8"], subtitle: "AI education & consultation\nfor social workers.",
      imageAlt: "A person seated in a sunlit studio", imagePositionX: 53, imagePositionY: 45, mobileFocusY: 0, imageWidth: 50,
    },
    {
      ...base("founder", "profile", "Human first.\nAlways.", "/manus-storage/founder-portrait_734f239c.webp"),
      eyebrow: "THE PEOPLE", subtitle: "Real people. Real purpose. A more human way forward.",
      body: "Our work begins with listening. We connect people, practical ideas, and thoughtful tools so technology serves the communities around us.",
      imageAlt: "A person smiling in a bright office", imagePositionX: 50, imagePositionY: 35, imageWidth: 51,
      titleSize: 76, bodySize: 23,
    },
    {
      ...base("pathway", "editorial", "Your pathway\nto what comes next.", "/manus-storage/async-images/uegu0OfrMdL7EGd3QNyCaH/image-1.webp"),
      eyebrow: "01 / THE IDEA", subtitle: "A clearer path begins with one small step.",
      body: "Start with curiosity. Build with care. Put what you learn to work in ways that respect real people and real-world context.",
      background: "#f8f7f2", foreground: "#173d32", accent: "#d2a94e", imageWidth: 47, titleSize: 78, headlineFont: "Source Serif 4", headlineWeight: 700, bodySize: 24,
      imageAlt: "A smiling person in a calm creative workspace",
    },
    {
      ...base("programs", "programs", "Explore what\nwe can build.", "/manus-storage/learning-room_d0e8cfbf.webp"),
      eyebrow: "02 / WHAT WE DO", subtitle: "Practical programs and learning for a more thoughtful future.",
      background: "#f8f7f2", foreground: "#173d32", titleSize: 73, bodySize: 23,
      imageAlt: "A sunlit learning room with a shared table",
      items: [
        sample("p1", "Learn", "A friendly starting point, at your pace.", "FOUNDATIONS"),
        sample("p2", "Build", "Turn what you know into useful practice.", "HANDS-ON"),
        sample("p3", "Deploy", "Bring your next idea into the world.", "REAL IMPACT"),
      ],
    },
    {
      ...base("workshops", "workshops", "Better together.\nLearn by doing.", "/manus-storage/async-images/uegu0OfrMdL7EGd3QNyCaH/image-2.webp"),
      eyebrow: "03 / EXPERIENCES", subtitle: "Small groups. Useful ideas. Room to ask questions.",
      background: "#f8f7f2", foreground: "#173d32", titleSize: 70, bodySize: 22,
      imageAlt: "A facilitator welcoming people into a learning session",
      items: [
        sample("w1", "An open conversation", "Explore a topic with real people and practical examples.", "WORKSHOP"),
        sample("w2", "Build something useful", "Turn insight into a process you can actually use.", "PRACTICE SESSION"),
      ],
    },
    {
      ...base("questions", "faq", "Good questions\ndeserve clear answers.", "/manus-storage/golden-light_8a646cb9.webp"),
      eyebrow: "04 / QUESTIONS", subtitle: "The details matter. Start with what people ask most.",
      background: "#f8f7f2", foreground: "#173d32", titleSize: 70, headlineFont: "Source Serif 4", headlineWeight: 700, bodySize: 21,
      imageAlt: "Warm light and soft shadows",
      items: [
        sample("q1", "Who is this for?", "People and teams who want a more confident, thoughtful way to learn."),
        sample("q2", "Do I need previous experience?", "No. Start with where you are and build from there."),
        sample("q3", "Can I ask a different question?", "Yes. Use the search bar to look through the slides."),
      ],
    },
    {
      ...base("closing", "closing", "A brighter way\nstarts here.", "/manus-storage/async-images/uegu0OfrMdL7EGd3QNyCaH/image-3.webp"),
      eyebrow: "THE NEXT CHAPTER", accentLine: "starts here.", headlineColors: ["#fffdf8", "#e7bc66"],
      subtitle: "A simple step today can change what tomorrow looks like.",
      body: "Explore the story or ask a question below. The next step is easier when the path is clear.",
      imageAlt: "Colleagues talking in a welcoming studio",
      ctaLabel: "Ask this presentation", ctaUrl: "#search", titleSize: 82, bodySize: 23,
    },
  ],
};

export function copyStarterDeck(): TemplateDeck {
  return structuredClone(STARTER_DECK);
}

const PREVIOUS_STARTER_PHOTOS: Record<string, { image: string; alt: string }> = {
  pathway: { image: "/manus-storage/async-images/s4AEsHDA1xc8BnXtej654y/image-1.webp", alt: "Warm sunlit abstract pathway" },
  workshops: { image: "/manus-storage/studio-room_0a9d7650.webp", alt: "Warm, calm workshop space" },
  closing: { image: "/manus-storage/sun-path_ce6f6535.webp", alt: "Editorial photograph for this slide" },
};

/** Update only untouched example photos, never an owner's custom image or published snapshot. */
export function starterPhotosNeedUpdate(deck: TemplateDeck): boolean {
  return deck.slides.some((slide) => slide.image === PREVIOUS_STARTER_PHOTOS[slide.id]?.image);
}

export function refreshUntouchedStarterPhotos(deck: TemplateDeck): TemplateDeck {
  if (!starterPhotosNeedUpdate(deck)) return deck;
  return {
    ...deck,
    slides: deck.slides.map((slide) => {
      const previous = PREVIOUS_STARTER_PHOTOS[slide.id];
      if (!previous || slide.image !== previous.image) return slide;
      const current = STARTER_DECK.slides.find((starter) => starter.id === slide.id)!;
      return { ...slide, image: current.image, imageAlt: slide.imageAlt === previous.alt ? current.imageAlt : slide.imageAlt };
    }),
  };
}

export function newSlide(layout: Layout, position: number): TemplateSlide {
  const matching = STARTER_DECK.slides.find((slide) => slide.layout === layout);
  const starter = matching ? structuredClone(matching) : interactivePreset(layout);
  starter.id = `slide-${crypto.randomUUID()}`;
  starter.visible = false;
  starter.eyebrow = `NEW SLIDE ${String(position + 1).padStart(2, "0")}`;
  return starter;
}

function interactivePreset(layout: Layout): TemplateSlide {
  if (layout === "video") return {
    ...base("video", "video", "Watch the story\nunfold.", "/manus-storage/studio-room_0a9d7650.webp"),
    subtitle: "Add your own video to give visitors a closer look at the work.",
    body: "Upload an MP4 or WebM file in the Media tab. The photo is your poster image.",
    background: "#173d32", imageAlt: "A welcoming workshop space", titleSize: 68,
  };
  if (layout === "quiz") return {
    ...base("quiz", "quiz", "A question worth\nexploring.", ""),
    subtitle: "An interactive choice turns a page into a conversation.",
    background: "#173d32", titleSize: 72,
    quizQuestion: "What should come first when using AI in a people-centered practice?",
    quizChoices: [
      { id: "q-a", text: "Check privacy and keep human judgment in the loop", correct: true },
      { id: "q-b", text: "Upload private case notes to save time", correct: false },
      { id: "q-c", text: "Accept every suggestion without review", correct: false },
    ],
    quizExplanation: "Protecting people and checking outputs come before speed.",
  };
  if (layout === "memory") return {
    ...base("memory", "memory", "Make the lesson\nstick.", ""),
    subtitle: "Reveal two lights at a time to connect ideas with their meaning.",
    background: "#173d32", titleSize: 70,
    gamePairs: [
      { id: "m-a", term: "Curiosity", meaning: "Ask better questions" },
      { id: "m-b", term: "Care", meaning: "Protect the person" },
      { id: "m-c", term: "Clarity", meaning: "Make it understandable" },
    ],
  };
  if (layout === "html") return {
    ...base("html", "html", "A canvas for\nyour own idea.", ""),
    subtitle: "Build a custom moment with HTML, CSS and a little JavaScript.",
    background: "#f8f7f2", foreground: "#173d32", titleSize: 62,
    htmlContent: '<style>body{display:grid;place-items:center;height:100vh;margin:0;background:#eaf1e9;color:#173d32;font:600 22px system-ui}button{padding:16px 22px;border:0;border-radius:40px;background:#22594a;color:white;cursor:pointer}</style><main><p id="message">Hello from your custom slide.</p><button id="reveal">Reveal the next idea</button></main><script>document.getElementById("reveal").addEventListener("click",()=>{document.getElementById("message").textContent="Anything is possible inside this canvas."})</script>',
  };
  if (layout === "booking") return {
    ...base("booking", "booking", "Make room for\na real conversation.", ""),
    eyebrow: "BOOK A WORKSHOP", subtitle: "Find a time that works. Request a seat right here, without leaving the story.",
    background: "#173d32", titleSize: 70, bodySize: 22,
    bookingSlots: [{ id: "sample-session", label: "Your first workshop", startsAt: "", capacity: 12 }],
  };
  if (layout === "pathway") return {
    ...base("pathway-choice", "pathway", "A next step\nmade for you.", ""),
    eyebrow: "YOUR OWN PATH", subtitle: "Pick what you need. See a useful next step written by the website owner.",
    background: "#f8f7f2", foreground: "#173d32", titleSize: 68, headlineFont: "Source Serif 4", headlineWeight: 700,
    pathQuestion: "What would help you most right now?",
    pathChoices: [
      { id: "understand", label: "Understand the basics", outcome: "Begin with a clear, jargon-free foundation.", nextStep: "Ask for a beginner-friendly workshop." },
      { id: "practice", label: "Try it with my team", outcome: "Learn together using examples from your work.", nextStep: "Explore a guided team session." },
      { id: "build", label: "Create something useful", outcome: "Start small, test carefully, and keep people at the center.", nextStep: "Plan a practical project conversation." },
    ],
  };
  return base("custom", layout, "Your new story.", "");
}
