import type { CSSProperties } from "react";
import type { TemplateSlide } from "./deck";
import "./slide-thumbnail.css";

const PHOTO_LEFT = new Set(["split", "profile", "closing", "workshops"]);
const PHOTO_RIGHT = new Set(["editorial", "programs", "faq", "video"]);

export function SlideThumbnail({ slide }: { slide: TemplateSlide }) {
  const hasPhoto = Boolean(slide.image) && (PHOTO_LEFT.has(slide.layout) || PHOTO_RIGHT.has(slide.layout));
  const left = PHOTO_LEFT.has(slide.layout);
  const style = {
    "--thumb-ink": slide.background,
    "--thumb-text": slide.foreground,
    "--thumb-accent": slide.accent,
    "--thumb-image": slide.image ? `url("${slide.image.replace(/"/g, "%22")}")` : "none",
  } as CSSProperties;
  return <span className={`studio-thumb ${hasPhoto ? left ? "has-photo is-photo-left" : "has-photo is-photo-right" : "is-type-only"}`} style={style} aria-hidden="true">
    {hasPhoto && <span className="studio-thumb-photo" />}
    <span className="studio-thumb-copy"><span className="studio-thumb-mark" />
      <span className="studio-thumb-headline">{slide.title.split("\n").slice(0, 3).map((line, index) => <span key={index} style={{ color: slide.headlineColors[index] ?? (line.trim() === slide.accentLine.trim() && slide.accentLine ? slide.accent : undefined) }}>{line}</span>)}</span>
      <span className="studio-thumb-rule" />
    </span>
  </span>;
}
