import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { leadInputSchema, leadStageSchema } from "./crm";
import { getHostedLeads, submitHostedLead, updateHostedLead } from "./crm.server";

export const submitLead = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => leadInputSchema.parse(data))
  .handler(async ({ data }) => { await submitHostedLead(data); return { received: true }; });

export const getMyLeads = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => getHostedLeads(context.userId));

export const updateMyLead = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ id: z.string().uuid(), stage: leadStageSchema, notes: z.string().max(2000) }).parse(data))
  .handler(async ({ context, data }) => { await updateHostedLead(context.userId, data.id, data.stage, data.notes); return { saved: true }; });
