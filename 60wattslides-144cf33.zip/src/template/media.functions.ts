import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { deleteOwnedMedia, listOwnedMedia, registerOwnedUpload, registerOwnedYoutube } from "./media.server";

export const listMyMedia = createServerFn({ method: "GET" }).middleware([requireSupabaseAuth])
  .handler(async ({ context }) => listOwnedMedia(context.userId));
export const finalizeMyUpload = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ url: z.string().min(1).max(2000), title: z.string().min(1).max(160), alt: z.string().max(200).default("") }).parse(data))
  .handler(async ({ context, data }) => registerOwnedUpload(context.userId, data.url, data.title, data.alt));
export const addMyYoutube = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ url: z.string().url().max(500), title: z.string().min(1).max(160) }).parse(data))
  .handler(async ({ context, data }) => registerOwnedYoutube(context.userId, data.url, data.title));
export const removeMyMedia = createServerFn({ method: "POST" }).middleware([requireSupabaseAuth])
  .inputValidator((data: unknown) => z.object({ id: z.string().uuid() }).parse(data))
  .handler(async ({ context, data }) => deleteOwnedMedia(context.userId, data.id));
