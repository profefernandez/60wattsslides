import { useEffect, useRef, useState } from "react";
import { clampPan, panBy, photoContainer, photoFrame, photoState, wheelFactor, zoomAt, type PhotoState } from "@/lib/slide-placement";
import type { TextStyle } from "@/lib/slide-text";
import { cn } from "@/lib/utils";

interface PhotoEditSurfaceProps {
  src: string;
  alt: string;
  style: Partial<TextStyle>;
  defaultFit: "cover" | "contain";
  imgClassName?: string;
  allowShape?: boolean;
  allowSplit?: boolean;
  /** Only passed in the CMS preview; without it the photo renders as a plain image. */
  onPhotoChange?: ((patch: Partial<TextStyle>) => void) | undefined;
}

export function PhotoEditSurface({ src, alt, style, defaultFit, imgClassName, allowShape = false, allowSplit = false, onPhotoChange }: PhotoEditSurfaceProps) {
  const box = photoContainer(allowShape ? style : { ...style, media_shape: "full" });
  const frameRef = useRef<HTMLDivElement>(null);
  const rootRef = useRef<HTMLDivElement>(null);
  const [selected, setSelected] = useState(false);
  const [live, setLive] = useState<PhotoState | null>(null);
  const [message, setMessage] = useState("");
  const liveRef = useRef<PhotoState | null>(null);
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const gesture = useRef<{ dist: number; cx: number; cy: number } | null>(null);
  const wheelTimer = useRef<number | undefined>(undefined);
  const base = photoState(style);
  const current = live ?? base;
  const editable = !!onPhotoChange;

  const show = (s: PhotoState) => { liveRef.current = s; setLive(s); };
  const commit = (s: PhotoState | null = liveRef.current, note?: string) => {
    if (s) onPhotoChange?.({ media_zoom: Math.round(s.zoom * 10) / 10, media_x: Math.round(s.x * 10) / 10, media_y: Math.round(s.y * 10) / 10 });
    liveRef.current = null; setLive(null);
    if (s) setMessage(note ?? `Photo zoom ${Math.round(s.zoom)}%`);
  };
  const stateRef = useRef(current);
  stateRef.current = current;

  useEffect(() => {
    if (!selected) return;
    const el = frameRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const rect = el.getBoundingClientRect();
      show(zoomAt(liveRef.current ?? stateRef.current, wheelFactor(e.deltaY, e.deltaMode), e.clientX - rect.left, e.clientY - rect.top, rect.width, rect.height));
      window.clearTimeout(wheelTimer.current);
      wheelTimer.current = window.setTimeout(() => commit(), 200);
    };
    const onOutside = (e: PointerEvent) => { if (!rootRef.current?.contains(e.target as Node)) setSelected(false); };
    el.addEventListener("wheel", onWheel, { passive: false });
    document.addEventListener("pointerdown", onOutside);
    return () => { el.removeEventListener("wheel", onWheel); document.removeEventListener("pointerdown", onOutside); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected]);

  const img = <img src={src} alt={alt} draggable={false} className={cn("h-full w-full select-none", imgClassName)} style={photoFrame({ ...style, media_zoom: current.zoom, media_x: current.x, media_y: current.y }, defaultFit)} />;
  if (!editable) return <div className={box.className} style={box.style}>{img}</div>;

  const center = (rect: DOMRect) => [rect.width / 2, rect.height / 2] as const;
  const zoomBy = (factor: number) => {
    const rect = frameRef.current?.getBoundingClientRect();
    const [px, py] = rect ? center(rect) : [0, 0];
    commit(zoomAt(stateRef.current, factor, px, py, rect?.width ?? 0, rect?.height ?? 0));
  };

  return (
    <div ref={rootRef} className="absolute inset-0" data-photo-surface>
      <div ref={frameRef} tabIndex={0} role="application" aria-roledescription="photo editor"
        aria-label={selected ? "Photo selected: drag to move, scroll or pinch to zoom, arrow keys pan, plus and minus zoom, 0 resets, Escape to finish" : "Photo: press Enter or click to edit framing"}
        className={cn(box.className, selected ? "cursor-grab touch-none ring-2 ring-primary ring-offset-2 ring-offset-background active:cursor-grabbing" : "cursor-pointer")}
        style={box.style}
        onClick={(e) => { e.stopPropagation(); setSelected(true); }}
        onDoubleClick={(e) => { e.stopPropagation(); const fit = (style.media_fit ?? defaultFit) === "contain" ? "cover" : "contain"; onPhotoChange?.({ media_fit: fit, media_zoom: 100, media_x: 0, media_y: 0 }); setMessage(fit === "contain" ? "Showing whole photo" : "Photo fills the frame"); }}
        onTouchStart={(e) => { if (selected) e.stopPropagation(); }}
        onTouchEnd={(e) => { if (selected) e.stopPropagation(); }}
        onPointerDown={(e) => {
          e.stopPropagation();
          if (!selected) return;
          e.preventDefault();
          e.currentTarget.setPointerCapture(e.pointerId);
          pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
          gesture.current = null;
        }}
        onPointerMove={(e) => {
          const prev = pointers.current.get(e.pointerId);
          const rect = frameRef.current?.getBoundingClientRect();
          if (!selected || !prev || !rect) return;
          e.stopPropagation();
          pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
          const pts = [...pointers.current.values()];
          const s = liveRef.current ?? stateRef.current;
          if (pts.length >= 2) {
            const [a, b] = pts as [{ x: number; y: number }, { x: number; y: number }];
            const dist = Math.hypot(a.x - b.x, a.y - b.y);
            const cx = (a.x + b.x) / 2 - rect.left, cy = (a.y + b.y) / 2 - rect.top;
            const g = gesture.current;
            gesture.current = { dist, cx, cy };
            if (!g || !g.dist) return;
            const zoomed = zoomAt(s, dist / g.dist, cx, cy, rect.width, rect.height);
            show(panBy(zoomed, (cx - g.cx) / rect.width * 100, (cy - g.cy) / rect.height * 100));
          } else {
            show(panBy(s, (e.clientX - prev.x) / rect.width * 100, (e.clientY - prev.y) / rect.height * 100));
          }
        }}
        onPointerUp={(e) => {
          pointers.current.delete(e.pointerId);
          gesture.current = null;
          if (pointers.current.size === 0 && liveRef.current) commit(liveRef.current, liveRef.current.zoom !== base.zoom ? undefined : "Photo moved");
        }}
        onPointerCancel={(e) => { pointers.current.delete(e.pointerId); gesture.current = null; if (pointers.current.size === 0) commit(); }}
        onKeyDown={(e) => {
          if (!selected) {
            if (e.key === "Enter" || e.key === " ") { e.preventDefault(); e.stopPropagation(); setSelected(true); }
            return;
          }
          const step = e.shiftKey ? 5 : 1;
          const s = stateRef.current;
          let next: PhotoState | null = null;
          if (e.key === "ArrowLeft") next = panBy(s, -step, 0);
          else if (e.key === "ArrowRight") next = panBy(s, step, 0);
          else if (e.key === "ArrowUp") next = panBy(s, 0, -step);
          else if (e.key === "ArrowDown") next = panBy(s, 0, step);
          else if (e.key === "+" || e.key === "=") { e.preventDefault(); e.stopPropagation(); zoomBy(1.05); return; }
          else if (e.key === "-" || e.key === "_") { e.preventDefault(); e.stopPropagation(); zoomBy(1 / 1.05); return; }
          else if (e.key === "0") next = clampPan({ zoom: 100, x: 0, y: 0 });
          else if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); setSelected(false); return; }
          if (!next) return;
          e.preventDefault(); e.stopPropagation();
          commit(next, e.key === "0" ? "Photo centered" : `Photo moved`);
        }}>
        {img}
      </div>
      <span className="sr-only" aria-live="polite">{message}</span>
    </div>
  );
}
