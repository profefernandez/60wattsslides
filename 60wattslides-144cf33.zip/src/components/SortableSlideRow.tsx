import { useSortable } from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import { ChevronRight, GripVertical } from "lucide-react";
import { Button } from "@/components/ui/button";
import { slideBackground } from "@/lib/slide-background";
import { photoFrame } from "@/lib/slide-placement";
import type { Slide } from "@/lib/cms";

export function SortableSlideRow({ slide, index, onOpen }: { slide: Slide; index: number; onOpen: () => void }) {
  const { attributes, listeners, setNodeRef, setActivatorNodeRef, transform, transition, isDragging } = useSortable({ id: slide.id });
  return (
    <div ref={setNodeRef} style={{ transform: CSS.Transform.toString(transform), transition }} className={`flex min-w-0 items-center rounded-md border border-input bg-background shadow-sm ${isDragging ? "relative z-20 opacity-75 ring-2 ring-ring" : ""}`}>
      <Button ref={setActivatorNodeRef} type="button" size="icon" variant="ghost" className="ml-1 h-11 w-10 shrink-0 cursor-grab touch-none active:cursor-grabbing" aria-label={`Reorder slide ${index + 1}: ${slide.title || "Untitled"}`} title="Drag to reorder" {...attributes} {...listeners}>
        <GripVertical aria-hidden="true" />
      </Button>
      <Button type="button" variant="ghost" onClick={onOpen} className="h-auto min-h-16 min-w-0 flex-1 justify-start gap-3 px-2 py-2 text-left font-normal">
        <div className="h-12 w-16 shrink-0 overflow-hidden rounded bg-muted">
          {(slide.kind === "image" || slide.kind === "photo-text") && slide.media_url && <img src={slide.media_url} alt="" className="h-full w-full object-contain" style={photoFrame(slide.title_style, "contain")} />}
          {slide.kind === "video" && slide.media_url && <video src={slide.media_url} muted playsInline preload="metadata" className="h-full w-full object-cover" />}
          {slide.kind === "text" && slideBackground(slide) === "image" && slide.media_url && <img src={slide.media_url} alt="" className="h-full w-full object-cover" style={photoFrame(slide.title_style)} />}
        </div>
        <span className="min-w-0 flex-1">
          <span className="block truncate font-medium">{slide.title || "Untitled"}</span>
          <span className="block text-xs text-muted-foreground capitalize">Slide {index + 1} · {slide.kind}{!slide.enabled ? " · Hidden" : ""}</span>
        </span>
        <ChevronRight className="h-4 w-4 shrink-0 text-muted-foreground" aria-hidden="true" />
      </Button>
    </div>
  );
}