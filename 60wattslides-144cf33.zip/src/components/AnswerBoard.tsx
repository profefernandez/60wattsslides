import { useEffect, useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Download, Mail, X } from "lucide-react";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { submitBoardLead } from "@/lib/lead.functions";
import { cn } from "@/lib/utils";

export interface BoardItem { anchorId: string; slideId: string; label: string; title: string; body: string; question: string; }

type Delivery = "download" | "email" | "both";

const formSchema = z.object({
  firstName: z.string().trim().min(1, "First name is required").max(80),
  email: z.string().trim().email("Enter a valid email address").max(254),
  organization: z.string().trim().max(120),
});

/** Full-screen board of this session's answers. Lives in React state only; nothing is saved unless the visitor submits the form. */
export function AnswerBoard({ items, formOnOpen, onClose, onRemove }: { items: BoardItem[]; formOnOpen: boolean; onClose: () => void; onRemove: (anchorId: string) => void }) {
  const [zoom, setZoom] = useState<string | null>(null);
  const [form, setForm] = useState<Delivery | null>(formOnOpen ? "download" : null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const shown = items.slice(-4);

  useEffect(() => { headingRef.current?.focus(); }, []);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") { e.stopImmediatePropagation(); if (zoom) setZoom(null); else if (form) setForm(null); else onClose(); } };
    window.addEventListener("keydown", onKey, true);
    return () => window.removeEventListener("keydown", onKey, true);
  }, [zoom, form, onClose]);

  const zoomed = shown.find((i) => i.anchorId === zoom);

  return (
    <div role="dialog" aria-modal="true" aria-labelledby="board-title" className="absolute inset-0 z-40 flex flex-col bg-background/95 backdrop-blur-md">
      <header className="flex flex-wrap items-center gap-2 border-b border-border p-4">
        <h2 id="board-title" ref={headingRef} tabIndex={-1} className="mr-auto font-serif text-2xl text-foreground outline-none">Your answers</h2>
        <Button type="button" size="sm" disabled={!items.length} onClick={() => setForm("download")}><Download aria-hidden="true" /> Download my board</Button>
        <Button type="button" size="sm" variant="outline" disabled={!items.length} onClick={() => setForm("email")}><Mail aria-hidden="true" /> Email it to me</Button>
        <Button type="button" size="icon" variant="ghost" aria-label="Close board" onClick={onClose} className="h-11 w-11"><X aria-hidden="true" /></Button>
        <p className="w-full text-sm text-muted-foreground">This board disappears when you leave. Take a copy with you.</p>
      </header>

      {items.length === 0 ? (
        <p className="m-auto max-w-sm p-6 text-center text-muted-foreground">Ask a question in the bar below. Answers you find collect here.</p>
      ) : (
        <ul aria-label="Answer cards" className={cn("grid min-h-0 flex-1 gap-3 overflow-y-auto p-4",
          shown.length === 1 && "place-items-center",
          shown.length === 2 && "sm:grid-cols-2",
          shown.length >= 3 && "sm:grid-cols-2 sm:grid-rows-2")}>
          {shown.map((item) => (
            <li key={item.anchorId} className={cn("relative flex min-h-40 flex-col rounded-lg border border-primary bg-card p-5 text-card-foreground shadow-sm", shown.length === 1 && "w-full max-w-xl")}>
              <button type="button" onClick={() => setZoom(item.anchorId)} className="flex min-h-0 flex-1 flex-col text-left outline-none focus-visible:ring-2 focus-visible:ring-ring" aria-label={`Open answer: ${item.title}`}>
                <span className="text-xs font-semibold uppercase tracking-wide text-primary">{item.label}</span>
                <span className="mt-1 font-serif text-xl">{item.title}</span>
                <span className="mt-2 line-clamp-5 text-sm text-muted-foreground">{item.body}</span>
              </button>
              <Button type="button" size="icon" variant="ghost" aria-label={`Remove ${item.title} from board`} onClick={() => onRemove(item.anchorId)} className="absolute right-1 top-1 h-11 w-11"><X aria-hidden="true" /></Button>
            </li>
          ))}
        </ul>
      )}

      {zoomed && (
        <div role="dialog" aria-modal="true" aria-label={zoomed.title} className="absolute inset-0 z-50 flex items-center justify-center bg-background/80 p-4">
          <article className="max-h-full w-full max-w-2xl overflow-y-auto rounded-lg border border-primary bg-card p-6 text-card-foreground shadow-xl">
            <div className="flex items-start gap-2">
              <h3 className="mr-auto font-serif text-2xl">{zoomed.title}</h3>
              <Button type="button" size="icon" variant="ghost" aria-label="Back to board" autoFocus onClick={() => setZoom(null)} className="h-11 w-11"><X aria-hidden="true" /></Button>
            </div>
            {zoomed.question && <p className="mt-1 text-sm text-muted-foreground">You asked: {zoomed.question}</p>}
            <p className="mt-4 whitespace-pre-line">{zoomed.body}</p>
          </article>
        </div>
      )}

      {form && <LeadForm items={items} initialDelivery={form} onClose={() => setForm(null)} />}
    </div>
  );
}

function LeadForm({ items, initialDelivery, onClose }: { items: BoardItem[]; initialDelivery: Delivery; onClose: () => void }) {
  const submit = useServerFn(submitBoardLead);
  const [values, setValues] = useState({ firstName: "", email: "", organization: "" });
  const [delivery, setDelivery] = useState<Delivery>(initialDelivery);
  const [marketing, setMarketing] = useState(false);
  const [included, setIncluded] = useState<Set<string>>(() => new Set(items.map((i) => i.anchorId)));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState("");

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = formSchema.safeParse(values);
    const next: Record<string, string> = {};
    if (!parsed.success) for (const issue of parsed.error.issues) next[String(issue.path[0])] = issue.message;
    if (included.size === 0) next["items"] = "Keep at least one answer.";
    setErrors(next);
    if (Object.keys(next).length || !parsed.success) return;
    setBusy(true);
    try {
      const res = await submit({ data: { ...parsed.data, delivery, marketing, items: items.filter((i) => included.has(i.anchorId)).map((i) => ({ anchorId: i.anchorId, question: i.question })) } });
      if (!res.ok) { setErrors({ form: res.message }); return; }
      const bytes = Uint8Array.from(atob(res.pdfBase64), (c) => c.charCodeAt(0));
      const url = URL.createObjectURL(new Blob([bytes], { type: "application/pdf" }));
      const a = document.createElement("a"); a.href = url; a.download = res.fileName; a.click();
      window.setTimeout(() => URL.revokeObjectURL(url), 10_000);
      setDone(delivery === "download" ? "Sent. Your board disappears when you leave, but your copy is on its way."
        : "Your copy downloaded. Email delivery isn't switched on yet, so please keep the downloaded file.");
    } catch {
      setErrors({ form: "Something went wrong. Please try again." });
    } finally { setBusy(false); }
  }

  return (
    <div role="dialog" aria-modal="true" aria-labelledby="lead-title" className="absolute inset-0 z-50 flex items-center justify-center bg-background/80 p-4">
      <form onSubmit={onSubmit} noValidate className="max-h-full w-full max-w-md space-y-4 overflow-y-auto rounded-lg border border-border bg-card p-6 text-card-foreground shadow-xl">
        <div className="flex items-start">
          <h3 id="lead-title" className="mr-auto font-serif text-xl">Take a copy with you</h3>
          <Button type="button" size="icon" variant="ghost" aria-label="Close form" onClick={onClose} className="h-11 w-11"><X aria-hidden="true" /></Button>
        </div>
        {done ? (
          <>
            <p role="status" className="text-foreground">{done}</p>
            <Button type="button" onClick={onClose} autoFocus>Back to my board</Button>
          </>
        ) : (
          <>
            {([["firstName", "First name", true], ["email", "Email", true], ["organization", "Organization (optional)", false]] as const).map(([key, label, req]) => (
              <div key={key} className="space-y-1">
                <Label htmlFor={`lead-${key}`}>{label}</Label>
                <Input id={`lead-${key}`} type={key === "email" ? "email" : "text"} autoFocus={key === "firstName"} required={req} maxLength={key === "email" ? 254 : 120}
                  autoComplete={key === "firstName" ? "given-name" : key === "email" ? "email" : "organization"}
                  aria-invalid={!!errors[key]} aria-describedby={errors[key] ? `lead-${key}-err` : undefined}
                  value={values[key]} onChange={(e) => setValues((v) => ({ ...v, [key]: e.target.value }))} />
                {errors[key] && <p id={`lead-${key}-err`} className="text-sm text-destructive">{errors[key]}</p>}
              </div>
            ))}
            <fieldset className="space-y-2">
              <legend className="text-sm font-medium">How should we deliver it?</legend>
              <RadioGroup value={delivery} onValueChange={(v) => setDelivery(v as Delivery)}>
                {([["download", "Download PDF"], ["email", "Email it to me"], ["both", "Both"]] as const).map(([v, l]) => (
                  <div key={v} className="flex items-center gap-2"><RadioGroupItem id={`d-${v}`} value={v} /><Label htmlFor={`d-${v}`}>{l}</Label></div>
                ))}
              </RadioGroup>
            </fieldset>
            <fieldset className="space-y-2">
              <legend className="text-sm font-medium">Answers to include</legend>
              {items.map((i) => (
                <div key={i.anchorId} className="flex items-center gap-2">
                  <Checkbox id={`inc-${i.anchorId}`} checked={included.has(i.anchorId)} onCheckedChange={(c) => setIncluded((s) => { const n = new Set(s); if (c) n.add(i.anchorId); else n.delete(i.anchorId); return n; })} />
                  <Label htmlFor={`inc-${i.anchorId}`} className="font-normal">{i.title} — {i.label}</Label>
                </div>
              ))}
              {errors["items"] && <p className="text-sm text-destructive">{errors["items"]}</p>}
            </fieldset>
            <div className="flex items-start gap-2">
              <Checkbox id="lead-marketing" checked={marketing} onCheckedChange={(c) => setMarketing(c === true)} />
              <Label htmlFor="lead-marketing" className="font-normal leading-snug">May we contact you about 60 Watts of Clarity services and workshops?</Label>
            </div>
            <p className="text-xs text-muted-foreground">We store your name, email, and the questions you asked so we can send your copy. Data questions: learnai@60wattsofclarity.com</p>
            {errors["form"] && <p role="alert" className="text-sm text-destructive">{errors["form"]}</p>}
            <Button type="submit" disabled={busy} className="w-full">{busy ? "Preparing your copy…" : "Get my copy"}</Button>
          </>
        )}
      </form>
    </div>
  );
}
