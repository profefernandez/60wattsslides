import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import type { Slide } from "@/lib/cms";

type Submission = { id: string; slide_id: string; name: string; email: string; created_at: string; expires_at: string };

export function DocumentSubmissions({ slides }: { slides: Slide[] }) {
  const [search, setSearch] = useState("");
  const { data = [], isLoading, error } = useQuery({ queryKey: ["document-submissions"], queryFn: async () => {
    const { data, error } = await supabase.from("document_submissions")
      .select("id, slide_id, name, email, created_at, expires_at")
      .gt("expires_at", new Date().toISOString()).order("created_at", { ascending: false }).limit(1000);
    if (error) throw error;
    return data as Submission[];
  } });
  const names = useMemo(() => new Map(slides.map((slide) => [slide.id, slide.title])), [slides]);
  const visible = data.filter((row) => row.expires_at > new Date().toISOString() &&
    `${row.name} ${row.email} ${names.get(row.slide_id) ?? ""}`.toLowerCase().includes(search.toLowerCase().trim()));

  function exportCsv() {
    const escaped = (value: string) => `"${(/^[\s\u0000-\u001f]*[=+@\-]/.test(value) ? "'" : "") + value.replaceAll('"', '""')}\"`;
    const rows = [["Name", "Email", "Slide", "Submitted", "Expires"], ...visible.map((row) => [row.name, row.email, names.get(row.slide_id) ?? "Deleted slide", row.created_at, row.expires_at])];
    const blob = new Blob(["\uFEFF", rows.map((row) => row.map(escaped).join(",")).join("\r\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a"); link.href = url; link.download = "document-submissions.csv";
    link.click(); URL.revokeObjectURL(url);
  }

  return <div className="space-y-4">
    <div className="flex items-center justify-between gap-2"><h2 className="font-semibold">Document requests</h2><Button size="sm" variant="outline" disabled={!visible.length} onClick={exportCsv}><Download className="mr-1 h-4 w-4" /> Export CSV</Button></div>
    <Input aria-label="Search document requests" placeholder="Search name, email, or slide" value={search} onChange={(e) => setSearch(e.target.value)} />
    {isLoading && <p className="text-sm text-muted-foreground">Loading requests…</p>}
    {error && <p role="alert" className="text-sm text-destructive">Requests could not be loaded.</p>}
    {!isLoading && !error && !visible.length && <p className="text-sm text-muted-foreground">No matching requests.</p>}
    <ul className="divide-y divide-border">{visible.map((row) => <li key={row.id} className="space-y-1 py-3 text-sm">
      <p className="font-medium">{row.name}</p><p className="break-all text-muted-foreground">{row.email}</p>
      <p className="text-xs text-muted-foreground">{names.get(row.slide_id) ?? "Deleted slide"} · {new Date(row.created_at).toLocaleString()}</p>
      <p className="text-xs text-muted-foreground">Expires {new Date(row.expires_at).toLocaleDateString()}</p>
    </li>)}</ul>
    {data.length === 1000 && <p className="text-xs text-muted-foreground">Showing the newest 1,000 requests.</p>}
  </div>;
}