import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Slide } from "@/lib/cms";

export function WorkshopClicks({ slides }: { slides: Slide[] }) {
  const { data, isLoading } = useQuery({
    queryKey: ["workshop-clicks"],
    queryFn: async () => {
      const { data, error } = await supabase.from("workshop_clicks").select("slide_id, session_title, signup_url").order("created_at", { ascending: false }).limit(5000);
      if (error) throw error;
      return data;
    },
  });
  const titles = new Map(slides.map((s) => [s.id, s.title || "Untitled workshop"]));
  const rows = new Map<string, { slide: string; session: string; url: string; count: number }>();
  for (const c of data ?? []) {
    const key = `${c.slide_id}|${c.session_title}|${c.signup_url}`;
    const row = rows.get(key) ?? { slide: titles.get(c.slide_id) ?? "Deleted slide", session: c.session_title, url: c.signup_url, count: 0 };
    row.count += 1;
    rows.set(key, row);
  }
  const sorted = [...rows.values()].sort((a, b) => b.count - a.count);
  return (
    <section className="space-y-3">
      <h2 className="text-lg font-semibold">Workshop registration clicks</h2>
      {isLoading ? <p className="text-sm text-muted-foreground">Loading…</p> : sorted.length === 0 ? (
        <p className="text-sm text-muted-foreground">No registration clicks yet.</p>
      ) : (
        <div className="overflow-x-auto rounded-md border">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-left"><tr><th className="p-2">Workshop</th><th className="p-2">Session</th><th className="p-2">Signup link</th><th className="p-2 text-right">Clicks</th></tr></thead>
            <tbody>
              {sorted.map((r) => (
                <tr key={`${r.slide}|${r.session}|${r.url}`} className="border-t">
                  <td className="p-2">{r.slide}</td><td className="p-2">{r.session}</td>
                  <td className="max-w-48 truncate p-2 text-muted-foreground" title={r.url}>{r.url}</td>
                  <td className="p-2 text-right font-medium">{r.count}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
