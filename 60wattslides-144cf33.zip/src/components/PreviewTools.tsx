import { useState } from "react";
import { ChevronDown, Crop, Maximize2, Minus, Plus, RotateCcw, Video } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PhotoToolbar } from "@/components/PhotoToolbar";
import { videoBox } from "@/components/VideoFrame";
import type { Slide } from "@/lib/cms";
import { slideBackground } from "@/lib/slide-background";
import { panBy, photoState, zoomAt, type PhotoState } from "@/lib/slide-placement";
import type { TextStyle } from "@/lib/slide-text";

interface PreviewToolsProps {
  slide: Slide;
  onChange: (patch: Partial<TextStyle>) => void;
}

/** Editing tools that live above the CMS preview — never on the slide itself. */
export function PreviewTools({ slide, onChange }: PreviewToolsProps) {
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState("");
  const isVideo = slide.kind === "video" && !!slide.media_url;
  const isPhoto = !!slide.media_url && (slide.kind === "image" || slide.kind === "photo-text" || (slide.kind === "text" && slideBackground(slide) === "image"));
  if (!isVideo && !isPhoto) return null;

  const style = slide.title_style;
  const save = (s: PhotoState) => onChange({ media_zoom: Math.round(s.zoom * 10) / 10, media_x: Math.round(s.x * 10) / 10, media_y: Math.round(s.y * 10) / 10 });
  const vb = videoBox(style);
  const setVideo = (size: number, x = vb.x, y = vb.y) => {
    const next = Math.min(100, Math.max(30, size));
    onChange({ video_size: next, video_x: x, video_y: y });
    setMessage(`Video size ${next}%`);
  };

  return (
    <div className="mx-auto mb-4 w-full max-w-5xl">
      <Button type="button" variant={open ? "secondary" : "outline"} aria-expanded={open} onClick={() => setOpen((v) => !v)} className="h-11 gap-2">
        {isVideo ? <Video aria-hidden /> : <Crop aria-hidden />}
        {isVideo ? "Resize video" : "Photo tools"}
        <ChevronDown aria-hidden className={open ? "rotate-180 transition-transform" : "transition-transform"} />
      </Button>
      {open && (
        <div className="mt-2">
          {isVideo ? (
            <div role="toolbar" aria-label="Video size" className="flex flex-wrap items-center gap-2 rounded-lg border border-border bg-popover p-2 text-popover-foreground shadow-sm">
              <Button type="button" size="sm" variant="outline" className="min-h-11" onClick={() => setVideo(vb.size - 10)}><Minus aria-hidden /> Smaller</Button>
              <span className="min-w-12 text-center text-sm font-semibold tabular-nums">{Math.round(vb.size)}%</span>
              <Button type="button" size="sm" variant="outline" className="min-h-11" onClick={() => setVideo(vb.size + 10)}><Plus aria-hidden /> Bigger</Button>
              <Button type="button" size="sm" variant="outline" className="min-h-11" onClick={() => setVideo(100, 50, 50)}><Maximize2 aria-hidden /> Fill slide</Button>
              <Button type="button" size="sm" variant="outline" className="min-h-11" onClick={() => setVideo(vb.size, 50, 50)}><RotateCcw aria-hidden /> Center</Button>
              <p className="w-full text-xs text-foreground/85">Tip: click the video in the preview, then drag to move, pinch or scroll to resize, or drag its corner.</p>
            </div>
          ) : (
            <PhotoToolbar style={style} zoom={photoState(style).zoom}
              allowShape={slide.kind !== "text"} allowSplit={slide.kind === "photo-text"}
              onZoom={(f) => save(zoomAt(photoState(style), f, 50, 50, 100, 100))}
              onPan={(dx, dy) => save(panBy(photoState(style), dx, dy))}
              onReset={() => { onChange({ media_zoom: 100, media_x: 0, media_y: 0 }); setMessage("Photo centered"); }}
              onPatch={(patch, note) => { onChange(patch); setMessage(note); }} />
          )}
        </div>
      )}
      <span className="sr-only" aria-live="polite">{message}</span>
    </div>
  );
}
