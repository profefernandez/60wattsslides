import { ArrowLeft, BookOpen, Image, MessageCircleQuestion, Play, Plus, Type, Users, Video } from "lucide-react";
import { Button } from "@/components/ui/button";
import { STARTER_LAYOUTS, type StarterLayoutId } from "@/lib/slide-templates";

const icons = {
  hero: Image,
  "photo-message": Type,
  person: Users,
  video: Video,
  workshop: Play,
  faq: MessageCircleQuestion,
  partners: BookOpen,
  text: Type,
} as const;

export function StarterGallery({ empty, onChoose, onOutline, onBack }: {
  empty: boolean;
  onChoose: (layout: StarterLayoutId) => void;
  onOutline: () => void;
  onBack: () => void;
}) {
  return (
    <section aria-label="Choose a slide layout" className="space-y-5">
      {!empty && <Button type="button" variant="ghost" size="sm" onClick={onBack} className="-ml-2"><ArrowLeft className="mr-1 h-4 w-4" /> Back to slide</Button>}
      <div className="rounded-xl border border-[#c7d9ce] bg-[#eef3ee] p-4 text-[#21493c]">
        <p className="text-[11px] font-bold uppercase tracking-[0.16em]">Build on what you already have</p>
        <h2 className="mt-2 font-serif text-xl font-semibold">Choose a starting layout</h2>
        <p className="mt-2 text-sm leading-relaxed">Every new slide includes editable starter text and begins hidden. Replace the example words, add your own photo or video, then turn on Visible when it’s ready.</p>
      </div>
      {empty && <Button type="button" onClick={onOutline} className="h-auto w-full justify-start gap-3 py-4 text-left">
        <Plus className="h-5 w-5 shrink-0" /><span><strong className="block">Create a five-slide starter outline</strong><span className="block text-xs font-normal opacity-80">Introduction, person, message, workshop and FAQ — all ready to edit</span></span>
      </Button>}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        {STARTER_LAYOUTS.map((layout) => {
          const Icon = icons[layout.id];
          return <button key={layout.id} type="button" onClick={() => onChoose(layout.id)} className="group min-h-32 rounded-xl border border-border bg-background p-4 text-left transition-colors hover:border-[#245c4a] hover:bg-[#f2f6f0] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#245c4a]">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-[#e8f0e7] text-[#245c4a]"><Icon className="h-5 w-5" /></span>
            <strong className="mt-3 block text-sm">{layout.label}</strong>
            <span className="mt-1 block text-xs leading-relaxed text-foreground/65">{layout.description}</span>
          </button>;
        })}
      </div>
    </section>
  );
}
