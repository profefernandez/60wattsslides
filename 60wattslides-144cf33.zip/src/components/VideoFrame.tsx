import { useEffect, useRef, useState, type ReactNode } from "react";
import type { TextStyle } from "@/lib/slide-text";
import { cn } from "@/lib/utils";

const MIN = 30;
const MAX = 100;
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

interface VideoBox { size: number; x: number; y: number }

export function videoBox(style: Partial<TextStyle> | null | undefined): VideoBox {
  const n = (v: unknown, d: number) => (typeof v === "number" && Number.isFinite(v) ? v : d);
  return { size: clamp(n(style?.video_size, 100), MIN, MAX), x: clamp(n(style?.video_x, 50), 0, 100), y: clamp(n(style?.video_y, 50), 0, 100) };
}

interface VideoFrameProps {
  style: Partial<TextStyle>;
  children: ReactNode;
  /** Only in the CMS preview. */
  onChange?: ((patch: Partial<TextStyle>) => void) | undefined;
}

export function VideoFrame({ style, children, onChange }: VideoFrameProps) {
  const saved = videoBox(style);
  const [live, setLive] = useState<VideoBox | null>(null);
  const [selected, setSelected] = useState(false);
  const [message, setMessage] = useState("");
  const box = live ?? saved;
  const liveRef = useRef<VideoBox | null>(null);
  const rootRef = useRef<HTMLDivElement>(null);
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const drag = useRef<{ mode: "move" | "resize"; sx: number; sy: number; start: VideoBox; dist: number } | null>(null);
  const wheelTimer = useRef<number | undefined>(undefined);
  const boxRef = useRef(box);
  boxRef.current = box;

  const show = (b: VideoBox) => { liveRef.current = b; setLive(b); };
  const commit = (b: VideoBox | null = liveRef.current) => {
    liveRef.current = null; setLive(null);
    if (!b) return;
    onChange?.({ video_size: Math.round(b.size), video_x: Math.round(b.x * 10) / 10, video_y: Math.round(b.y * 10) / 10 });
    setMessage(`Video size ${Math.round(b.size)}%`);
  };
  const resize = (b: VideoBox, size: number): VideoBox => ({ ...b, size: clamp(size, MIN, MAX) });

  useEffect(() => {
    if (!selected) return;
    const el = rootRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const dy = e.deltaY * (e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? 100 : 1);
      const cur = liveRef.current ?? boxRef.current;
      show(resize(cur, cur.size * Math.exp(-dy * 0.0015)));
      window.clearTimeout(wheelTimer.current);
      wheelTimer.current = window.setTimeout(() => commit(), 200);
    };
    const onOutside = (e: PointerEvent) => { if (!el.contains(e.target as Node)) setSelected(false); };
    el.addEventListener("wheel", onWheel, { passive: false });
    document.addEventListener("pointerdown", onOutside);
    return () => { el.removeEventListener("wheel", onWheel); document.removeEventListener("pointerdown", onOutside); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selected]);

  const full = box.size >= MAX;
  const frameClass = full ? "absolute inset-0" : "absolute aspect-video max-h-full -translate-x-1/2 -translate-y-1/2 overflow-hidden rounded-lg shadow-2xl";
  const frameStyle = full ? undefined : { width: `${box.size}%`, left: `${box.x}%`, top: `${box.y}%` };

  if (!onChange) return <div className={frameClass} style={frameStyle}>{children}</div>;

  const parentRect = () => rootRef.current?.parentElement?.getBoundingClientRect();
  const dist = () => { const p = [...pointers.current.values()]; return p.length < 2 ? 0 : Math.hypot(p[0]!.x - p[1]!.x, p[0]!.y - p[1]!.y); };

  const onDown = (mode: "move" | "resize") => (e: React.PointerEvent) => {
    e.stopPropagation();
    if (!selected) { setSelected(true); return; }
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    drag.current = { mode, sx: e.clientX, sy: e.clientY, start: boxRef.current, dist: dist() };
  };
  const onMove = (e: React.PointerEvent) => {
    const d = drag.current; const rect = parentRect();
    if (!d || !rect || !pointers.current.has(e.pointerId)) return;
    e.stopPropagation();
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointers.current.size >= 2) {
      const now = dist();
      if (d.dist > 0 && now > 0) show(resize(d.start, d.start.size * (now / d.dist)));
      else { d.dist = now; d.start = liveRef.current ?? boxRef.current; }
      return;
    }
    const dx = ((e.clientX - d.sx) / rect.width) * 100;
    const dy = ((e.clientY - d.sy) / rect.height) * 100;
    if (d.mode === "resize") show(resize(d.start, d.start.size + dx * 2));
    else show({ ...d.start, size: d.start.size >= MAX ? 90 : d.start.size, x: clamp(d.start.x + dx, 0, 100), y: clamp(d.start.y + dy, 0, 100) });
  };
  const onUp = (e: React.PointerEvent) => {
    pointers.current.delete(e.pointerId);
    if (pointers.current.size === 0) { drag.current = null; commit(); }
    else if (drag.current) { drag.current.dist = dist(); drag.current.start = liveRef.current ?? boxRef.current; }
  };
  const onKey = (e: React.KeyboardEvent) => {
    const b = boxRef.current; const s = e.shiftKey ? 5 : 1;
    const map: Record<string, () => VideoBox> = {
      ArrowLeft: () => ({ ...b, x: clamp(b.x - s, 0, 100) }), ArrowRight: () => ({ ...b, x: clamp(b.x + s, 0, 100) }),
      ArrowUp: () => ({ ...b, y: clamp(b.y - s, 0, 100) }), ArrowDown: () => ({ ...b, y: clamp(b.y + s, 0, 100) }),
      "+": () => resize(b, b.size + 5), "=": () => resize(b, b.size + 5), "-": () => resize(b, b.size - 5),
      "0": () => ({ size: 100, x: 50, y: 50 }),
    };
    if (e.key === "Escape") { setSelected(false); return; }
    if (e.key === "Enter" && !selected) { setSelected(true); return; }
    const fn = map[e.key];
    if (fn && selected) { e.preventDefault(); e.stopPropagation(); commit(fn()); }
  };

  return (
    <div ref={rootRef} className={frameClass} style={frameStyle} data-video-surface>
      {children}
      {/* Capture layer so the embedded player doesn't swallow gestures in the editor */}
      <div tabIndex={0} role="application" aria-roledescription="video resizer"
        aria-label={selected ? "Video selected: drag to move, pinch or scroll to resize, arrow keys move, plus and minus resize, 0 resets, Escape to finish" : "Video: click or press Enter to resize and move"}
        className={cn("absolute inset-0 z-10 touch-none outline-none", selected ? "cursor-grab ring-2 ring-inset ring-primary active:cursor-grabbing" : "cursor-pointer ring-2 ring-inset ring-primary/40 hover:ring-primary focus-visible:ring-primary")}
        onClick={(e) => e.stopPropagation()}
        onPointerDown={onDown("move")} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp}
        onTouchStart={(e) => e.stopPropagation()} onTouchEnd={(e) => e.stopPropagation()}
        onKeyDown={onKey}
      />
      {selected && (
        <>
          <div aria-hidden className="absolute bottom-1 right-1 z-20 h-6 w-6 cursor-nwse-resize touch-none rounded-sm border-2 border-primary bg-background"
            onPointerDown={onDown("resize")} onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp} />
        </>
      )}
      <span className="sr-only" aria-live="polite">{message}</span>
    </div>
  );
}
