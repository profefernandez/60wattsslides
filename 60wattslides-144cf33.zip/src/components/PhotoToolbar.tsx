import { ArrowDown, ArrowLeft, ArrowRight, ArrowUp, Minus, Plus, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { PHOTO_SHAPES, clamp } from "@/lib/slide-placement";
import { isHexColor, type TextStyle } from "@/lib/slide-text";
import { cn } from "@/lib/utils";

interface PhotoToolbarProps {
  style: Partial<TextStyle>;
  zoom: number;
  allowShape: boolean;
  allowSplit: boolean;
  onZoom: (factor: number) => void;
  onPan: (dx: number, dy: number) => void;
  onReset: () => void;
  onPatch: (patch: Partial<TextStyle>, announce: string) => void;
}

const chip = "min-h-11 px-3 text-xs";

export function PhotoToolbar({ style, zoom, allowShape, allowSplit, onZoom, onPan, onReset, onPatch }: PhotoToolbarProps) {
  const fit = style.media_fit ?? "contain";
  const shape = style.media_shape ?? "full";
  return (
    <div role="toolbar" aria-label="Photo tools" data-photo-toolbar
      className="space-y-2 rounded-lg border border-border bg-popover p-2 text-popover-foreground shadow-sm"
      onPointerDown={(e) => e.stopPropagation()} onTouchStart={(e) => e.stopPropagation()} onWheel={(e) => e.stopPropagation()} onClick={(e) => e.stopPropagation()}>
      <div className="flex flex-wrap items-center gap-1">
        <Button type="button" size="sm" variant="outline" className={chip} onClick={() => onZoom(1 / 1.1)}><Minus aria-hidden /> Zoom out</Button>
        <span className="min-w-12 text-center text-xs font-semibold tabular-nums" aria-hidden>{Math.round(zoom)}%</span>
        <Button type="button" size="sm" variant="outline" className={chip} onClick={() => onZoom(1.1)}><Plus aria-hidden /> Zoom in</Button>
        <Button type="button" size="sm" variant="outline" className={chip} onClick={() => onPan(0, -5)}><ArrowUp aria-hidden /> Pan up</Button>
        <Button type="button" size="sm" variant="outline" className={chip} onClick={() => onPan(0, 5)}><ArrowDown aria-hidden /> Pan down</Button>
        <Button type="button" size="sm" variant="outline" className={chip} onClick={() => onPan(-5, 0)}><ArrowLeft aria-hidden /> Pan left</Button>
        <Button type="button" size="sm" variant="outline" className={chip} onClick={() => onPan(5, 0)}><ArrowRight aria-hidden /> Pan right</Button>
        <Button type="button" size="sm" variant="outline" className={chip} onClick={onReset}><RotateCcw aria-hidden /> Reset</Button>
      </div>
      <div className="flex flex-wrap items-center gap-1" role="group" aria-label="Fit">
        {(["contain", "cover"] as const).map((value) => (
          <Button key={value} type="button" size="sm" variant={fit === value ? "default" : "outline"} aria-pressed={fit === value} className={chip}
            onClick={() => onPatch({ media_fit: value }, value === "contain" ? "Showing whole photo" : "Photo fills the frame")}>
            {value === "contain" ? "Whole photo" : "Fill"}
          </Button>
        ))}
      </div>
      {allowShape && (
        <>
          <div className="flex flex-wrap items-center gap-1" role="group" aria-label="Shape">
            {PHOTO_SHAPES.map((s) => (
              <Button key={s.value} type="button" size="sm" variant={shape === s.value ? "default" : "outline"} aria-pressed={shape === s.value} className={chip}
                onClick={() => onPatch({ media_shape: s.value }, `Shape: ${s.label.toLowerCase()}`)}>{s.label}</Button>
            ))}
          </div>
          {shape === "custom" && (
            <label className="block text-xs font-medium">Corners · {Math.round(clamp(style.media_radius ?? 12, 0, 50))}%
              <Slider aria-label="Photo corner roundness" className="mt-2" min={0} max={50} step={1} value={[clamp(style.media_radius ?? 12, 0, 50)]}
                onValueChange={([v]) => onPatch({ media_radius: v ?? 12 }, `Corners ${v}%`)} />
            </label>
          )}
          <div className="flex flex-wrap items-center gap-1" role="group" aria-label="Border">
            {(["none", "thin", "thick"] as const).map((b) => (
              <Button key={b} type="button" size="sm" variant={(style.media_border ?? "none") === b ? "default" : "outline"} aria-pressed={(style.media_border ?? "none") === b} className={chip}
                onClick={() => onPatch({ media_border: b }, `Border ${b}`)}>{b === "none" ? "No border" : b === "thin" ? "Thin border" : "Thick border"}</Button>
            ))}
            <input type="color" aria-label="Photo border colour wheel" value={isHexColor(style.media_border_color ?? "") ? style.media_border_color : "#ffffff"}
              onChange={(e) => onPatch({ media_border_color: e.target.value.toLowerCase() }, "Border colour changed")}
              className="h-11 w-12 cursor-pointer rounded-md border border-input bg-background p-1" />
            <input aria-label="Photo border hex colour code" maxLength={7} placeholder="#ff8800" defaultValue={style.media_border_color ?? ""}
              onChange={(e) => { const v = e.target.value.trim(); if (isHexColor(v)) onPatch({ media_border_color: v.toLowerCase() }, "Border colour changed"); }}
              className="h-11 w-24 rounded-md border border-input bg-background px-2 font-mono text-xs" />
            <Button type="button" size="sm" variant="ghost" className={chip} onClick={() => onPatch({ media_border_color: "" }, "Border uses theme colour")}>Theme color</Button>
          </div>
          <div className="flex flex-wrap items-center gap-1" role="group" aria-label="Shadow">
            {(["none", "soft", "strong"] as const).map((s) => (
              <Button key={s} type="button" size="sm" variant={(style.media_shadow ?? "none") === s ? "default" : "outline"} aria-pressed={(style.media_shadow ?? "none") === s} className={chip}
                onClick={() => onPatch({ media_shadow: s }, `Shadow ${s}`)}>{s === "none" ? "No shadow" : s === "soft" ? "Soft shadow" : "Strong shadow"}</Button>
            ))}
          </div>
        </>
      )}
      {allowSplit && (
        <label className={cn("block text-xs font-medium")}>Photo width · {Math.round(clamp(style.media_split ?? 48, 30, 70))}%
          <Slider aria-label="Photo width on wide screens" className="mt-2" min={30} max={70} step={1} value={[clamp(style.media_split ?? 48, 30, 70)]}
            onValueChange={([v]) => onPatch({ media_split: v ?? 48 }, `Photo width ${v}%`)} />
        </label>
      )}
    </div>
  );
}
