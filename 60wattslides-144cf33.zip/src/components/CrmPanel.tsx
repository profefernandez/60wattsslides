import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { z } from "zod";
import { FileText, Plus, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { deleteContact, getLeadPdfUrl } from "@/lib/crm.functions";

type Contact = Tables<"crm_contacts">;
const STATUSES = [["new", "New lead"], ["contacted", "Contacted"], ["client", "Client"], ["archived", "Archived"]] as const;
type Status = (typeof STATUSES)[number][0];
const statusLabel = (s: string) => STATUSES.find(([v]) => v === s)?.[1] ?? s;

const contactSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(120),
  email: z.union([z.literal(""), z.string().trim().email("Enter a valid email").max(254)]),
  organization: z.string().trim().max(120),
  phone: z.string().trim().max(40),
  notes: z.string().max(5000),
  status: z.enum(["new", "contacted", "client", "archived"]),
  tags: z.array(z.string().trim().min(1).max(30)).max(20),
});
type Draft = z.infer<typeof contactSchema>;
const empty: Draft = { name: "", email: "", organization: "", phone: "", notes: "", status: "new", tags: [] };

export function CrmPanel() {
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState<"all" | Status>("all");
  const [source, setSource] = useState<"all" | "manual" | "board">("all");
  const [editing, setEditing] = useState<{ id: string | null; draft: Draft } | null>(null);

  const contacts = useQuery({
    queryKey: ["crm-contacts"],
    queryFn: async () => {
      const { data, error } = await supabase.from("crm_contacts").select("*").order("created_at", { ascending: false }).limit(1000);
      if (error) throw error;
      return data;
    },
  });
  const retention = useQuery({
    queryKey: ["lead-retention"],
    queryFn: async () => (await supabase.from("site_settings").select("lead_retention_months").eq("id", 1).single()).data?.lead_retention_months ?? 12,
  });

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return (contacts.data ?? []).filter((c) =>
      (status === "all" || c.status === status) && (source === "all" || c.source === source) &&
      (!q || [c.name, c.email, c.organization, c.phone, c.notes, ...c.tags].some((f) => f.toLowerCase().includes(q))));
  }, [contacts.data, search, status, source]);

  const save = useMutation({
    mutationFn: async ({ id, draft }: { id: string | null; draft: Draft }) => {
      const row = { ...draft, updated_at: new Date().toISOString() };
      const { error } = id ? await supabase.from("crm_contacts").update(row).eq("id", id) : await supabase.from("crm_contacts").insert({ ...row, source: "manual" });
      if (error) throw error;
    },
    onSuccess: () => { toast.success("Contact saved"); setEditing(null); void qc.invalidateQueries({ queryKey: ["crm-contacts"] }); },
    onError: () => toast.error("Couldn't save the contact"),
  });
  const remove = useServerFn(deleteContact);
  const pdfUrl = useServerFn(getLeadPdfUrl);

  async function setRetention(months: number) {
    const v = Math.min(36, Math.max(1, Math.round(months) || 12));
    const { error } = await supabase.from("site_settings").update({ lead_retention_months: v }).eq("id", 1);
    if (error) toast.error("Couldn't save retention"); else { toast.success(`Website leads are kept for ${v} months`); void qc.invalidateQueries({ queryKey: ["lead-retention"] }); }
  }

  return (
    <section aria-labelledby="crm-title" className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <h2 id="crm-title" className="mr-auto text-lg font-semibold">Clients & leads</h2>
        <Button size="sm" onClick={() => setEditing({ id: null, draft: empty })}><Plus aria-hidden="true" /> Add client</Button>
      </div>

      <div className="grid gap-2 sm:grid-cols-[1fr_auto_auto]">
        <Input aria-label="Search contacts" placeholder="Search name, email, tag…" value={search} onChange={(e) => setSearch(e.target.value)} />
        <Select value={status} onValueChange={(v) => setStatus(v as typeof status)}>
          <SelectTrigger aria-label="Filter by status" className="w-36"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="all">All statuses</SelectItem>{STATUSES.map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={source} onValueChange={(v) => setSource(v as typeof source)}>
          <SelectTrigger aria-label="Filter by source" className="w-36"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="all">All sources</SelectItem><SelectItem value="manual">Added by you</SelectItem><SelectItem value="board">Website leads</SelectItem></SelectContent>
        </Select>
      </div>

      <div className="flex flex-wrap items-center gap-2 rounded-md border border-border p-3 text-sm">
        <Label htmlFor="retention">Delete website leads after</Label>
        <Input id="retention" type="number" min={1} max={36} className="w-20" key={retention.data} defaultValue={retention.data ?? 12} onBlur={(e) => { if (Number(e.target.value) !== retention.data) void setRetention(Number(e.target.value)); }} />
        <span>months (1–36). Clients you add yourself are never auto-deleted.</span>
      </div>

      {editing && <ContactForm initial={editing.draft} busy={save.isPending} onCancel={() => setEditing(null)} onSave={(draft) => save.mutate({ id: editing.id, draft })} />}

      {contacts.isLoading ? <p className="text-sm text-muted-foreground">Loading…</p> : filtered.length === 0 ? (
        <p className="text-sm text-muted-foreground">No contacts yet.</p>
      ) : (
        <ul className="space-y-2">
          {filtered.map((c) => <ContactRow key={c.id} contact={c}
            onEdit={() => setEditing({ id: c.id, draft: { name: c.name, email: c.email, organization: c.organization, phone: c.phone, notes: c.notes, status: c.status as Status, tags: c.tags } })}
            onPdf={async () => { const r = await pdfUrl({ data: { id: c.id } }); if (r.url) window.open(r.url, "_blank", "noopener"); else toast.error("No PDF saved for this lead"); }}
            onDelete={async () => { if (!window.confirm(`Delete ${c.name || c.email}? This also deletes their saved PDF.`)) return; try { await remove({ data: { id: c.id } }); toast.success("Contact deleted"); void qc.invalidateQueries({ queryKey: ["crm-contacts"] }); } catch { toast.error("Couldn't delete"); } }}
          />)}
        </ul>
      )}
    </section>
  );
}

function ContactRow({ contact: c, onEdit, onPdf, onDelete }: { contact: Contact; onEdit: () => void; onPdf: () => void; onDelete: () => void }) {
  const [open, setOpen] = useState(false);
  const board = Array.isArray(c.board) ? (c.board as { title?: string; question?: string }[]) : [];
  return (
    <li className="rounded-md border border-border p-3">
      <div className="flex flex-wrap items-center gap-2">
        <button type="button" onClick={() => setOpen((v) => !v)} aria-expanded={open} className="mr-auto text-left">
          <span className="font-medium">{c.name || "(no name)"}</span>
          <span className="block text-xs text-muted-foreground">{[c.email, c.organization].filter(Boolean).join(" · ")}</span>
        </button>
        <Badge variant={c.status === "client" ? "default" : "secondary"}>{statusLabel(c.status)}</Badge>
        {c.source === "board" && <Badge variant="outline">Website lead</Badge>}
        <Button size="sm" variant="outline" onClick={onEdit}>Edit</Button>
        <Button size="icon" variant="ghost" aria-label={`Delete ${c.name}`} onClick={onDelete}><Trash2 aria-hidden="true" /></Button>
      </div>
      {open && (
        <div className="mt-3 space-y-2 text-sm">
          {c.phone && <p>Phone: {c.phone}</p>}
          {c.tags.length > 0 && <p className="flex flex-wrap gap-1">{c.tags.map((t) => <Badge key={t} variant="outline">{t}</Badge>)}</p>}
          {c.notes && <p className="whitespace-pre-line">{c.notes}</p>}
          {c.source === "board" && (
            <>
              <p className="text-muted-foreground">
                Requested {new Date(c.created_at).toLocaleString()} · delivery: {c.delivery} · marketing: {c.marketing_consent ? "yes" : "no"}
                {c.expires_at && ` · auto-deletes ${new Date(c.expires_at).toLocaleDateString()}`}
              </p>
              {board.length > 0 && <ul className="list-disc pl-5">{board.map((b, i) => <li key={i}><span className="font-medium">{b.title}</span>{b.question && ` — asked: “${b.question}”`}</li>)}</ul>}
              {c.pdf_path && <Button size="sm" variant="outline" onClick={onPdf}><FileText aria-hidden="true" /> View their PDF</Button>}
            </>
          )}
        </div>
      )}
    </li>
  );
}

function ContactForm({ initial, busy, onSave, onCancel }: { initial: Draft; busy: boolean; onSave: (d: Draft) => void; onCancel: () => void }) {
  const [d, setD] = useState(initial);
  const [tagText, setTagText] = useState(initial.tags.join(", "));
  const [errors, setErrors] = useState<Record<string, string>>({});
  return (
    <form className="space-y-3 rounded-md border border-primary p-4" onSubmit={(e) => {
      e.preventDefault();
      const parsed = contactSchema.safeParse({ ...d, tags: [...new Set(tagText.split(",").map((t) => t.trim()).filter(Boolean))] });
      if (!parsed.success) { setErrors(Object.fromEntries(parsed.error.issues.map((i) => [String(i.path[0]), i.message]))); return; }
      setErrors({}); onSave(parsed.data);
    }}>
      <div className="grid gap-3 sm:grid-cols-2">
        {(["name", "email", "organization", "phone"] as const).map((k) => (
          <div key={k} className="space-y-1">
            <Label htmlFor={`crm-${k}`} className="capitalize">{k}</Label>
            <Input id={`crm-${k}`} value={d[k]} aria-invalid={!!errors[k]} onChange={(e) => setD({ ...d, [k]: e.target.value })} />
            {errors[k] && <p className="text-sm text-destructive">{errors[k]}</p>}
          </div>
        ))}
        <div className="space-y-1">
          <Label htmlFor="crm-status">Status</Label>
          <Select value={d.status} onValueChange={(v) => setD({ ...d, status: v as Status })}>
            <SelectTrigger id="crm-status"><SelectValue /></SelectTrigger>
            <SelectContent>{STATUSES.map(([v, l]) => <SelectItem key={v} value={v}>{l}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div className="space-y-1">
          <Label htmlFor="crm-tags">Tags (comma separated)</Label>
          <Input id="crm-tags" value={tagText} onChange={(e) => setTagText(e.target.value)} />
        </div>
      </div>
      <div className="space-y-1">
        <Label htmlFor="crm-notes">Notes</Label>
        <Textarea id="crm-notes" rows={4} value={d.notes} onChange={(e) => setD({ ...d, notes: e.target.value })} />
      </div>
      <div className="flex gap-2">
        <Button type="submit" disabled={busy}>{busy ? "Saving…" : "Save"}</Button>
        <Button type="button" variant="ghost" onClick={onCancel}>Cancel</Button>
      </div>
    </form>
  );
}
