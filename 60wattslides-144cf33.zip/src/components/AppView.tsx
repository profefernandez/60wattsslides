import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useWhiteRemoved } from "@/lib/remove-white";
import { useServerFn } from "@tanstack/react-start";
import { CalendarPlus, ChevronLeft, ChevronRight, Download, GraduationCap, Pause, Play, Send, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SlideActionLink } from "@/components/SlideActionLink";
import { trackWorkshopClick } from "@/lib/workshop.functions";
import { anchorId } from "@/lib/slide-map";
import { askGuide, type GuideAnswer, type GuideSource } from "@/lib/guide.functions";
import { requestDocument } from "@/lib/document.functions";
import { calendarLinks, clampAutoplaySeconds, safeSignupUrl, type SiteContent, type Slide } from "@/lib/cms";
import { cn } from "@/lib/utils";
import { screenLayout, textBackingClasses, textStyleClasses, textStyleCss } from "@/lib/slide-text";
import { slideBackground, slideBackgroundClass } from "@/lib/slide-background";
import { clamp, photoSplit, textPlacement } from "@/lib/slide-placement";
import { PhotoEditSurface } from "@/components/PhotoEditSurface";
import { VideoFrame } from "@/components/VideoFrame";
import type { TextStyle } from "@/lib/slide-text";
import { buildSlideMap } from "@/lib/slide-map";
import { AnswerBoard, type BoardItem } from "@/components/AnswerBoard";
import { addEphemeral, advancePast, insertEphemeral, type EphemeralSlide } from "@/lib/ephemeral-slides";
import { actionColorVariables } from "@/lib/slide-actions";
import { annotationDisplay, annotationIcon, annotationMode, annotationShape, annotationStyle, type AnswerTemplate } from "@/lib/annotation";
import { chatIcon, sendIcon, type ChatStyle } from "@/lib/chat-style";
import { youtubeEmbedUrl, youtubeVideoId } from "@/lib/youtube";

interface Highlight { slideId: string; anchorId: string; comment: string; label: string; question?: string; }
interface Cutout { left: number; top: number; width: number; height: number; bubbleLeft: number; bubbleTop: number; }

interface AppViewProps {
  content: SiteContent;
  /** Public workspace provides its own navigation and search controls. */
  minimal?: boolean;
  /** When set (CMS), the carousel jumps to this slide and autoplay pauses. */
  focusIndex?: number | undefined;
  /** CMS can preview hidden slides without making them public. */
  includeHidden?: boolean;
  pauseAutoplay?: boolean;
  onIndexChange?: (i: number) => void;
  /** CMS-only placement mode; live slides never expose editing handles. */
  onTextMove?: ((kind: "title" | "subtitle", x: number, y: number) => void) | undefined;
  /** CMS-only: move a slide button to its own spot on the slide. */
  onActionMove?: ((index: number, x: number, y: number) => void) | undefined;
  onPhotoChange?: ((patch: Partial<TextStyle>) => void) | undefined;
}

const SPOT_HINT = "Press Escape to close, P to keep it open, or square brackets to switch answers.";

export function AppView({ content, minimal = false, focusIndex, includeHidden = false, pauseAutoplay = false, onIndexChange, onTextMove, onActionMove, onPhotoChange }: AppViewProps) {
  const published = useMemo(() => content.slides.filter((s) => includeHidden || s.enabled), [content.slides, includeHidden]);
  const slideMap = useMemo(() => buildSlideMap(content.slides), [content.slides]);
  const [ephemeral, setEphemeral] = useState<EphemeralSlide[]>([]);
  const [collapsed, setCollapsed] = useState<Highlight[]>([]);
  const [board, setBoard] = useState<BoardItem[]>([]);
  const [boardOpen, setBoardOpen] = useState<null | "board" | "form">(null);
  const slides = useMemo(() => insertEphemeral(published, ephemeral), [published, ephemeral]);
  const total = slides.length;
  const [index, setIndex] = useState(0);
  const [interactionPaused, setInteractionPaused] = useState(false);
  const [manualPaused, setManualPaused] = useState(false);
  const [reducedMotion, setReducedMotion] = useState(false);
  const [motionPreferenceReady, setMotionPreferenceReady] = useState(false);
  const [motionOptIn, setMotionOptIn] = useState(false);
  const [announcement, setAnnouncement] = useState("");
  const [temporaryAnnouncement, setTemporaryAnnouncement] = useState("");
  const [spotlight, setSpotlight] = useState<Highlight | null>(null);
  const [highlights, setHighlights] = useState<Highlight[]>([]);
  const [annotations, setAnnotations] = useState(false);
  const [spotlightPaused, setSpotlightPaused] = useState(false);
  const [pending, setPending] = useState<Highlight | null>(null);
  const [aborted, setAborted] = useState<Highlight | null>(null);
  const [pulseId, setPulseId] = useState<string | null>(null);
  const [cutout, setCutout] = useState<Cutout | null>(null);
  const [annotationRects, setAnnotationRects] = useState<{ highlight: Highlight; rect: Cutout }[]>([]);
  const stageRef = useRef<HTMLElement>(null);
  const focusReturnRef = useRef<HTMLElement | null>(null);
  const spotlightFocusRef = useRef<HTMLButtonElement>(null);
  const sliderRef = useRef<HTMLDivElement>(null);
  const sequenceRef = useRef(0);
  const touchX = useRef(0);
  useEffect(() => {
    const preference = window.matchMedia("(prefers-reduced-motion: reduce)");
    const sync = () => { setReducedMotion(preference.matches); setMotionPreferenceReady(true); };
    sync();
    preference.addEventListener("change", sync);
    return () => preference.removeEventListener("change", sync);
  }, []);
  const motionEnabled = motionPreferenceReady && !manualPaused && (!reducedMotion || motionOptIn);
  const dismiss = useCallback((restoreFocus = true) => {
    setSpotlight(null); setCutout(null); setSpotlightPaused(false);
    const destination = focusReturnRef.current;
    focusReturnRef.current = null;
    if (restoreFocus) window.setTimeout(() => {
      const fallback = stageRef.current?.closest(".app-view")?.querySelector<HTMLInputElement>("[data-chat] input");
      const chip = destination?.closest('[aria-label="Earlier answers"]') ? destination : null;
      (chip?.isConnected ? chip : fallback)?.focus();
    }, 50);
  }, []);
  const closeSpotlight = useCallback(() => { dismiss(); setAnnouncement("Answer closed."); }, [dismiss]);
  const toggleSpotlightPause = useCallback(() => {
    setSpotlightPaused((v) => { setAnnouncement(v ? "Answer will close in 8 seconds." : "Answer pinned. It stays open until you close it."); return !v; });
  }, []);
  const cancelSequence = useCallback(() => {
    sequenceRef.current += 1;
    setPending((p) => { if (p) setAborted(p); return null; });
    setPulseId(null);
    dismiss(false);
  }, [dismiss]);

  const go = useCallback(
    (i: number, announce = false) => {
      if (total === 0) return;
      const next = ((i % total) + total) % total;
      const leaving = slides[index];
      if (leaving && "sourceSlideId" in leaving && next > index && next !== index) {
        const remaining = advancePast(ephemeral, leaving.id);
        if (remaining.length !== ephemeral.length) {
          const old = ephemeral.find((item) => item.id === leaving.id);
          if (old && !old.draft) {
            setCollapsed((previous) => [...previous.filter((item) => item.anchorId !== old.anchorId), { slideId: old.sourceSlideId, anchorId: old.anchorId, comment: old.body, label: old.label }]);
            setTemporaryAnnouncement(`Temporary answer ${old.label} auto-collapsed after two forward exits. ${remaining.length} of 2 temporary slides active. Available in Earlier answers.`);
          }
          setEphemeral(remaining);
          const nextId = slides[next]?.id;
          setIndex(insertEphemeral(published, remaining).findIndex((item) => item.id === nextId));
        } else {
          setEphemeral(remaining);
          setIndex(next);
        }
      } else {
        setIndex(next);
      }
      if (spotlight && spotlight.slideId !== slides[next]?.id) {
        dismiss(false);
        requestAnimationFrame(() => stageRef.current?.focus());
      }
      if (announce) setAnnouncement(`Slide ${next + 1} of ${total}: ${slides[next]?.title || "Untitled slide"}`);
      onIndexChange?.(next);
    },
    [total, slides, index, ephemeral, published, spotlight, dismiss, onIndexChange],
  );

  useEffect(() => {
    if (focusIndex !== undefined && focusIndex >= 0 && focusIndex < total) setIndex(focusIndex);
  }, [focusIndex, total]);

  useEffect(() => {
    if (index >= total && total > 0) setIndex(0);
  }, [index, total]);

  const locate = useCallback((h: Highlight): Cutout | null => {
    const stage = stageRef.current;
    const el = Array.from(stage?.querySelectorAll<HTMLElement>("[data-anchor]") ?? [])
      .find((node) => node.dataset['anchor'] === h.anchorId && node.closest("[data-slide-id]")?.getAttribute("data-slide-id") === h.slideId);
    if (!stage || !el || !el.getClientRects().length) return null;
    const r = el.getBoundingClientRect(), p = stage.getBoundingClientRect();
    if (r.width < 1 || r.height < 1 || r.bottom < p.top || r.top > p.bottom) return null;
    const left = Math.max(8, r.left - p.left - 6), top = Math.max(52, r.top - p.top - 6);
    const width = Math.min(r.width + 12, p.width - left - 8), height = Math.min(r.height + 12, p.height - top - 8);
    const bubbleTop = top + height + 12 + 165 < p.height - 95 ? top + height + 12 : Math.max(65, top - 172);
    return { left, top, width, height, bubbleLeft: Math.max(12, Math.min(left, p.width - Math.min(320, p.width - 24) - 12)), bubbleTop };
  }, []);

  useEffect(() => {
    const update = () => {
      setCutout(spotlight ? locate(spotlight) : null);
      setAnnotationRects(annotations ? highlights.filter((h) => h.slideId === slides[index]?.id).map((highlight) => ({ highlight, rect: locate(highlight) })).filter((entry): entry is { highlight: Highlight; rect: Cutout } => entry.rect !== null) : []);
    };
    const frame = requestAnimationFrame(update);
    window.addEventListener("resize", update);
    const stage = stageRef.current;
    stage?.addEventListener("scroll", update, true);
    return () => { cancelAnimationFrame(frame); window.removeEventListener("resize", update); stage?.removeEventListener("scroll", update, true); };
  }, [spotlight, annotations, highlights, slides, index, locate]);

  useEffect(() => {
    if (!spotlight || spotlightPaused) return;
    const timeout = window.setTimeout(dismiss, 8000);
    return () => window.clearTimeout(timeout);
  }, [spotlight, spotlightPaused, dismiss]);

  useEffect(() => {
    if (spotlight && cutout) requestAnimationFrame(() => spotlightFocusRef.current?.focus());
  }, [spotlight, cutout]);

  const recordAnswer = useCallback((h: Highlight) => {
    const source = slideMap.find((entry) => entry.id === h.slideId);
    const text = source?.anchors.find((anchor) => anchor.anchorId === h.anchorId)?.textContent;
    if (!source || !text) return;
    const id = `answer:${h.anchorId}`;
    const next = addEphemeral(ephemeral, { id, sourceSlideId: h.slideId, anchorId: h.anchorId, title: source.title || "Answer", body: text, label: h.label, advances: 0 });
    const evicted = ephemeral.find((item) => !next.some((answer) => answer.id === item.id));
    if (evicted) setCollapsed((previous) => [...previous.filter((item) => item.anchorId !== evicted.anchorId), { slideId: evicted.sourceSlideId, anchorId: evicted.anchorId, comment: evicted.body, label: evicted.label }]);
    setEphemeral(next);
    setBoard((prev) => [...prev.filter((b) => b.anchorId !== h.anchorId), { anchorId: h.anchorId, slideId: h.slideId, label: h.label, title: source.title || "Answer", body: text, question: h.question ?? prev.find((b) => b.anchorId === h.anchorId)?.question ?? "" }].slice(-12));
    setIndex(insertEphemeral(published, next).findIndex((item) => item.id === h.slideId));
    setTemporaryAnnouncement(`${evicted ? `Temporary answer ${evicted.label} evicted to Earlier answers. ` : ""}Temporary answer ${h.label} added after ${source.title || "this slide"}. ${next.length} of 2 temporary slides active.${next.length === 2 ? " Two-slide limit reached." : ""}`);
    setAnnouncement(`${h.comment} ${SPOT_HINT}`);
  }, [slideMap, published, ephemeral]);

  const createDraftSlide = useCallback((result: Extract<GuideAnswer, { action: "create_slide" }>, question: string) => {
    cancelSequence();
    const current = slides[index];
    const sourceSlideId = current && "sourceSlideId" in current ? current.sourceSlideId : current?.id ?? published.at(-1)?.id ?? "end";
    const id = `draft:${crypto.randomUUID()}`;
    const next = addEphemeral(ephemeral, {
      id,
      sourceSlideId,
      anchorId: id,
      title: result.newSlide.title,
      body: result.newSlide.body,
      bullets: result.newSlide.bullets,
      label: result.chipLabel,
      advances: 0,
      draft: true,
    });
    setEphemeral(next);
    setIndex(insertEphemeral(published, next).findIndex((slide) => slide.id === id));
    setAnnouncement("A new, unpublished topic slide was added to this session. It does not contain a verified answer.");
    try {
      window.sessionStorage.setItem("sixty-watts-slide-draft", JSON.stringify({ title: result.newSlide.title, body: result.newSlide.body, bullets: result.newSlide.bullets, question }));
    } catch { /* Browsers may disable session storage. */ }
  }, [cancelSequence, slides, index, published, ephemeral]);

  const startHighlight = useCallback((h: Highlight) => {
    const focused = document.activeElement;
    const returnTo = focused instanceof HTMLElement && !focused.closest("[data-spotlight-bubble]") ? focused : focusReturnRef.current;
    cancelSequence(); setAborted(null); setPending(h); if (!reducedMotion) setPulseId(h.slideId);
    focusReturnRef.current = returnTo;
    const sequence = sequenceRef.current;
    const target = slides.findIndex((s) => s.id === h.slideId);
    if (target < 0) { setPending(null); setPulseId(null); return; }
    const where = `slide ${target + 1} of ${slides.length}: ${slides[target]?.title || "Untitled slide"}`;
    if (!reducedMotion) setAnnouncement(`Answer found. Moving to ${where}.`);
    window.setTimeout(() => {
      if (sequenceRef.current !== sequence) return;
      setPulseId(null);
      go(target, true);
      // Wait for the slide's actual transition; reduced-motion has no transition.
      if (reducedMotion) {
        setPending(null); setSpotlight(h); setHighlights((prev) => [...prev.filter((v) => v.anchorId !== h.anchorId), h]);
        recordAnswer(h);
      }
    }, reducedMotion ? 0 : 500);
  }, [cancelSequence, slides, go, reducedMotion, recordAnswer]);

  const finishNavigation = useCallback(() => {
    if (!pending || slides[index]?.id !== pending.slideId) return;
    setPending(null); setSpotlight(pending);
    setHighlights((prev) => [...prev.filter((v) => v.anchorId !== pending.anchorId), pending]);
    recordAnswer(pending);
  }, [pending, slides, index, recordAnswer]);

  useEffect(() => {
    if (!pending || reducedMotion || pulseId || slides[index]?.id !== pending.slideId) return;
    // Same-slide results do not generate a transform transition.
    const timer = window.setTimeout(finishNavigation, 700);
    return () => window.clearTimeout(timer);
  }, [pending, reducedMotion, pulseId, slides, index, finishNavigation]);

  const stepHighlight = useCallback((dir: 1 | -1) => {
    if (highlights.length === 0) { setAnnouncement("No highlighted answers yet."); return; }
    const cur = spotlight ? highlights.findIndex((h) => h.anchorId === spotlight.anchorId) : -1;
    const next = cur < 0 ? (dir > 0 ? 0 : highlights.length - 1) : (cur + dir + highlights.length) % highlights.length;
    const h = highlights[next];
    if (h) { setAnnotations(false); startHighlight(h); }
  }, [highlights, spotlight, startHighlight]);

  const insideCutout = (x?: number, y?: number) => {
    const p = stageRef.current?.getBoundingClientRect();
    if (!cutout || !p || x === undefined || y === undefined) return false;
    const lx = x - p.left, ly = y - p.top;
    return lx >= cutout.left && lx <= cutout.left + cutout.width && ly >= cutout.top && ly <= cutout.top + cutout.height;
  };

  const autoplay = !pauseAutoplay && !spotlight && !pending && !(slides[index] && "sourceSlideId" in slides[index]) && focusIndex === undefined && motionEnabled && !interactionPaused && total > 1;
  useEffect(() => {
    if (!autoplay) return;
    const t = setInterval(() => go(index + 1), clampAutoplaySeconds(content.settings.autoplay_seconds) * 1000);
    return () => clearInterval(t);
  }, [autoplay, index, go, content.settings.autoplay_seconds]);

  const mode = annotationMode(content.settings.annotation_mode);
  const annotationVisible = mode === "always" || (mode === "after_search" && highlights.length > 0);
  const display = annotationDisplay(content.settings.annotation_display);
  const annotationShowsIcon = display !== "text";
  const annotationShowsText = display !== "icon";
  const annotationText = content.settings.annotation_label || "Annotations";
  const annotationAppearance = annotationStyle(content.settings.annotation_style);
  const annotationButtonShape = annotationShape(content.settings.annotation_shape);
  const AnnotationIcon = annotationIcon(content.settings.annotation_icon);
  const template = content.settings.answer_template;


  return (
    <div className="app-view @container dark relative h-full w-full overflow-hidden bg-background text-foreground antialiased"
      onKeyDown={(e) => {
        if (e.altKey || e.ctrlKey || e.metaKey) return;
        if (e.key === "Escape" && (spotlight || pending || annotations)) { e.preventDefault(); if (spotlight) closeSpotlight(); else cancelSequence(); setAborted(null); setAnnotations(false); return; }
        const target = e.target;
        if (target instanceof HTMLElement && (target.closest("input, textarea, select, [contenteditable='true'], [role='textbox']") || target.closest("[data-chat], [data-document]"))) return;
        if (e.key === "]") { e.preventDefault(); stepHighlight(1); return; }
        if (e.key === "[") { e.preventDefault(); stepHighlight(-1); return; }
        if ((e.key === "p" || e.key === "P") && spotlight) { e.preventDefault(); toggleSpotlightPause(); return; }
        if (e.shiftKey || total < 2) return;
        if (e.key === "Escape") { cancelSequence(); setAborted(null); return; }
        if (e.key === "ArrowLeft") { e.preventDefault(); cancelSequence(); go(index - 1, true); }
        else if (e.key === "ArrowRight") { e.preventDefault(); cancelSequence(); go(index + 1, true); }
        else if (e.key === "Home") { e.preventDefault(); cancelSequence(); go(0, true); }
        else if (e.key === "End") { e.preventDefault(); cancelSequence(); go(total - 1, true); }
      }}
    >
      <a href="#carousel-main" className="sr-only focus:not-sr-only absolute left-4 top-4 z-50 rounded-md bg-background px-4 py-3 text-foreground shadow-lg focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-foreground">Skip to main content</a>
      <div className="sr-only" role="status" aria-live="polite" aria-atomic="true">{announcement}</div>
      <div className="sr-only" role="status" aria-live="polite" aria-atomic="true">{temporaryAnnouncement}</div>
      <main
        id="carousel-main" ref={stageRef}
        tabIndex={-1}
        aria-label="Carousel"
        className="absolute inset-0 z-0"
        onTouchStart={(e) => {
          touchX.current = e.changedTouches[0]?.screenX ?? 0;
          setInteractionPaused(true);
        }}
        onTouchEnd={(e) => {
          const d = touchX.current - (e.changedTouches[0]?.screenX ?? touchX.current);
          if (Math.abs(d) > 50) { cancelSequence(); go(index + (d > 0 ? 1 : -1), true); }
          else if (spotlight && !insideCutout(e.changedTouches[0]?.clientX, e.changedTouches[0]?.clientY)) closeSpotlight();
          setInteractionPaused(false);
        }}
        onPointerDown={(e) => { if (spotlight && e.pointerType === "mouse" && !(e.target as HTMLElement).closest("[data-spotlight-bubble]") && !insideCutout(e.clientX, e.clientY)) closeSpotlight(); }}
      >
        <div
          ref={sliderRef}
          onTransitionEnd={(e) => { if (e.target === sliderRef.current && e.propertyName === "transform") finishNavigation(); }}
          className="flex h-full transition-transform duration-600 ease-[cubic-bezier(0.25,1,0.5,1)] will-change-transform motion-reduce:transition-none"
          style={{ transform: `translateX(-${index * 100}%)` }}
        >
          {slides.map((s, i) => (
            "sourceSlideId" in s
              ? <EphemeralView key={s.id} answer={s} active={i === index} template={template} onDismiss={() => {
                  if (!s.draft) setCollapsed((previous) => [...previous.filter((item) => item.anchorId !== s.anchorId), { slideId: s.sourceSlideId, anchorId: s.anchorId, comment: s.body, label: s.label }]);
                  setEphemeral((previous) => previous.filter((answer) => answer.id !== s.id));
                  setIndex(Math.max(0, i - 1));
                  setAnnouncement(s.draft ? "Unpublished draft closed. Returned to the slideshow." : "Temporary answer closed. Returned to its source slide.");
                  if (!s.draft) setTemporaryAnnouncement(`Temporary answer ${s.label} closed. ${Math.max(0, ephemeral.length - 1)} of 2 temporary slides active. Available in Earlier answers.`);
                  requestAnimationFrame(() => stageRef.current?.focus());
                }} />
               : <SlideView key={s.id} slide={s} active={i === index} playMedia={motionEnabled && !interactionPaused && !spotlight} onPause={setInteractionPaused} onTextMove={i === index ? onTextMove : undefined} onActionMove={i === index ? onActionMove : undefined} onPhotoChange={i === index ? onPhotoChange : undefined} />
          ))}
          {total === 0 && (
            <div className="flex h-full w-full items-center justify-center text-muted-foreground">No slides yet</div>
          )}
        </div>
        {spotlight && cutout && !annotations && (
          <div data-spotlight className="pointer-events-none absolute inset-0 z-10" aria-label="Highlighted answer">
            <div className="absolute rounded-md border-2 border-primary shadow-[0_0_22px_var(--primary)] transition-all duration-200 motion-reduce:transition-none"
              style={{ left: cutout.left, top: cutout.top, width: cutout.width, height: cutout.height, boxShadow: "0 0 0 9999px color-mix(in oklch, var(--background) 72%, transparent), 0 0 24px var(--primary)" }} />
            <div data-spotlight-bubble role="region" aria-label="Answer controls" className="pointer-events-auto absolute max-h-52 w-[min(20rem,calc(100%-1.5rem))] overflow-y-auto rounded-md border border-primary bg-background p-3 text-sm text-foreground shadow-lg"
              style={{ left: cutout.bubbleLeft, top: cutout.bubbleTop }}>
              <p className="mb-1 text-xs font-semibold text-primary">Slide {index + 1} of {total}{slides[index]?.title ? ` · ${slides[index]?.title}` : ""}</p>
              <p>{spotlight.comment}</p>
              <div className="mt-2 flex flex-wrap items-center gap-1">
                {highlights.length > 1 && <Button type="button" variant="ghost" size="sm" onClick={() => stepHighlight(-1)} aria-label="Previous highlighted answer" aria-keyshortcuts="[" className="h-11 px-2"><ChevronLeft className="size-4" /></Button>}
                <Button ref={spotlightFocusRef} type="button" variant="outline" size="sm" onClick={toggleSpotlightPause} aria-pressed={spotlightPaused} aria-keyshortcuts="P" className="h-11">
                  {spotlightPaused ? <><Play className="size-4" />Resume</> : <><Pause className="size-4" />Keep open</>}
                </Button>
                <Button type="button" variant="outline" size="sm" onClick={closeSpotlight} aria-keyshortcuts="Escape" className="h-11"><X className="size-4" />Close</Button>
                {highlights.length > 1 && <Button type="button" variant="ghost" size="sm" onClick={() => stepHighlight(1)} aria-label="Next highlighted answer" aria-keyshortcuts="]" className="h-11 px-2"><ChevronRight className="size-4" /></Button>}
              </div>
              <p className="mt-1 text-xs text-muted-foreground" aria-hidden="true">{spotlightPaused ? "Pinned" : "Closes in 8s"} · Esc close · P pin · [ ] switch</p>
            </div>
          </div>
        )}
        {annotations && annotationRects.map(({ highlight, rect }) => (
          <div key={highlight.anchorId} className="pointer-events-none absolute z-10 rounded-md border-2 border-primary shadow-[0_0_18px_var(--primary)]" style={{ left: rect.left, top: rect.top, width: rect.width, height: rect.height }}>
            <Button type="button" variant="outline" aria-label={`Show answer: ${highlight.label}`} onClick={() => { setSpotlight(highlight); setAnnotations(false); }}
              className="pointer-events-auto absolute top-full left-0 mt-2 h-auto max-h-20 max-w-64 whitespace-normal border-primary bg-background px-3 py-2 text-left text-xs text-foreground shadow-lg">{highlight.comment}</Button>
          </div>
        ))}
      </main>

      {!minimal && total > 1 && (
        <>
          <nav aria-label="Story slides" className="absolute inset-x-0 top-0 z-20 flex gap-1 px-3 pt-2 @3xl:px-6">
            {slides.map((s, i) => (
              <Button key={s.id} type="button" variant="ghost" aria-label={`Go to slide ${i + 1} of ${total}: ${s.title || "Untitled slide"}`}
                aria-current={i === index ? "step" : undefined} title={s.title || `Slide ${i + 1}`}
                onClick={() => { cancelSequence(); go(i, true); }} className="group relative h-11 min-w-0 flex-1 rounded-sm px-0 pt-0 pb-6 hover:bg-transparent focus-visible:bg-background/70">
                <span aria-hidden="true" className={cn("relative block h-1 w-full overflow-hidden rounded-full bg-foreground/40 shadow-sm", "sourceSlideId" in s && "border border-dashed border-primary bg-primary/20")}>
                  <span key={`${s.id}-${i === index ? "active" : "inactive"}`} className={cn("block h-full origin-left bg-foreground", i < index || (i === index && reducedMotion) ? "w-full" : i === index && autoplay ? "w-full animate-story-progress" : i === index ? "w-1/3" : "w-0", pulseId === s.id && "w-full animate-guide-pulse bg-primary")}
                    style={i === index && autoplay && !reducedMotion ? { animationDuration: `${clampAutoplaySeconds(content.settings.autoplay_seconds)}s` } : undefined} />
                </span>
              </Button>
            ))}
          </nav>
          <div className="pointer-events-none absolute inset-x-0 top-16 bottom-32 z-10 flex justify-between">
            <Button type="button" variant="ghost" aria-label="Previous slide" title="Previous slide" onClick={() => { cancelSequence(); go(index - 1, true); }}
              className="group pointer-events-auto h-full w-[16%] max-w-20 min-w-11 justify-start rounded-none bg-transparent px-1 hover:bg-transparent focus-visible:bg-transparent">
              <span aria-hidden="true" className="flex h-11 w-5 items-center justify-center rounded-full bg-background/45 text-foreground/75 shadow-sm transition-colors group-hover:bg-background/85 group-hover:text-foreground group-focus-visible:bg-background group-focus-visible:text-foreground motion-reduce:transition-none"><ChevronLeft className="size-4" /></span>
            </Button>
            <Button type="button" variant="ghost" aria-label="Next slide" title="Next slide" onClick={() => { cancelSequence(); go(index + 1, true); }}
              className="group pointer-events-auto h-full w-[16%] max-w-20 min-w-11 justify-end rounded-none bg-transparent px-1 hover:bg-transparent focus-visible:bg-transparent">
              <span aria-hidden="true" className="flex h-11 w-5 items-center justify-center rounded-full bg-background/45 text-foreground/75 shadow-sm transition-colors group-hover:bg-background/85 group-hover:text-foreground group-focus-visible:bg-background group-focus-visible:text-foreground motion-reduce:transition-none"><ChevronRight className="size-4" /></span>
            </Button>
          </div>
        </>
      )}

      {!minimal && annotationVisible && (
        <div className="absolute left-4 top-14 z-20">
          <button type="button" aria-pressed={annotations} aria-label={`${annotationText || "Annotations"}${highlights.length > 0 ? `, ${highlights.length} saved` : ""}`} title={annotationText || "Annotations"}
            onClick={() => { dismiss(); setAnnotations((value) => !value); }}
            className={cn("slide-action inline-flex min-h-11 items-center justify-center gap-2 px-4 py-2 font-semibold transition-colors focus-visible:outline-2 focus-visible:outline-offset-2",
              `slide-action--${annotationAppearance}`, `slide-action-shape--${annotationButtonShape}`, annotationShowsText ? "min-w-28" : "w-11 px-0")}
            style={actionColorVariables({ label: "", url: "", style: annotationAppearance, color: content.settings.annotation_color })}>
            <AnnotationIcon aria-hidden="true" className={cn("size-5 shrink-0", !annotationShowsIcon && "hidden")} />
            {annotationShowsText && <span>{annotationText}{highlights.length > 0 ? ` (${highlights.length})` : ""}</span>}
          </button>
        </div>
      )}

      {!minimal && <Button type="button" variant="outline" size="icon" aria-label={motionEnabled ? "Pause carousel and media" : "Play carousel and media"} aria-pressed={!motionEnabled}
        title={motionEnabled ? "Pause carousel and media" : "Play carousel and media"}
        onClick={() => {
          if (motionEnabled) setManualPaused(true);
          else { setManualPaused(false); setMotionOptIn(true); setInteractionPaused(false); cancelSequence(); }
        }}
        className="absolute right-4 top-14 z-20 h-11 w-11 rounded-full border-foreground/50 bg-background/80 text-foreground hover:bg-background focus-visible:ring-2 focus-visible:ring-foreground"
      >
        {motionEnabled ? <Pause aria-hidden="true" /> : <Play aria-hidden="true" />}
      </Button>}

      {!minimal && <ChatDock
        placeholder={content.settings.chat_placeholder}
        chatStyle={content.settings.chat_style}
        onActive={() => setInteractionPaused(true)}
        onInactive={() => setInteractionPaused(false)}
        deckState={{ slideIds: slides.map((s) => s.id), visibleSlideId: slides[index]?.id ?? null }}
        onHighlight={startHighlight}
        onCreateSlide={createDraftSlide}
        aborted={aborted} abortedTitle={slides.find((s) => s.id === aborted?.slideId)?.title || "slide"} onResume={() => { if (aborted) startHighlight(aborted); }}
        collapsed={collapsed} onReopen={startHighlight}
        boardCount={board.length} onOpenBoard={() => { setInteractionPaused(true); setBoardOpen("board"); }} onLeadForm={() => { setInteractionPaused(true); setBoardOpen("form"); }}
      />}
      {!minimal && boardOpen && <AnswerBoard items={board} formOnOpen={boardOpen === "form"} onClose={() => { setBoardOpen(null); setInteractionPaused(false); requestAnimationFrame(() => stageRef.current?.closest(".app-view")?.querySelector<HTMLInputElement>("[data-chat] input")?.focus()); }} onRemove={(id) => setBoard((b) => b.filter((x) => x.anchorId !== id))} />}
    </div>
  );
}

function EphemeralView({ answer, active, template, onDismiss }: { answer: EphemeralSlide; active: boolean; template: AnswerTemplate; onDismiss: () => void }) {
  const [expanded, setExpanded] = useState(false);
  if (answer.draft) return (
    <section data-slide-id={answer.id} aria-hidden={!active} inert={!active} aria-label={`Unpublished draft: ${answer.title}`}
      className="relative flex h-full w-full shrink-0 grow-0 basis-full flex-col justify-center overflow-y-auto bg-[#163f35] px-8 py-28 text-white @md:px-20">
      <div className="mx-auto w-full max-w-3xl">
        <p className="mb-6 text-xs font-bold uppercase tracking-[0.2em] text-[#e8be69]">New topic slide · Not published</p>
        <div className="mb-6 flex items-start justify-between gap-4">
          <h2 className="max-w-2xl text-3xl font-semibold leading-tight @md:text-5xl">{answer.title}</h2>
          <Button type="button" size="icon" variant="outline" aria-label="Dismiss unpublished draft" onClick={onDismiss} className="h-11 w-11 shrink-0 border-white/70 bg-white/10 text-white hover:bg-white/20"><X className="size-5" /></Button>
        </div>
        <p className="max-w-2xl text-base leading-relaxed text-white/90 @md:text-xl">{answer.body}</p>
        {answer.bullets && <ul className="mt-6 list-disc space-y-2 pl-5 text-sm text-white/80 @md:text-base">{answer.bullets.map((bullet) => <li key={bullet}>{bullet}</li>)}</ul>}
        <p className="mt-8 border-t border-white/30 pt-4 text-xs text-white/70">This question is not answered by the current presentation. Review and verify new content before publishing.</p>
      </div>
    </section>
  );
  const accent = template.accent ? { color: template.accent } : undefined;
  const surface = template.accent
    ? { borderColor: template.accent, ...(template.background === "tint" ? { backgroundColor: `${template.accent}1a` } : {}) }
    : undefined;
  const heading = template.heading || "Answered for you";
  return (
    <section data-slide-id={answer.id} aria-hidden={!active} inert={!active} aria-label={`${heading}: ${answer.title}`}
      className={cn("relative flex h-full w-full shrink-0 grow-0 basis-full flex-col justify-center overflow-y-auto px-8 py-24 text-foreground motion-safe:animate-fade-in-up @md:px-16",
        template.font === "serif" ? "font-serif" : template.font === "mono" ? "font-mono" : "font-sans",
        template.border === "none" ? "border-0" : template.border === "solid" ? "border border-solid border-primary" : "border border-dashed border-primary",
        template.background === "tint" ? "bg-primary/10" : template.background === "solid" ? "bg-card" : "bg-background")}
      style={surface}>
      <div className="mx-auto w-full max-w-3xl">
        {heading && <p className="mb-5 text-sm font-semibold uppercase text-primary" style={accent}>{heading}</p>}
        <div className="mb-5 flex flex-col-reverse items-start gap-4 @md:flex-row @md:justify-between">
          <h2 className="text-3xl font-semibold @md:text-5xl">{answer.title}</h2>
          <Button type="button" size="icon" variant="outline" aria-label="Dismiss temporary answer" onClick={onDismiss} className="h-11 w-11 shrink-0 self-center border-primary @md:self-auto"><X className="size-5" /></Button>
        </div>
        <p className={cn("whitespace-pre-line text-lg leading-relaxed @md:text-2xl", !expanded && "line-clamp-4")}>{answer.body}</p>
        {answer.body.length > 180 && <Button type="button" variant="ghost" aria-expanded={expanded} onClick={() => setExpanded(!expanded)} className="mt-4 px-0 text-primary" style={accent}>{expanded ? "Read less" : "Read more"}</Button>}
      </div>
    </section>
  );
}

function Overlay({ opacity }: { opacity: number }) {
  return <div className="pointer-events-none absolute inset-0 bg-background" style={{ opacity: opacity / 100 }} />;
}

function SlideView({ slide, active, playMedia, onPause, onTextMove, onActionMove, onPhotoChange }: { slide: Slide; active: boolean; playMedia: boolean; onPause: (p: boolean) => void; onTextMove?: AppViewProps["onTextMove"]; onActionMove?: AppViewProps["onActionMove"]; onPhotoChange?: AppViewProps["onPhotoChange"] }) {
  return (
    <div className="relative h-full w-full shrink-0 grow-0 basis-full" aria-hidden={!active} inert={!active}>
       <SlideFront slide={slide} active={active} playMedia={playMedia} onPause={onPause} onTextMove={onTextMove} onActionMove={onActionMove} onPhotoChange={onPhotoChange} />
    </div>
  );
}

type DragTarget = { type: "text"; kind: "title" | "subtitle" } | { type: "action"; index: number };

function SlideFront({ slide, active, playMedia, onPause, onTextMove, onActionMove, onPhotoChange }: { slide: Slide; active: boolean; playMedia: boolean; onPause: (p: boolean) => void; onTextMove?: AppViewProps["onTextMove"]; onActionMove?: AppViewProps["onActionMove"]; onPhotoChange?: AppViewProps["onPhotoChange"] }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const drag = useRef<{ target: DragTarget; pointerId: number; startX: number; startY: number; x: number; y: number } | null>(null);
  const slideRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const elements = slideRef.current?.querySelectorAll<HTMLElement>('[data-anchor]');
    elements?.forEach((element) => {
      if (element.dataset['anchor'] !== anchorId(slide.id, "title") && element.dataset['anchor'] !== anchorId(slide.id, "subtitle")) return;
      if (onTextMove) { element.tabIndex = 0; element.classList.add("slide-text-draggable"); element.setAttribute("aria-label", `${element.dataset['anchor'] === anchorId(slide.id, "title") ? "Heading" : "Subtitle"}: drag to move, or use arrow keys`); }
      else { element.removeAttribute("tabindex"); element.removeAttribute("aria-label"); element.classList.remove("slide-text-draggable"); }
    });
  }, [onTextMove, slide.id, slide.kind, slide.subtitle]);
  const textKind = (element: Element | null): "title" | "subtitle" | null => {
    const id = element?.closest<HTMLElement>("[data-anchor]")?.dataset['anchor'];
    return id === anchorId(slide.id, "title") ? "title" : id === anchorId(slide.id, "subtitle") ? "subtitle" : null;
  };
  const actions = (slide.title_style?.actions ?? []).slice(0, 2).map((action, index) => ({ ...action, label: action.label?.trim() ?? "", url: safeSignupUrl(action.url), index })).filter((action) => action.label && action.url);
  const dragTarget = (element: Element | null): DragTarget | null => {
    if (onActionMove) {
      const holder = element?.closest<HTMLElement>("[data-action-index]");
      const index = holder ? Number(holder.dataset['actionIndex']) : Number.NaN;
      if (Number.isFinite(index)) return { type: "action", index };
    }
    if (!onTextMove) return null;
    const kind = textKind(element);
    return kind ? { type: "text", kind } : null;
  };
  const targetOffset = (target: DragTarget): { x: number; y: number } => {
    if (target.type === "action") {
      const action = (slide.title_style?.actions ?? [])[target.index];
      return { x: action?.x ?? 0, y: action?.y ?? 0 };
    }
    const style = target.kind === "title" ? slide.title_style : slide.subtitle_style;
    return { x: style.offset_x ?? 0, y: style.offset_y ?? 0 };
  };
  const applyOffset = (target: DragTarget, x: number, y: number) => {
    if (target.type === "action") onActionMove?.(target.index, x, y);
    else onTextMove?.(target.kind, x, y);
  };
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    if (active && playMedia) void video.play().catch(() => {});
    else video.pause();
  }, [active, playMedia]);
  return (
    <div ref={slideRef} data-slide-id={slide.id} className="relative h-full w-full overflow-hidden [container-type:size]"
      onTouchStart={(event) => { if (dragTarget(event.target as Element)) event.stopPropagation(); }}
      onTouchEnd={(event) => { if (dragTarget(event.target as Element)) event.stopPropagation(); }}
      onPointerDown={(event) => {
        const target = dragTarget(event.target as Element);
        if (!target) return;
        const offset = targetOffset(target);
        drag.current = { target, pointerId: event.pointerId, startX: event.clientX, startY: event.clientY, ...offset };
        slideRef.current?.setPointerCapture(event.pointerId);
        event.preventDefault(); event.stopPropagation();
      }}
      onPointerMove={(event) => {
        const start = drag.current;
        const rect = slideRef.current?.getBoundingClientRect();
        if (!start || start.pointerId !== event.pointerId || !rect) return;
        applyOffset(start.target, clamp(start.x + (event.clientX - start.startX) / rect.width * 100, -70, 70), clamp(start.y + (event.clientY - start.startY) / rect.height * 100, -70, 70));
        event.stopPropagation();
      }}
      onPointerUp={(event) => { if (drag.current?.pointerId === event.pointerId) drag.current = null; }}
      onPointerCancel={() => { drag.current = null; }}
      onKeyDown={(event) => {
        if (!["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(event.key)) return;
        const target = dragTarget(event.target as Element);
        if (!target) return;
        event.preventDefault(); event.stopPropagation();
        const offset = targetOffset(target);
        const step = event.shiftKey ? 5 : 1;
        applyOffset(target, clamp(offset.x + (event.key === "ArrowRight" ? step : event.key === "ArrowLeft" ? -step : 0), -70, 70), clamp(offset.y + (event.key === "ArrowDown" ? step : event.key === "ArrowUp" ? -step : 0), -70, 70));
      }}>
      {slide.kind === "image" && slide.media_url && (
          <PhotoEditSurface src={slide.media_url} alt={slide.media_alt || ""} style={slide.title_style} defaultFit="contain" allowShape onPhotoChange={onPhotoChange} />
      )}
       {slide.kind === "photo-text" && (
         <div className="absolute inset-0 grid grid-rows-[minmax(0,var(--photo-rows))_minmax(0,1fr)] bg-background @xl:grid-cols-[minmax(0,var(--photo-split))_minmax(0,1fr)] @xl:grid-rows-1" style={photoSplit(slide.title_style)}>
           <div className="relative min-h-0 min-w-0 overflow-hidden [container-type:size] border-b border-border bg-muted @xl:border-r @xl:border-b-0">
             {slide.media_url && <PhotoEditSurface src={slide.media_url} alt={slide.media_alt || ""} style={slide.title_style} defaultFit="contain" allowShape allowSplit onPhotoChange={onPhotoChange} />}
           </div>
           <div className="relative min-h-0 min-w-0 overflow-y-auto bg-background px-7 pt-8 pb-44 @xl:flex @xl:flex-col @xl:justify-center @xl:px-12 @xl:pt-20 @xl:pb-52">
             <h2 data-anchor={anchorId(slide.id, "title")} className={cn("mb-4 max-w-full", textStyleClasses(slide.title_style, "title"))} style={{ ...textStyleCss(slide.title_style, "title"), ...textPlacement(slide.title_style) }}><span className={textBackingClasses(slide.title_style, "title")}>{slide.title}</span></h2>
             {slide.subtitle && <p data-anchor={anchorId(slide.id, "subtitle")} className={cn("max-w-full whitespace-pre-line", textStyleClasses(slide.subtitle_style, "subtitle"))} style={{ ...textStyleCss(slide.subtitle_style, "subtitle"), ...textPlacement(slide.subtitle_style) }}><span className={textBackingClasses(slide.subtitle_style, "subtitle")}>{slide.subtitle}</span></p>}
           </div>
         </div>
       )}
      {slide.kind === "video" && slide.media_url && (
        <VideoFrame style={slide.title_style} onChange={onPhotoChange}>
        {youtubeVideoId(slide.media_url) ? (
          <iframe
            key={`${slide.id}-${active && playMedia ? "play" : "pause"}`}
            src={youtubeEmbedUrl(youtubeVideoId(slide.media_url)!, { autoplay: active && playMedia })}
            title={slide.media_alt || slide.title || "YouTube video"}
            className="h-full w-full border-0"
            allow="autoplay; encrypted-media; picture-in-picture"
            allowFullScreen
          />
        ) : (
          <video ref={videoRef} src={slide.media_url} className="h-full w-full object-cover" muted loop playsInline />
        )}
        </VideoFrame>
      )}
      {slide.kind === "list" && <div className="absolute inset-0 bg-hero-gradient" />}
      {(slide.kind === "document" || slide.kind === "faq" || slide.kind === "workshop" || slide.kind === "logos") && <div className="absolute inset-0 bg-hero-gradient" />}
      {slide.kind === "text" && (slideBackground(slide) === "image" && slide.media_url
        ? <><PhotoEditSurface src={slide.media_url} alt={slide.media_alt || ""} style={slide.title_style} defaultFit="cover" onPhotoChange={onPhotoChange} /><Overlay opacity={slide.overlay_opacity} /></>
        : <div className={cn("absolute inset-0", slideBackgroundClass(slide))} />)}
      {(slide.kind === "image" || slide.kind === "video") && <Overlay opacity={slide.overlay_opacity} />}

      {slide.kind === "list" ? (
         <ListSlide slide={slide} active={active} onPause={onPause} />
      ) : slide.kind === "faq" ? (
         <FaqSlide slide={slide} active={active} />
      ) : slide.kind === "logos" ? (
         <LogosSlide slide={slide} onPause={onPause} />
      ) : slide.kind === "workshop" ? (
        <WorkshopSlide slide={slide} />
       ) : slide.kind === "document" ? (
         <DocumentSlide slide={slide} active={active} onPause={onPause} />
       ) : slide.kind === "photo-text" ? (
         null
      ) : (
         <SlideText slide={slide} />
      )}
      {actions.length > 0 && <nav aria-label={`Links for ${slide.title || "this slide"}`} className="absolute inset-x-4 bottom-32 z-10 flex flex-wrap items-center justify-center gap-2 @3xl:bottom-36">
        {actions.map((action) => (
          <span key={action.index}
            data-action-index={onActionMove ? action.index : undefined}
            tabIndex={onActionMove ? 0 : undefined}
            aria-label={onActionMove ? `Button ${action.index + 1}: drag to move, or use arrow keys` : undefined}
            className={cn("inline-flex", onActionMove && "slide-text-draggable")}
            onClickCapture={(event) => { if (onActionMove) event.preventDefault(); }}
            style={{ transform: `translate(${clamp(action.x ?? 0, -70, 70)}cqw, ${clamp(action.y ?? 0, -70, 70)}cqh)` }}>
            <SlideActionLink action={{ ...action, url: action.url ?? "" }} index={action.index} href={action.url ?? ""} onPause={onPause} />
          </span>
        ))}
      </nav>}
    </div>
  );
}

function DocumentSlide({ slide, active, onPause }: { slide: Slide; active: boolean; onPause: (p: boolean) => void }) {
  const claim = useServerFn(requestDocument);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [website, setWebsite] = useState("");
  const [consent, setConsent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);
  const expired = slide.document_expires_at ? new Date(slide.document_expires_at) <= new Date() : false;
  return (
     <div data-document className={cn("absolute inset-0 flex items-center justify-center overflow-y-auto px-8 pt-12 @3xl:px-16", slide.title_style?.actions?.some((action) => action.label && safeSignupUrl(action.url)) ? "pb-56" : "pb-36")}>
      <div className="w-full max-w-lg space-y-5">
        <h2 data-anchor={anchorId(slide.id, "title")} className={textStyleClasses(slide.title_style, "title")} style={{ ...textStyleCss(slide.title_style, "title"), ...textPlacement(slide.title_style) }}><span className={textBackingClasses(slide.title_style, "title")}>{slide.title}</span></h2>
        {slide.subtitle && <p data-anchor={anchorId(slide.id, "subtitle")} className={cn("whitespace-pre-line", textStyleClasses(slide.subtitle_style, "subtitle"))} style={{ ...textStyleCss(slide.subtitle_style, "subtitle"), ...textPlacement(slide.subtitle_style) }}><span className={textBackingClasses(slide.subtitle_style, "subtitle")}>{slide.subtitle}</span></p>}
        {!slide.document_path || expired || (slide.document_max_downloads > 0 && slide.document_download_count >= slide.document_max_downloads) ? <p className="text-sm text-foreground">Download unavailable.</p> : (
          <form data-anchor={anchorId(slide.id, "cta")} className="space-y-4" onFocus={() => onPause(true)} onSubmit={async (event) => {
            event.preventDefault();
            if (!active || loading) return;
            setLoading(true); setError(""); setDone(false);
            try {
              const { url } = await claim({ data: { slideId: slide.id, name, email, website } });
              const link = document.createElement("a");
              link.href = url; link.download = slide.document_name; link.rel = "noopener noreferrer";
              document.body.appendChild(link); link.click(); link.remove();
              setDone(true);
            } catch (cause) { setError(cause instanceof Error ? cause.message : "Download unavailable. Please try again."); }
            finally { setLoading(false); }
          }}>
            <p className="text-sm font-medium">{slide.document_name}</p>
            <div className="space-y-1"><label htmlFor={`document-name-${slide.id}`} className="text-sm font-medium">Name</label><input id={`document-name-${slide.id}`} required minLength={2} maxLength={120} autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} className="h-11 w-full rounded-md border border-input bg-background px-3 text-foreground placeholder:text-muted-foreground focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-foreground" /></div>
            <div className="space-y-1"><label htmlFor={`document-email-${slide.id}`} className="text-sm font-medium">Email</label><input id={`document-email-${slide.id}`} required type="email" maxLength={254} autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} className="h-11 w-full rounded-md border border-input bg-background px-3 text-foreground placeholder:text-muted-foreground focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-foreground" /></div>
            <div className="absolute -left-[10000px]" aria-hidden="true"><label htmlFor={`document-website-${slide.id}`}>Website</label><input id={`document-website-${slide.id}`} name="website" tabIndex={-1} autoComplete="off" value={website} onChange={(e) => setWebsite(e.target.value)} /></div>
            <label className="flex items-start gap-3 text-xs text-muted-foreground"><input type="checkbox" required checked={consent} onChange={(e) => setConsent(e.target.checked)} className="mt-0.5 accent-primary" /><span>I agree to share my name and email for this download. My details will no longer be accessible after {slide.document_retention_days} days.</span></label>
            <Button type="submit" disabled={loading || !consent} className="min-h-11 w-full"><Download className="mr-2 h-4 w-4" />{loading ? "Preparing…" : "Download file"}</Button>
            <p role="status" aria-live="polite" className="text-sm">{error || (done ? "Your download is ready." : "")}</p>
          </form>
        )}
      </div>
    </div>
  );
}

function SlideText({ slide }: { slide: Slide }) {
  const layout = slide.kind === "text" ? screenLayout(slide.title_style) : "centered";
  return (
    <div className={cn(
       "absolute inset-0 p-8 @3xl:p-16",
      slide.kind === "video" && "pointer-events-none [&>*]:pointer-events-auto",
       slide.title_style?.actions?.some((action) => action.label && safeSignupUrl(action.url)) && "pb-48 @3xl:pb-52",
      layout === "centered" && "-mt-[10vh] flex flex-col items-center justify-center",
      layout === "left-block" && "flex flex-col items-start justify-center",
      layout === "top-banner" && "flex flex-col items-center justify-start pt-[12vh] @3xl:pt-[15vh]",
      layout === "split" && "grid content-center items-center gap-8 @3xl:grid-cols-2 @3xl:gap-16",
    )}>
       <h2 data-anchor={anchorId(slide.id, "title")} className={cn("max-w-4xl", layout !== "split" && "mb-4", textStyleClasses(slide.title_style, "title"))} style={{ ...textStyleCss(slide.title_style, "title"), ...textPlacement(slide.title_style) }}>
        <span className={textBackingClasses(slide.title_style, "title")}>{slide.title}</span>
      </h2>
      {slide.subtitle && (
         <p data-anchor={anchorId(slide.id, "subtitle")} className={cn("max-w-2xl whitespace-pre-line", textStyleClasses(slide.subtitle_style, "subtitle"))} style={{ ...textStyleCss(slide.subtitle_style, "subtitle"), ...textPlacement(slide.subtitle_style) }}>
          <span className={textBackingClasses(slide.subtitle_style, "subtitle")}>{slide.subtitle}</span>
        </p>
      )}
    </div>
  );
}

function ListSlide({ slide, active, onPause }: { slide: Slide; active: boolean; onPause: (p: boolean) => void }) {
  const [open, setOpen] = useState<number | null>(null);
  const headingStyle = { size: "medium" as const, weight: "light" as const, readability: "none" as const, ...slide.title_style };
  useEffect(() => {
    if (!active) setOpen(null);
  }, [active]);
  const item = open !== null ? slide.items[open] : null;

  return (
     <div className={cn("absolute inset-0 flex items-center justify-center p-8", slide.title_style?.actions?.some((action) => action.label && safeSignupUrl(action.url)) && "pb-44")}>
      <div className="relative -mt-[10vh] h-[380px] w-full max-w-xl">
        <div
          aria-hidden={Boolean(item)}
          inert={Boolean(item)}
          className={cn(
            "absolute inset-0 flex flex-col justify-center transition-all duration-500 motion-reduce:transition-none",
            item ? "pointer-events-none -translate-x-10 opacity-0" : "translate-x-0 opacity-100",
          )}
        >
           <h2 data-anchor={anchorId(slide.id, "title")} className={cn("mb-10", textStyleClasses(headingStyle, "title"))} style={{ ...textStyleCss(headingStyle, "title"), ...textPlacement(slide.title_style) }}><span className={textBackingClasses(headingStyle, "title")}>{slide.title}</span></h2>
          <div className="flex flex-col">
            {slide.items.map((it, i) => (
              <Button type="button" variant="ghost"
                key={i}
                data-anchor={anchorId(slide.id, `item-${i}`)}
                onClick={() => {
                  setOpen(i);
                  onPause(true);
                }}
                className="group flex h-auto w-full items-center justify-between rounded-none border-b border-foreground/20 py-6 text-left transition-colors last:border-transparent hover:border-primary/50 focus-visible:ring-2 focus-visible:ring-foreground"
              >
                <span className="text-xl font-light transition-colors group-hover:text-primary @3xl:text-2xl">
                  {it.title}
                </span>
                <ChevronRight className="h-6 w-6 text-foreground/50 transition-all group-hover:translate-x-1 group-hover:text-primary" />
              </Button>
            ))}
          </div>
        </div>
        <div
          aria-hidden={!item}
          inert={!item}
          className={cn(
            "absolute inset-0 flex flex-col justify-center transition-all duration-500 motion-reduce:transition-none",
            item ? "translate-x-0 opacity-100" : "pointer-events-none translate-x-10 opacity-0",
          )}
        >
          <Button type="button" variant="ghost"
            onClick={() => {
              setOpen(null);
              onPause(false);
            }}
            className="group mb-8 flex w-fit items-center text-sm font-medium tracking-widest text-foreground/70 uppercase transition-colors hover:text-foreground focus-visible:ring-2 focus-visible:ring-foreground"
          >
            <ChevronLeft className="mr-2 h-4 w-4 transition-transform group-hover:-translate-x-1" />
            Back
          </Button>
          <h2 className={cn("mb-6", textStyleClasses(headingStyle, "title"))} style={textStyleCss(headingStyle, "title")}><span className={textBackingClasses(headingStyle, "title")}>{item?.title}</span></h2>
          <p className="mb-8 text-lg leading-relaxed font-light text-foreground/70">{item?.desc}</p>
          <div className="text-sm font-medium tracking-widest text-primary uppercase">{item?.meta}</div>
        </div>
      </div>
    </div>
  );
}

function LogoImage({ src, alt, removeWhite }: { src: string; alt: string; removeWhite: boolean }) {
  const out = useWhiteRemoved(src, removeWhite);
  if (!out) return <span role="img" aria-label={alt} className="h-full w-full" />;
  return <img src={out} alt={alt} className="h-full w-full object-contain" draggable={false} />;
}

function LogosSlide({ slide, onPause }: { slide: Slide; onPause: (p: boolean) => void }) {
  const logos = slide.items.map((it, idx) => ({ ...it, idx })).filter((it) => it.logo_url).slice(0, 9);
  const n = logos.length;
  const hasActions = slide.title_style?.actions?.some((action) => action.label && safeSignupUrl(action.url));
  return (
    <div className={cn("absolute inset-0 flex items-center justify-center overflow-y-auto px-6 pt-16 @3xl:px-16", hasActions ? "pb-56" : "pb-40")}>
      <div className="w-full max-w-4xl text-center">
        {slide.title && <h2 data-anchor={anchorId(slide.id, "title")} className={cn("mb-3", textStyleClasses(slide.title_style, "title"))} style={{ ...textStyleCss(slide.title_style, "title"), ...textPlacement(slide.title_style) }}><span className={textBackingClasses(slide.title_style, "title")}>{slide.title}</span></h2>}
        {slide.subtitle && <p data-anchor={anchorId(slide.id, "subtitle")} className={cn("mb-8", textStyleClasses(slide.subtitle_style, "subtitle"))} style={{ ...textStyleCss(slide.subtitle_style, "subtitle"), ...textPlacement(slide.subtitle_style) }}><span className={textBackingClasses(slide.subtitle_style, "subtitle")}>{slide.subtitle}</span></p>}
        {n > 0 && (() => {
          // Balanced rows: 1-3 one row, 4 → 2+2, 5 → 3+2, 6 → 3+3, 7 → 4+3, 8 → 4+4, 9 → 3+3+3
          const perRow = n <= 3 ? n : n === 4 ? 2 : n <= 6 ? 3 : n <= 8 ? 4 : 3;
          const scale = Math.min(160, Math.max(60, slide.title_style?.logo_size ?? 100)) / 100;
          const base = perRow === 1 ? 320 : perRow === 2 ? 280 : perRow === 3 ? 240 : 200;
          const pad = slide.title_style?.logo_padding ?? "tight";
          const gap = perRow >= 4 ? 12 : 20;
          return (
          <ul aria-label="Organizations we work with" className={cn("mx-auto flex flex-wrap justify-center", perRow >= 3 ? "[--cols:2] @3xl:[--cols:var(--cols-lg)]" : "[--cols:var(--cols-lg)]")} style={{ gap, ["--cols-lg" as string]: perRow, maxWidth: `min(100%, ${Math.round(base * scale * perRow + gap * (perRow - 1))}px)` }}>
            {logos.map((it) => {
              const href = safeSignupUrl(it.signup_url ?? "");
              const removeBg = slide.title_style?.logo_bg === "remove";
              const img = <LogoImage src={it.logo_url ?? ""} alt={it.title || "Partner logo"} removeWhite={removeBg} />;
              const tile = cn("flex aspect-[3/2] w-full items-center justify-center overflow-hidden rounded-xl", removeBg ? "" : "border border-foreground/15 bg-foreground/90", pad === "none" ? "p-0" : pad === "tight" ? "p-1.5 @3xl:p-2" : "p-3 @3xl:p-5");
              return (
                <li key={it.idx} data-anchor={anchorId(slide.id, `item-${it.idx}`)} style={{ flex: `0 0 calc((100% - ${gap}px * (var(--cols) - 1)) / var(--cols))` }}>
                  {href
                    ? <a href={href} target="_blank" rel="noopener noreferrer" onClick={() => onPause(true)} aria-label={`${it.title || "Partner"} website (opens in a new tab)`} className={cn(tile, "transition-transform hover:scale-105 focus-visible:outline-2 focus-visible:outline-primary motion-reduce:transition-none")}>{img}</a>
                    : <div className={tile}>{img}</div>}
                </li>
              );
            })}
          </ul>
          );
        })()}
      </div>
    </div>
  );
}

function FaqSlide({ slide, active }: { slide: Slide; active: boolean }) {
  const [open, setOpen] = useState<number | null>(null);
  useEffect(() => {
    if (!active) setOpen(null);
  }, [active]);
  return (
     <div data-document className={cn("absolute inset-0 flex items-center justify-center overflow-y-auto px-8 pt-16 @3xl:px-16", slide.title_style?.actions?.some((action) => action.label && safeSignupUrl(action.url)) ? "pb-56" : "pb-40")}>
      <div className="w-full max-w-2xl">
        {slide.title && <h2 data-anchor={anchorId(slide.id, "title")} className={cn("mb-4", textStyleClasses(slide.title_style, "title"))} style={{ ...textStyleCss(slide.title_style, "title"), ...textPlacement(slide.title_style) }}><span className={textBackingClasses(slide.title_style, "title")}>{slide.title}</span></h2>}
        {slide.subtitle && <p data-anchor={anchorId(slide.id, "subtitle")} className={cn("mb-8", textStyleClasses(slide.subtitle_style, "subtitle"))} style={{ ...textStyleCss(slide.subtitle_style, "subtitle"), ...textPlacement(slide.subtitle_style) }}><span className={textBackingClasses(slide.subtitle_style, "subtitle")}>{slide.subtitle}</span></p>}

        <div className="divide-y divide-foreground/20 rounded-lg border border-foreground/20 bg-background/50 backdrop-blur-md">
          {slide.items.map((it, i) => {
            const isOpen = open === i;
            return (
              <div key={i} data-anchor={anchorId(slide.id, `item-${i}`)}>
                <h3>
                  <button type="button" id={`faq-${slide.id}-q-${i}`} aria-expanded={isOpen} aria-controls={`faq-${slide.id}-a-${i}`} onClick={() => setOpen(isOpen ? null : i)}
                    className="flex min-h-11 w-full items-center justify-between gap-4 px-5 py-4 text-left text-lg font-medium text-foreground hover:text-primary">
                    <span>{it.title}</span>
                    <ChevronRight aria-hidden="true" className={cn("h-5 w-5 shrink-0 transition-transform motion-reduce:transition-none", isOpen && "rotate-90")} />
                  </button>
                </h3>
                <div id={`faq-${slide.id}-a-${i}`} role="region" aria-labelledby={`faq-${slide.id}-q-${i}`} hidden={!isOpen} className="px-5 pb-5 leading-relaxed whitespace-pre-line text-foreground/80">{it.desc}</div>
              </div>
            );
          })}
          {slide.items.length === 0 && <p className="px-5 py-4 text-muted-foreground">No questions yet.</p>}
        </div>
      </div>
    </div>
  );
}

type WorkshopRange = "all" | "week" | "month" | "later";
const WORKSHOP_RANGES: { value: WorkshopRange; label: string }[] = [
  { value: "all", label: "All sessions" },
  { value: "week", label: "Next 7 days" },
  { value: "month", label: "Next 30 days" },
  { value: "later", label: "Later" },
];
function inRange(start: string, range: WorkshopRange): boolean {
  const t = new Date(start).getTime();
  if (!start || Number.isNaN(t)) return false;
  const days = (t - Date.now()) / 86400000;
  if (days < 0) return false;
  return range === "week" ? days <= 7 : range === "month" ? days <= 30 : range === "later" ? days > 30 : true;
}

function WorkshopSlide({ slide }: { slide: Slide }) {
  const track = useServerFn(trackWorkshopClick);
  const [range, setRange] = useState<WorkshopRange>("all");
  const hasSchedule = slide.items.some((it) => (it.starts ?? []).some(Boolean));
  const visible = slide.items.map((it, i) => ({ it, i })).filter(({ it }) => range === "all" || (it.starts ?? []).some((st) => inRange(st, range)));
  return (
     <div className={cn("absolute inset-0 flex items-center justify-center overflow-y-auto px-8 pt-16 @3xl:px-16", slide.title_style?.actions?.some((action) => action.label && safeSignupUrl(action.url)) ? "pb-56" : "pb-40")}>
      <div className="w-full max-w-2xl">
        {slide.title && <h2 data-anchor={anchorId(slide.id, "title")} className={cn("mb-4", textStyleClasses(slide.title_style, "title"))} style={{ ...textStyleCss(slide.title_style, "title"), ...textPlacement(slide.title_style) }}><span className={textBackingClasses(slide.title_style, "title")}>{slide.title}</span></h2>}
        {slide.subtitle && <p data-anchor={anchorId(slide.id, "subtitle")} className={cn("mb-8", textStyleClasses(slide.subtitle_style, "subtitle"))} style={{ ...textStyleCss(slide.subtitle_style, "subtitle"), ...textPlacement(slide.subtitle_style) }}><span className={textBackingClasses(slide.subtitle_style, "subtitle")}>{slide.subtitle}</span></p>}
        <div className="space-y-4">
          {hasSchedule && (
            <div role="group" aria-label="Filter sessions by date" className="flex flex-wrap gap-2">
              {WORKSHOP_RANGES.map((r) => (
                <Button key={r.value} type="button" size="sm" variant={range === r.value ? "default" : "outline"} aria-pressed={range === r.value} className="min-h-11" onClick={() => setRange(r.value)}>{r.label}</Button>
              ))}
            </div>
          )}
          <p className="sr-only" role="status" aria-live="polite">{range === "all" ? "" : `${visible.length} ${visible.length === 1 ? "session" : "sessions"} shown`}</p>
          {visible.length === 0 && slide.items.length > 0 && <p className="text-foreground/80">No sessions in this time range.</p>}
          {visible.map(({ it, i }) => {
            const allDates = [it.meta, ...(it.dates ?? [])];
            const dates = allDates.map((d, j) => ({ label: d.trim(), cal: calendarLinks(it, it.starts?.[j] ?? "") })).filter((d) => d.label);
            const url = safeSignupUrl(it.signup_url);
            const cap = typeof it.capacity === "number" && it.capacity > 0 ? it.capacity : null;
            const left = typeof it.seats_left === "number" && it.seats_left >= 0 ? (cap ? Math.min(it.seats_left, cap) : it.seats_left) : null;
            const full = left === 0;
            const cta = it.cta_label?.trim() || "Register now";
            const waitlist = safeSignupUrl(it.waitlist_url);
            return (
              <article key={i} data-anchor={anchorId(slide.id, `item-${i}`)} aria-labelledby={`${slide.id}-ws-${i}`} className="rounded-lg border border-foreground/20 bg-background/50 p-5 backdrop-blur-md">
                {dates.length === 1 && <p className="mb-1 text-sm font-medium tracking-widest text-primary uppercase"><span className="sr-only">When: </span>{dates[0]!.label}</p>}
                <h3 id={`${slide.id}-ws-${i}`} className="text-lg font-medium text-foreground">{it.title}</h3>
                {dates.length > 1 && (
                  <ul aria-label={`Dates for ${it.title}`} className="mt-3 flex flex-wrap gap-2">
                    {dates.map((d, j) => <li key={j} className="rounded-full border border-primary/40 px-3 py-1 text-sm font-medium text-primary">{d.label}</li>)}
                  </ul>
                )}
                {dates.some((d) => d.cal) && (
                  <ul aria-label={`Add ${it.title} to your calendar`} className="mt-3 space-y-1 text-sm">
                    {dates.map((d, j) => d.cal && (
                      <li key={j} className="flex flex-wrap items-center gap-x-3 gap-y-1">
                        <CalendarPlus className="h-4 w-4 text-primary" aria-hidden="true" />
                        <span className="text-foreground/80">{d.label}{it.timezone ? ` (${it.timezone})` : ""}:</span>
                        <a className="font-medium text-primary underline underline-offset-4" href={d.cal.google} target="_blank" rel="noopener noreferrer">Google<span className="sr-only"> Calendar, {d.label}, opens in a new tab</span></a>
                        <a className="font-medium text-primary underline underline-offset-4" href={d.cal.ics} download={`${it.title || "workshop"}.ics`}>Apple / Outlook<span className="sr-only"> calendar file, {d.label}</span></a>
                      </li>
                    ))}
                  </ul>
                )}
                {it.desc && <p className="mt-2 leading-relaxed whitespace-pre-line text-foreground/80">{it.desc}</p>}
                {(cap !== null || left !== null) && (
                  <div className="mt-4">
                    <p className={cn("text-sm font-medium", full ? "text-destructive" : "text-foreground")}><span className="sr-only">Availability: </span>
                      {full ? "Fully booked" : left !== null ? `${left} ${left === 1 ? "seat" : "seats"} left${cap ? ` of ${cap}` : ""}` : `${cap} seats`}
                    </p>
                    {cap !== null && left !== null && (
                      <div role="progressbar" aria-label="Seats taken" aria-valuemin={0} aria-valuemax={cap} aria-valuenow={cap - left} className="mt-2 h-1.5 overflow-hidden rounded-full bg-foreground/20">
                        <div className="h-full bg-primary" style={{ width: `${((cap - left) / cap) * 100}%` }} />
                      </div>
                    )}
                  </div>
                )}
                {full && waitlist ? (
                  <Button asChild variant="outline" className="mt-4 min-h-11 w-full @xl:w-auto">
                    <a href={waitlist} target="_blank" rel="noopener noreferrer">Join the waitlist<span className="sr-only"> for {it.title}, session full (opens in a new tab)</span></a>
                  </Button>
                ) : full ? (
                  <p className="mt-4 text-sm font-medium text-foreground/80">This session is full.</p>
                ) : null}
                {url && !full && (
                  <Button asChild className="mt-4 min-h-11 w-full @xl:w-auto">
                    <a href={url} target="_blank" rel="noopener noreferrer" onClick={() => { void track({ data: { slideId: slide.id, sessionTitle: it.title, signupUrl: url } }).catch(() => undefined); }}>{cta}<span className="sr-only"> for {it.title} (opens in a new tab)</span></a>
                  </Button>
                )}
                {!url && !full && <p className="mt-4 text-sm font-medium text-foreground/70">Registration opening soon.</p>}
              </article>
            );
          })}
          {slide.items.length === 0 && <p className="text-muted-foreground">No sessions yet.</p>}
        </div>
      </div>
    </div>
  );
}

function ChatDock({ placeholder, chatStyle: look, onActive, onInactive, deckState, onHighlight, onCreateSlide, aborted, abortedTitle, onResume, collapsed, onReopen, boardCount, onOpenBoard, onLeadForm }: { placeholder: string; chatStyle: ChatStyle; onActive: () => void; onInactive: () => void; deckState: { slideIds: string[]; visibleSlideId: string | null }; onHighlight: (h: Highlight) => void; onCreateSlide: (result: Extract<GuideAnswer, { action: "create_slide" }>, question: string) => void; aborted: Highlight | null; abortedTitle: string; onResume: () => void; collapsed: Highlight[]; onReopen: (h: Highlight) => void; boardCount: number; onOpenBoard: () => void; onLeadForm: () => void }) {
  const guide = useServerFn(askGuide);
  const [input, setInput] = useState("");
  const LeadIcon = chatIcon(look.icon);
  const SendIcon = sendIcon(look.send_icon);
  const [loading, setLoading] = useState(false);
  const [notice, setNotice] = useState("");
  const [options, setOptions] = useState<GuideSource[]>([]);

  async function send() {
    const text = input.trim();
    if (!text || loading) return;
    setLoading(true);
    setNotice("");
    setOptions([]);
    try {
      const result = await guide({ data: { question: text, deckState } });
      if (result.action === "highlight") {
        onHighlight({ slideId: result.targetSlideId, anchorId: result.anchorId, comment: result.comment.split(/(?<=[.!?])\s+/).slice(0, 2).join(" "), label: result.chipLabel, question: text });
        setNotice(`Found on “${result.slideTitle}”. The highlighted text is the source.`);
        setInput("");
      } else if (result.action === "suggest") {
        setOptions(result.matches);
        setNotice("A few slides may fit. Choose the source you meant.");
      } else if (result.action === "create_slide") {
        onCreateSlide(result, text);
        setNotice("A new unpublished topic slide was added here for this session.");
        setInput("");
      } else if (result.action === "trigger_lead_form") {
        setNotice("Contact details aren't sent to slide search. Use the private form instead.");
        onLeadForm();
      } else setNotice(result.message);
    } catch {
      setNotice("Search could not finish. Your question is still here—please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div data-chat className="pointer-events-none absolute bottom-0 z-20 flex w-full flex-col">
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
      <div className="relative z-10 mx-auto flex w-full max-w-3xl flex-col justify-end px-4 pt-16 pb-6">
        <p className="pointer-events-auto mb-2 self-center rounded-full border border-white/20 bg-black/55 px-3 py-1 text-xs font-semibold text-white backdrop-blur-sm">Search the slides · answers point to their source</p>
        {(collapsed.length > 0 || boardCount > 0) && <div role="group" aria-label="Earlier answers" className="pointer-events-auto mb-2 flex gap-2 overflow-x-auto pb-1">
          {boardCount > 0 && <Button type="button" size="sm" onClick={onOpenBoard} className="h-11 shrink-0">Your answers ({boardCount})</Button>}
          {collapsed.map((item) => <Button key={item.anchorId} type="button" variant="outline" size="sm" onClick={() => onReopen(item)} className="h-11 shrink-0 border-primary bg-background text-foreground">{item.label}</Button>)}
        </div>}
        {aborted && <Button type="button" variant="outline" onClick={onResume} className="pointer-events-auto mb-2 self-center border-primary bg-background text-foreground">Answer on {abortedTitle}</Button>}
        {notice && <p role="status" className="pointer-events-auto mb-2 self-center rounded-md bg-background px-3 py-2 text-sm text-foreground">{notice}</p>}
        {options.length > 0 && <div role="group" aria-label="Possible source slides" className="pointer-events-auto mb-2 flex flex-wrap justify-center gap-2">
          {options.map((option) => <Button key={option.targetSlideId} type="button" size="sm" variant="outline" className="min-h-11 border-primary bg-background text-foreground" onClick={() => {
            onHighlight({ slideId: option.targetSlideId, anchorId: option.anchorId, comment: option.comment, label: option.slideTitle, question: input });
            setNotice(`Found on “${option.slideTitle}”. The highlighted text is the source.`);
            setOptions([]);
            setInput("");
          }}>{option.slideTitle}</Button>)}
        </div>}
        <div role="status" aria-live="polite" className="mb-3 flex min-h-6 justify-center">
          {loading && (
            <span className="flex items-center gap-1.5 rounded-full border border-foreground/10 bg-background/60 px-4 py-2 text-foreground/70 backdrop-blur-md">
              <span className="sr-only">Finding your answer…</span>
              <span className="typing-dot" /><span className="typing-dot" /><span className="typing-dot" />
            </span>
          )}
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void send();
          }}
          data-chat-design={look.design}
          className={cn("chat-bar pointer-events-auto flex items-center gap-1.5 shadow-xl backdrop-blur-xl", `chat-bar--${look.design}`, look.size === "slim" ? "p-1" : "p-2")}
          style={look.bar_color ? ({ ["--chat-bar-accent" as string]: look.bar_color }) : undefined}
        >
          {LeadIcon && <div className="pl-2.5 text-primary" style={look.bar_color ? { color: look.bar_color } : undefined}>
            <LeadIcon aria-hidden className={look.size === "slim" ? "h-5 w-5" : "h-6 w-6"} />
          </div>}
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onFocus={onActive}
            onBlur={onInactive}
            placeholder={placeholder || "Ask a question about these slides…"}
            aria-label="Search the slides"
            maxLength={500}
            className={cn("w-full flex-1 bg-transparent px-2 text-[15px]", look.size === "slim" ? "py-1.5" : "py-2.5", "font-medium text-foreground placeholder:text-foreground/60 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-foreground")}
          />
          <button
            type="submit"
            aria-label="Search slides"
            disabled={loading || !input.trim()}
            className={cn("slide-action inline-flex h-11 w-11 shrink-0 items-center justify-center transition-colors disabled:opacity-60 motion-reduce:transition-none", `slide-action--${look.button_style}`, `slide-action-shape--${look.button_shape}`)}
            style={actionColorVariables({ label: "", url: "", style: look.button_style, color: look.button_color || undefined, shape: look.button_shape })}
          >
            <SendIcon aria-hidden className="h-5 w-5" />
          </button>
        </form>
      </div>
    </div>
  );
}
