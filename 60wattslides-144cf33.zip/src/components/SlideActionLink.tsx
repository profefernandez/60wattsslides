import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { actionColorVariables, actionShape, actionStyle, type Rgb, type SlideAction } from "@/lib/slide-actions";
import { cn } from "@/lib/utils";

function themeRgb(element: HTMLElement): Rgb | undefined {
  const canvas = document.createElement("canvas");
  const context = canvas.getContext("2d");
  if (!context) return undefined;
  const primary = getComputedStyle(element).getPropertyValue("--primary").trim();
  if (!primary) return undefined;
  context.fillStyle = primary;
  context.fillRect(0, 0, 1, 1);
  const pixels = context.getImageData(0, 0, 1, 1).data;
  return [pixels[0] ?? 0, pixels[1] ?? 0, pixels[2] ?? 0];
}

export function SlideActionLink({ action, index, href, preview = false, onPause }: {
  action: SlideAction;
  index: number;
  href?: string;
  preview?: boolean;
  onPause?: (paused: boolean) => void;
}) {
  const node = useRef<HTMLElement | null>(null);
  const [themeColor, setThemeColor] = useState<Rgb>();
  useEffect(() => {
    const update = () => { if (node.current) setThemeColor(themeRgb(node.current)); };
    update();
    const observer = new MutationObserver(update);
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ["class", "style"] });
    return () => observer.disconnect();
  }, []);
  const appearance = actionStyle(action, index);
  const shape = actionShape(action);
  const className = cn("slide-action min-h-11 max-w-[min(100%,16rem)] min-w-32 whitespace-normal break-words px-4 py-2 text-center font-semibold transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 @3xl:min-w-40", `slide-action--${appearance}`, `slide-action-shape--${shape}`);
  const style = actionColorVariables(action, index, themeColor);
  if (preview) return <span ref={node} data-slide-action-style={appearance} data-slide-action-shape={shape} className={cn(className, "inline-flex items-center justify-center")} style={style}>{action.label || "Button preview"}</span>;
  return <Button asChild variant="outline" className={className} style={style} data-slide-action-style={appearance} data-slide-action-shape={shape}>
    <a ref={(element) => { node.current = element; }} href={href} target="_blank" rel="noopener noreferrer" onFocus={() => onPause?.(true)} onBlur={() => onPause?.(false)}>{action.label}<span className="sr-only"> (opens in a new tab)</span></a>
  </Button>;
}