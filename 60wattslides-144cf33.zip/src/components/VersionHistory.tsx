import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import type { SiteContent, SiteSettings, Slide } from "@/lib/cms";
import { cn } from "@/lib/utils";

interface Version {
  id: string;
  created_at: string;
  author_email: string;
  snapshot: SiteContent;
}

export const versionsQueryKey = ["content-versions"];

export async function fetchVersions(): Promise<Version[]> {
  const { data, error } = await supabase
    .from("content_versions")
    .select("id, created_at, author_email, snapshot")
    .order("created_at", { ascending: false })
    .limit(30);
  if (error) throw error;
  return data.map((v) => ({ ...v, snapshot: v.snapshot as unknown as SiteContent }));
}

export async function saveVersion(content: SiteContent) {
  const { data } = await supabase.auth.getUser();
  await supabase.from("content_versions").insert({
    created_by: data.user?.id ?? null,
    author_email: data.user?.email ?? "",
    snapshot: content as unknown as never,
  });
}

const SETTING_LABELS: Record<keyof SiteSettings, string> = {
  app_name: "Site name",
  chat_placeholder: "Chat box text",
  system_prompt: "AI instructions",
  autoplay_seconds: "Seconds per slide",
  annotation_mode: "Highlights button visibility",
  annotation_label: "Highlights button name",
  annotation_display: "Highlights button appearance",
  annotation_icon: "Highlights button icon",
  annotation_style: "Highlights button style",
  annotation_shape: "Highlights button shape",
  annotation_color: "Highlights button colour",
  answer_template: "Answer card look",
  chat_style: "Chat bar design",
};

function slideChanges(a: Slide, b: Slide): string[] {
  const out: string[] = [];
  if (a.title !== b.title) out.push("heading");
  if (a.subtitle !== b.subtitle) out.push("text");
  if (JSON.stringify(a.title_style ?? {}) !== JSON.stringify(b.title_style ?? {})) out.push("heading style");
  if (JSON.stringify(a.title_style?.actions ?? []) !== JSON.stringify(b.title_style?.actions ?? [])) out.push("slide buttons");
  if (JSON.stringify(a.subtitle_style ?? {}) !== JSON.stringify(b.subtitle_style ?? {})) out.push("text style");
  if (a.media_url !== b.media_url) out.push("media");
  if (a.document_path !== b.document_path || a.document_name !== b.document_name) out.push("download file");
  if (a.document_expires_at !== b.document_expires_at || a.document_max_downloads !== b.document_max_downloads || a.document_retention_days !== b.document_retention_days) out.push("download rules");
  if (a.document_max_upload_mb !== b.document_max_upload_mb || JSON.stringify(a.document_allowed_types) !== JSON.stringify(b.document_allowed_types)) out.push("upload rules");
  if ((a.media_alt ?? "") !== (b.media_alt ?? "")) out.push("photo description");
  if ((a.title_style?.background_color ?? "original") !== (b.title_style?.background_color ?? "original")) out.push("background");
  if ((a.title_style?.screen_layout ?? "centered") !== (b.title_style?.screen_layout ?? "centered")) out.push("screen layout");
  if (a.kind !== b.kind) out.push("type");
  if (a.overlay_opacity !== b.overlay_opacity) out.push("darkness");
  if (a.enabled !== b.enabled) out.push(b.enabled ? "shown" : "hidden");
  if (JSON.stringify(a.items) !== JSON.stringify(b.items)) out.push("list items");
  return out;
}

/** Describes what changes if you go from `from` to `to`. */
function diff(from: SiteContent, to: SiteContent): string[] {
  const lines: string[] = [];
  const fromById = new Map(from.slides.map((s) => [s.id, s]));
  const toById = new Map(to.slides.map((s) => [s.id, s]));
  for (const s of to.slides) {
    const prev = fromById.get(s.id);
    if (!prev) lines.push(`+ Slide added: "${s.title}"`);
    else {
      const c = slideChanges(prev, s);
      if (c.length) lines.push(`~ "${s.title || prev.title}": ${c.join(", ")} changed`);
    }
  }
  for (const s of from.slides) if (!toById.has(s.id)) lines.push(`− Slide removed: "${s.title}"`);
  const order = (c: SiteContent) => c.slides.filter((s) => fromById.has(s.id) && toById.has(s.id)).map((s) => s.id).join();
  if (order(from) !== order(to)) lines.push("~ Slide order changed");
  (Object.keys(SETTING_LABELS) as (keyof SiteSettings)[]).forEach((k) => {
    if (from.settings[k] !== to.settings[k]) lines.push(`~ ${SETTING_LABELS[k]} changed`);
  });
  return lines;
}

export function VersionHistory({ current, onRestore }: { current: SiteContent; onRestore: (c: SiteContent) => void }) {
  const { data: versions, isLoading } = useQuery({ queryKey: versionsQueryKey, queryFn: fetchVersions });
  const [open, setOpen] = useState<string | null>(null);

  if (isLoading) return <p className="text-sm text-muted-foreground">Loading history…</p>;
  if (!versions?.length)
    return <p className="text-sm text-muted-foreground">No versions yet. A version is saved every time you publish.</p>;

  return (
    <div className="space-y-2">
      <p className="text-xs text-muted-foreground">
        Each publish saves a version. Pick one to see how it differs from what's in the editor now.
      </p>
      {versions.map((v, i) => {
        const isOpen = open === v.id;
        const changes = isOpen ? diff(current, v.snapshot) : [];
        return (
          <div key={v.id} className={cn("rounded-md border", isOpen && "border-primary")}>
            <button onClick={() => setOpen(isOpen ? null : v.id)} className="w-full p-3 text-left hover:bg-accent/50">
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm font-medium">{new Date(v.created_at).toLocaleString()}</span>
                {i === 0 && <span className="rounded bg-primary/15 px-1.5 py-0.5 text-xs text-primary">Live</span>}
              </div>
              <div className="text-xs text-muted-foreground">
                {v.snapshot.slides.length} slides{v.author_email ? ` · ${v.author_email}` : ""}
              </div>
            </button>
            {isOpen && (
              <div className="space-y-3 border-t p-3">
                <div className="text-xs font-medium text-muted-foreground">Restoring this version would:</div>
                {changes.length ? (
                  <ul className="space-y-1 text-sm">
                    {changes.map((c, j) => (
                      <li key={j} className="font-mono text-xs">{c}</li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-sm text-muted-foreground">Change nothing — it matches the editor.</p>
                )}
                <Button size="sm" variant="outline" disabled={!changes.length} onClick={() => onRestore(v.snapshot)}>
                  <RotateCcw className="mr-1 h-4 w-4" /> Restore into editor
                </Button>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
