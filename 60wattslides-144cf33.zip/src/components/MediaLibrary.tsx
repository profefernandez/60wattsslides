import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Folder, Plus, Search, Tag, Trash2, Upload, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { supabase } from "@/integrations/supabase/client";
import { fetchVersions, versionsQueryKey } from "@/components/VersionHistory";
import type { SiteContent } from "@/lib/cms";
import { cn } from "@/lib/utils";
import { uploadMedia } from "@/lib/media";

interface MediaFile {
  name: string;
  size: number;
  type: string;
  created_at: string;
  url: string;
}

export const mediaQueryKey = ["media-library"];
export const mediaTagsQueryKey = ["media-asset-tags"];

interface AssetMeta {
  tags: string[];
  folder: string;
}

async function fetchAssets(): Promise<Map<string, AssetMeta>> {
  const { data, error } = await supabase.from("media_assets").select("name, tags, folder");
  if (error) throw error;
  return new Map((data ?? []).map((r) => [r.name, { tags: r.tags ?? [], folder: r.folder ?? "" }]));
}

export async function fetchMedia(): Promise<MediaFile[]> {
  const { data, error } = await supabase.storage.from("media").list("", { limit: 1000, sortBy: { column: "created_at", order: "desc" } });
  if (error) throw error;
  const files = data.filter((f) => f.id);
  if (!files.length) return [];
  const { data: signed, error: e2 } = await supabase.storage
    .from("media")
    .createSignedUrls(files.map((f) => f.name), 60 * 60);
  if (e2) throw e2;
  return files.map((f, i) => ({
    name: f.name,
    size: Number(f.metadata?.["size"] ?? 0),
    type: String(f.metadata?.["mimetype"] ?? ""),
    created_at: f.created_at ?? "",
    url: signed[i]?.signedUrl ?? "",
  }));
}

/** Uploaded files are referenced by signed URLs that contain "/media/<name>". */
const refersTo = (url: string, name: string) => url.includes(`/media/${encodeURIComponent(name)}`) || url.includes(`/media/${name}`);

const displayName = (name: string) => name.replace(/^[0-9a-f-]{36}-/, "");

function formatSize(b: number) {
  if (b > 1e6) return `${(b / 1e6).toFixed(1)} MB`;
  return `${Math.max(1, Math.round(b / 1e3))} KB`;
}

type Usage = "draft" | "live" | "history" | "unused";

export function MediaLibrary({
  draft,
  live,
  onUse,
  onUseUrl,
  canUse,
}: {
  draft: SiteContent;
  live: SiteContent;
  onUse: (file: { name: string; type: string }) => void;
  onUseUrl: (url: string) => void;
  canUse: boolean;
}) {
  const qc = useQueryClient();
  const { data: files, isLoading } = useQuery({ queryKey: mediaQueryKey, queryFn: fetchMedia });
  const { data: versions } = useQuery({ queryKey: versionsQueryKey, queryFn: fetchVersions });
  const { data: assets } = useQuery({ queryKey: mediaTagsQueryKey, queryFn: fetchAssets });
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<"all" | "used" | "unused">("all");
  const [tagFilter, setTagFilter] = useState<string | null>(null);
  const [folderFilter, setFolderFilter] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [linkUrl, setLinkUrl] = useState("");

  async function addUpload(file: File) {
    setUploading(true);
    try {
      await uploadMedia(file);
      await qc.invalidateQueries({ queryKey: mediaQueryKey });
      toast.success("Added to media library");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Couldn't upload file");
    } finally {
      setUploading(false);
    }
  }

  const allTags = useMemo(() => [...new Set([...(assets?.values() ?? [])].flatMap((a) => a.tags))].sort(), [assets]);
  const allFolders = useMemo(
    () => [...new Set([...(assets?.values() ?? [])].map((a) => a.folder).filter(Boolean))].sort(),
    [assets],
  );

  async function patchAsset(name: string, patch: { tags?: string[]; folder?: string }) {
    const { error } = await supabase.from("media_assets").upsert({ name, ...patch });
    if (error) {
      toast.error(error.message);
      return;
    }
    void qc.invalidateQueries({ queryKey: mediaTagsQueryKey });
  }
  const [pending, setPending] = useState<{ file: MediaFile; usage: Usage } | null>(null);
  const [deleting, setDeleting] = useState(false);

  const usage = useMemo(() => {
    const m = new Map<string, { usage: Usage; slides: string[] }>();
    for (const f of files ?? []) {
      const inDraft = draft.slides.filter((s) => refersTo(s.media_url, f.name)).map((s) => s.title || "Untitled");
      const inLive = live.slides.some((s) => refersTo(s.media_url, f.name));
      const inHistory = (versions ?? []).some((v) => v.snapshot.slides.some((s) => refersTo(s.media_url, f.name)));
      m.set(f.name, {
        usage: inDraft.length ? "draft" : inLive ? "live" : inHistory ? "history" : "unused",
        slides: inDraft,
      });
    }
    return m;
  }, [files, draft, live, versions]);

  const shown = (files ?? []).filter((f) => {
    const u = usage.get(f.name)?.usage;
    if (filter === "used" && (u === "unused" || u === "history")) return false;
    if (filter === "unused" && !(u === "unused" || u === "history")) return false;
    if (tagFilter && !(assets?.get(f.name)?.tags ?? []).includes(tagFilter)) return false;
    if (folderFilter && (assets?.get(f.name)?.folder ?? "") !== folderFilter) return false;
    return displayName(f.name).toLowerCase().includes(q.trim().toLowerCase());
  });

  async function confirmDelete() {
    if (!pending) return;
    setDeleting(true);
    const { error } = await supabase.storage.from("media").remove([pending.file.name]);
    if (!error) await supabase.from("media_assets").delete().eq("name", pending.file.name);
    setDeleting(false);
    setPending(null);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("File removed");
    void qc.invalidateQueries({ queryKey: mediaQueryKey });
    void qc.invalidateQueries({ queryKey: mediaTagsQueryKey });
  }

  return (
    <div className="space-y-3">
      <label className="flex cursor-pointer items-center justify-center gap-2 rounded-md border border-dashed p-3 text-sm text-muted-foreground hover:bg-accent">
        <Upload className="h-4 w-4" /> {uploading ? "Uploading…" : "Upload photo or video"}
        <input type="file" accept="image/*,video/*" className="hidden" disabled={uploading} onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) void addUpload(file);
          e.target.value = "";
        }} />
      </label>
      <div className="flex gap-2">
        <Input type="url" aria-label="Media link URL" placeholder="Or paste a photo or video URL" value={linkUrl} onChange={(e) => setLinkUrl(e.target.value)} />
        <Button variant="outline" disabled={!canUse || !linkUrl.trim()} onClick={() => {
          try {
            const parsed = new URL(linkUrl.trim());
            if (!["http:", "https:"].includes(parsed.protocol)) throw new Error("Invalid URL");
            onUseUrl(parsed.href);
            setLinkUrl("");
          } catch {
            toast.error("Enter a valid photo or video URL");
          }
        }}>Use link</Button>
      </div>
      {!canUse && <p className="text-xs text-muted-foreground">Select a slide to use media or a link.</p>}
      <div className="relative">
        <Search className="absolute top-2.5 left-2.5 h-4 w-4 text-muted-foreground" />
        <Input placeholder="Search uploads" className="pl-8" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="flex gap-1">
        {(["all", "used", "unused"] as const).map((f) => (
          <Button key={f} size="sm" variant={filter === f ? "secondary" : "ghost"} onClick={() => setFilter(f)} className="capitalize">
            {f}
          </Button>
        ))}
      </div>
      {allFolders.length > 0 && (
        <div className="flex flex-wrap items-center gap-1">
          <Folder className="h-3.5 w-3.5 text-muted-foreground" />
          {allFolders.map((f) => (
            <Button
              key={f}
              size="sm"
              variant={folderFilter === f ? "secondary" : "outline"}
              className="h-6 px-2 text-xs"
              onClick={() => setFolderFilter(folderFilter === f ? null : f)}
            >
              {f}
            </Button>
          ))}
        </div>
      )}
      {allTags.length > 0 && (
        <div className="flex flex-wrap gap-1">
          <Tag className="mt-1 h-3.5 w-3.5 text-muted-foreground" />
          {allTags.map((t) => (
            <Button
              key={t}
              size="sm"
              variant={tagFilter === t ? "secondary" : "outline"}
              className="h-6 px-2 text-xs"
              onClick={() => setTagFilter(tagFilter === t ? null : t)}
            >
              {t}
            </Button>
          ))}
        </div>
      )}

      {isLoading && <p className="text-sm text-muted-foreground">Loading uploads…</p>}
      {!isLoading && !shown.length && (
        <p className="text-sm text-muted-foreground">{files?.length ? "No uploads match." : "No uploads yet. Upload a photo or video above."}</p>
      )}

      <div className="grid grid-cols-2 gap-2">
        {shown.map((f) => {
          const u = usage.get(f.name) ?? { usage: "unused" as Usage, slides: [] };
          const isVideo = f.type.startsWith("video");
          const inUse = u.usage === "draft" || u.usage === "live";
          return (
            <div key={f.name} className="overflow-hidden rounded-md border bg-card">
              <div className="relative aspect-video bg-muted">
                {isVideo ? (
                  <video src={f.url} controls muted playsInline preload="metadata" className="h-full w-full object-cover" />
                ) : (
                  <img src={f.url} alt={displayName(f.name)} className="h-full w-full object-cover" loading="lazy" />
                )}
                <span
                  className={cn(
                    "absolute top-1 left-1 rounded px-1.5 py-0.5 text-[10px] font-medium",
                    inUse ? "bg-primary text-primary-foreground" : u.usage === "history" ? "bg-secondary text-secondary-foreground" : "bg-muted text-muted-foreground",
                  )}
                >
                  {u.usage === "draft" ? `In use · ${u.slides.length}` : u.usage === "live" ? "Live only" : u.usage === "history" ? "Old versions" : "Unused"}
                </span>
              </div>
              <div className="space-y-1 p-2">
                <div className="truncate text-xs font-medium" title={displayName(f.name)}>{displayName(f.name)}</div>
                <div className="text-[10px] text-muted-foreground">{formatSize(f.size)}</div>
                {u.slides.length > 0 && <div className="truncate text-[10px] text-muted-foreground" title={u.slides.join(", ")}>{u.slides.join(", ")}</div>}
                <FolderEditor folder={assets?.get(f.name)?.folder ?? ""} folders={allFolders} onChange={(folder) => void patchAsset(f.name, { folder })} />
                <TagEditor fileTags={assets?.get(f.name)?.tags ?? []} onChange={(next) => void patchAsset(f.name, { tags: next })} />
                <div className="flex gap-1">
                  <Button size="sm" variant="outline" className="h-7 flex-1 text-xs" disabled={!canUse} onClick={() => onUse(f)}>
                    Use
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-7 w-7"
                    aria-label="Remove file"
                    disabled={inUse}
                    title={inUse ? "Remove it from all slides (and publish) first" : "Remove file"}
                    onClick={() => setPending({ file: f, usage: u.usage })}
                  >
                    <Trash2 className="h-3.5 w-3.5 text-destructive" />
                  </Button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <AlertDialog open={!!pending} onOpenChange={(o) => !o && setPending(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove "{pending ? displayName(pending.file.name) : ""}"?</AlertDialogTitle>
            <AlertDialogDescription>
              {pending?.usage === "history"
                ? "This file isn't on your site, but some older saved versions use it. If you restore one of those, this slide will show a blank background. This can't be undone."
                : "This file isn't used anywhere. It will be permanently deleted."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} disabled={deleting}>Remove</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export function MediaPicker({ onSelect, kind }: { onSelect: (file: MediaFile) => void; kind: "image" | "video" }) {
  const [search, setSearch] = useState("");
  const { data: files, isLoading } = useQuery({ queryKey: mediaQueryKey, queryFn: fetchMedia });
  const matching = (files ?? []).filter((file) => file.type.startsWith(kind) && displayName(file.name).toLowerCase().includes(search.toLowerCase()));
  return (
    <div className="space-y-2">
      <Input aria-label="Search media" placeholder="Search media" value={search} onChange={(e) => setSearch(e.target.value)} />
      {isLoading && <p className="text-xs text-muted-foreground">Loading media…</p>}
      {!isLoading && !matching.length && <p className="text-xs text-muted-foreground">No matching {kind === "image" ? "photos" : "videos"} in the library.</p>}
      <div className="grid max-h-64 grid-cols-2 gap-2 overflow-y-auto">
        {matching.map((file) => (
          <Button key={file.name} variant="outline" className="h-auto min-w-0 flex-col items-stretch overflow-hidden p-1 text-left" onClick={() => onSelect(file)} title={displayName(file.name)}>
            {kind === "image" ? <img src={file.url} alt="" className="aspect-video w-full object-cover" /> : <video src={file.url} muted playsInline preload="metadata" className="aspect-video w-full object-cover" />}
            <span className="w-full truncate px-1 py-1 text-xs">{displayName(file.name)}</span>
          </Button>
        ))}
      </div>
    </div>
  );
}

function FolderEditor({ folder, folders, onChange }: { folder: string; folders: string[]; onChange: (folder: string) => void }) {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState("");

  function commit() {
    const v = value.trim().toLowerCase();
    setValue("");
    setEditing(false);
    if (v !== folder) onChange(v);
  }

  if (!editing)
    return (
      <button
        onClick={() => {
          setValue(folder);
          setEditing(true);
        }}
        className="flex items-center gap-1 rounded border border-dashed px-1.5 py-0.5 text-[10px] text-muted-foreground hover:bg-accent"
        title="Set folder"
      >
        <Folder className="h-2.5 w-2.5" /> {folder || "no folder"}
      </button>
    );

  return (
    <div className="flex items-center gap-1">
      <Input
        autoFocus
        list="media-folders"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => {
          if (e.key === "Enter") commit();
          if (e.key === "Escape") {
            setValue("");
            setEditing(false);
          }
        }}
        placeholder="Folder name"
        className="h-5 w-24 px-1 text-[10px]"
      />
      <datalist id="media-folders">
        {folders.map((f) => (
          <option key={f} value={f} />
        ))}
      </datalist>
    </div>
  );
}

function TagEditor({ fileTags, onChange }: { fileTags: string[]; onChange: (next: string[]) => void }) {
  const [adding, setAdding] = useState(false);
  const [value, setValue] = useState("");

  function commit() {
    const t = value.trim().toLowerCase();
    setValue("");
    setAdding(false);
    if (t && !fileTags.includes(t)) onChange([...fileTags, t]);
  }

  return (
    <div className="flex flex-wrap items-center gap-1">
      {fileTags.map((t) => (
        <span key={t} className="flex items-center gap-0.5 rounded bg-secondary px-1.5 py-0.5 text-[10px] text-secondary-foreground">
          {t}
          <button aria-label={`Remove tag ${t}`} onClick={() => onChange(fileTags.filter((x) => x !== t))}>
            <X className="h-2.5 w-2.5" />
          </button>
        </span>
      ))}
      {adding ? (
        <Input
          autoFocus
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onBlur={commit}
          onKeyDown={(e) => {
            if (e.key === "Enter") commit();
            if (e.key === "Escape") {
              setValue("");
              setAdding(false);
            }
          }}
          placeholder="Tag name"
          className="h-5 w-20 px-1 text-[10px]"
        />
      ) : (
        <button
          aria-label="Add tag"
          onClick={() => setAdding(true)}
          className="flex items-center gap-0.5 rounded border border-dashed px-1.5 py-0.5 text-[10px] text-muted-foreground hover:bg-accent"
        >
          <Plus className="h-2.5 w-2.5" /> tag
        </button>
      )}
    </div>
  );
}
