"""Run with: python3 tests/test_spotlight_browser.py (against the local preview)."""
import asyncio
from playwright.async_api import async_playwright

URL = "http://localhost:8080"

async def ask(page, text):
    await page.get_by_role("textbox", name="Chat message").fill(text)
    await page.get_by_role("button", name="Send message").click()
    await page.get_by_role("region", name="Answer controls").wait_for(timeout=15000)

async def focus_and_timer(page):
    await ask(page, "software engineering")
    assert await page.evaluate("document.activeElement?.textContent?.includes('Keep open')")
    bubble = page.get_by_role("region", name="Answer controls")
    await bubble.get_by_role("button", name="Keep open").click()
    await page.wait_for_timeout(8200)
    assert await bubble.count() == 1, "pin must prevent automatic dismissal"
    await bubble.get_by_role("button", name="Resume").click()
    await bubble.wait_for(state="detached", timeout=10000)
    await page.wait_for_function("document.activeElement?.getAttribute('aria-label') === 'Chat message'")
    await page.get_by_role("button", name="Next slide").click()
    temporary = page.locator('[aria-label^="Answered for you:"][aria-hidden="false"]')
    assert await temporary.count() == 1
    await temporary.get_by_role("button", name="Dismiss temporary answer").click()
    assert await page.locator('[aria-label^="Answered for you:"]').count() == 0
    trigger = page.get_by_role("group", name="Earlier answers").get_by_role("button")
    await trigger.click()
    await bubble.wait_for()
    await page.keyboard.press("Escape")
    await bubble.wait_for(state="detached")
    await page.wait_for_function("document.activeElement?.closest('[aria-label=\"Earlier answers\"]') !== null")

async def navigation_and_cap(page):
    # Each result comes from a different existing item on the same published slide.
    for question in ("software engineering", "data science", "digital marketing"):
        await ask(page, question)
        await page.keyboard.press("Escape")
        await page.get_by_role("region", name="Answer controls").wait_for(state="detached")
    temporary = page.locator('[aria-label^="Answered for you:"]')
    assert await temporary.count() == 2, "only two live answers are allowed"
    labels = await temporary.all_text_contents()
    assert not any("Software Engineering" in label for label in labels), "oldest must be evicted"
    assert any("Data Science" in label for label in labels)
    assert any("Digital Marketing" in label for label in labels)
    assert await page.get_by_role("group", name="Earlier answers").get_by_role("button", name="software engineering").count() == 1

async def focus_during_slide_change(page):
    await ask(page, "software engineering")
    assert await page.evaluate("document.activeElement?.textContent?.includes('Keep open')")
    # Moving to another slide while the bubble owns focus must leave focus in the carousel.
    await page.keyboard.press("ArrowRight")
    await page.get_by_role("region", name="Answer controls").wait_for(state="detached")
    await page.wait_for_function("document.activeElement?.getAttribute('aria-label') === 'Carousel'")
    assert await page.locator('[aria-current="step"]').get_attribute("aria-label") != "Go to slide 3 of 5: Our Premier Programs"

async def auto_collapse(page):
    await ask(page, "software engineering")
    await page.keyboard.press("Escape")
    await page.get_by_role("region", name="Answer controls").wait_for(state="detached")
    await page.get_by_role("button", name="Next slide").click()
    active = page.locator('[aria-label^="Answered for you:"][aria-hidden="false"]')
    assert await active.count() == 1
    for exit_number in (1, 2):
        await page.get_by_role("button", name="Next slide").click()
        await page.wait_for_timeout(80)
        if exit_number == 1:
            assert await page.locator('[aria-label^="Answered for you:"]').count() == 1
            await page.get_by_role("button", name="Previous slide").click()
            assert await active.count() == 1
        else:
            assert await page.locator('[aria-label^="Answered for you:"]').count() == 0
            assert await page.get_by_role("group", name="Earlier answers").get_by_role("button", name="software engineering").count() == 1

async def main():
    async with async_playwright() as playwright:
        browser = await playwright.chromium.launch(headless=True)
        for width, reduced in ((1280, False), (375, False), (375, True)):
            page = await browser.new_page(viewport={"width": width, "height": 1800}, reduced_motion="reduce" if reduced else "no-preference")
            errors = []
            page.on("pageerror", lambda error: errors.append(str(error)))
            await page.goto(URL, wait_until="domcontentloaded")
            await focus_and_timer(page)
            assert not errors, errors
            print(f"PASS spotlight controls/focus/timer: {width}px, reduced={reduced}")
            await page.close()
        page = await browser.new_page(viewport={"width": 1280, "height": 1800})
        await page.goto(URL, wait_until="domcontentloaded")
        await navigation_and_cap(page)
        print("PASS two-live cap and oldest-first eviction")
        await page.close()
        page = await browser.new_page(viewport={"width": 1280, "height": 1800})
        await page.goto(URL, wait_until="domcontentloaded")
        await auto_collapse(page)
        print("PASS auto-collapse after two forward exits")
        await page.close()
        page = await browser.new_page(viewport={"width": 1280, "height": 1800})
        await page.goto(URL, wait_until="domcontentloaded")
        await focus_during_slide_change(page)
        print("PASS keyboard focus during slide changes")
        await browser.close()

if __name__ == "__main__":
    asyncio.run(main())
